extends SceneTree
## 从大佬官方发布包 PCK 中提取 assets 素材（贴图转 PNG、BGM 取原始 MP3）
## 用法: godot --headless --path <本项目> --script res://extract_pck.gd -- <pck路径> <输出目录>

var pack_path := ""
var out_root := ""
var n_img := 0
var n_mp3 := 0
var n_skip := 0
var fails: Array = []

func _init() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() < 2:
		print("用法: -- <pck> <out_dir>")
		quit(1)
		return
	pack_path = args[0]
	out_root = args[1]
	print("pack: ", pack_path)
	print("load pack: ", ProjectSettings.load_resource_pack(pack_path, true))
	var files: Array = []
	_walk("res://assets", files)
	print("entries: ", files.size())
	for p in files:
		var sp := str(p)
		if not sp.ends_with(".import"):
			continue
		var orig := sp.trim_suffix(".import")
		var target := _remap_path(FileAccess.get_file_as_string(sp))
		if target == "":
			n_skip += 1
			continue
		var out_path := out_root.path_join(orig.trim_prefix("res://"))
		DirAccess.make_dir_recursive_absolute(out_path.get_base_dir())
		if target.ends_with(".ctex"):
			var tex = ResourceLoader.load(target)
			if tex is Texture2D:
				var img: Image = tex.get_image()
				if img != null:
					img.save_png(out_path)
					n_img += 1
					continue
			fails.append(orig)
		elif target.ends_with(".mp3str") or orig.ends_with(".mp3"):
			var stream = ResourceLoader.load(target)
			if stream is AudioStreamMP3:
				var f := FileAccess.open(out_path, FileAccess.WRITE)
				f.store_buffer(stream.get_data())
				f.close()
				n_mp3 += 1
				continue
			fails.append(orig)
		else:
			n_skip += 1
	print("images=", n_img, " mp3=", n_mp3, " skip=", n_skip, " fail=", fails.size())
	for f in fails.slice(0, 20):
		print("FAIL: ", f)
	quit()

func _remap_path(txt: String) -> String:
	var section := ""
	for line in txt.split("\n"):
		var l := line.strip_edges()
		if l.begins_with("["):
			section = l
		elif l.begins_with("path=") and section == "[remap]":
			return l.trim_prefix("path=").strip_edges().trim_prefix("\"").trim_suffix("\"")
	return ""

func _walk(dir_path: String, out: Array) -> void:
	var d := DirAccess.open(dir_path)
	if d == null:
		return
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		if n.begins_with("."):
			n = d.get_next()
			continue
		var p := dir_path.path_join(n)
		if d.current_is_dir():
			_walk(p, out)
		else:
			out.append(p)
		n = d.get_next()
	d.list_dir_end()
