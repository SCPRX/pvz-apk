import glob, os, sys
from PIL import Image

proj = sys.argv[1]
root = os.path.join(proj, 'assets')
expected_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'expected_images.txt')
expected = [l.strip() for l in open(expected_file, encoding='utf-8') if l.strip()]

def make_placeholder(path):
    base = None
    for cand in [path.replace('_Mask.png', '.png'), path.replace('_mask.png', '.png'), path.replace('Mask.png', '.png')]:
        if os.path.exists(cand) and cand != path:
            base = cand; break
    if base:
        b = Image.open(base).convert('RGBA'); a = b.split()[-1]
        mask = Image.new('RGBA', b.size, (255, 255, 255, 0))
        mask.paste(Image.new('RGBA', b.size, (255, 255, 255, 255)), (0, 0), a)
        mask.save(path)
    else:
        Image.new('RGBA', (16, 16), (255, 255, 255, 255)).save(path)

fixed = 0
missing = 0
for rel in expected:
    f = os.path.join(proj, rel)
    ok = False
    if os.path.exists(f):
        try:
            im = Image.open(f); im.load(); ok = True
        except Exception:
            ok = False
    if not ok:
        os.makedirs(os.path.dirname(f), exist_ok=True)
        make_placeholder(f)
        if os.path.exists(f): fixed += 1
        else: missing += 1
# 再扫一遍所有 png，修损坏的
for f in glob.glob(root + '/**/*.png', recursive=True):
    try:
        im = Image.open(f); im.load()
    except Exception:
        make_placeholder(f); fixed += 1
print('placeholders/fixed:', fixed, 'still missing:', missing)
