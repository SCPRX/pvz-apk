import os, re, sys
proj = sys.argv[1]
# 4.1 改项目名 + 打开 ETC2/ASTC
p = os.path.join(proj, 'project.godot')
s = open(p, encoding='utf-8').read()
s = re.sub(r'config/name="[^"]*"', 'config/name="邻里花园 · 完整复刻版"', s)
s = re.sub(r'enabled=PackedStringArray\([^)]*\)', 'enabled=PackedStringArray()', s)
if 'import_etc2_astc' not in s:
    if '[rendering]' in s:
        s = s.replace('[rendering]', '[rendering]\ntextures/vram_compression/import_etc2_astc=true')
    else:
        s += '\n[rendering]\ntextures/vram_compression/import_etc2_astc=true\n'
open(p, 'w', encoding='utf-8').write(s)
# 4.2 我们的自定义关卡
os.makedirs(os.path.join(proj, 'level_game_para'), exist_ok=True)
level = '''[gd_resource type="Resource" script_class="ResourceLevelData" load_steps=3 format=3]

[ext_resource type="Script" path="res://scripts/resources/level/level_data.gd" id="1_a"]
[ext_resource type="Script" path="res://scripts/resources/level/pre_plant_in_level.gd" id="1_b"]

[resource]
script = ExtResource("1_a")
game_BG = 0
game_BGM = 0
is_day = true
is_day_sun = true
is_lawn_mover = true
can_choosed_card = true
monster_mode = 1
zombie_multy = 2
max_wave = 20
max_choosed_card_num = 10
start_sun = 150
'''
open(os.path.join(proj, 'level_game_para', '我们的花园_白天20波.tres'), 'w', encoding='utf-8').write(level)
# 4.3 Android 导出预设
preset = '''[preset.0]

name="Android"
platform="Android"
runnable=true
dedicated_server=false
custom_features=""
export_filter="all_resources"
include_filter=""
exclude_filter=""
export_path=""
patches=[]
encryption_include_filters=""
encryption_exclude_filters=""
encrypt_pck=false
encrypt_directory=false
script_export_mode=2

[preset.0.options]

custom_template/debug=""
custom_template/release=""
gradle_build/use_gradle_build=false
gradle_build/export_format=0
architectures/armeabi-v7a=false
architectures/arm64-v8a=true
architectures/x86=false
architectures/x86_64=false
version/code=1
version/name="1.0"
package/unique_name="com.ourpvz.full"
package/name="邻里花园PVZ"
package/signed=true
package/app_category=2
package/retain_data_on_uninstall=false
package/exclude_from_recents=false
package/show_in_android_tv=false
package/show_in_app_library=true
package/show_as_launcher_app=false
launcher_icons/main_192x192=""
launcher_icons/adaptive_foreground_432x432=""
launcher_icons/adaptive_background_432x432=""
launcher_icons/adaptive_monochrome_432x432=""
graphics/opengl_debug=false
xr_features/xr_mode=0
screen/immersive_mode=true
screen/support_small=true
screen/support_normal=true
screen/support_large=true
screen/support_xlarge=true
user_data_backup/allow=false
command_line/extra_args=""
apk_expansion/enable=false
apk_expansion/SALT=""
apk_expansion/public_key=""
permissions/custom_permissions=PackedStringArray()
permissions/internet=false
'''
open(os.path.join(proj, 'export_presets.cfg'), 'w', encoding='utf-8').write(preset)
# 4.4 说明文件
open(os.path.join(proj, 'README_OURS.md'), 'w', encoding='utf-8').write(
    '# 邻里花园 · 完整复刻版（我们的版本）\n\n'
    '基于 B 站 UP 主「睡觉做大梦_zzz」（GitHub: hsk-dream）开源项目 PVZ-Godot_dream v1.1.1。\n'
    '- 源码：官方仓库 v1.1.1（自定义非商用许可）\n'
    '- 素材：从其官方发布包中提取重建（原版 PvZ 素材版权归 EA/PopCap）\n'
    '- 我们的改动：项目改名、新增「我们的花园_白天20波」关卡、素材与音频重组\n\n'
    '仅供个人学习，禁止商用或再分发素材。\n')
print('project patched')
