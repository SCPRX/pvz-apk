import os, sys, shutil, subprocess, glob

proj = sys.argv[1]
src_dirs = sys.argv[2:]
root = os.path.join(proj, 'assets')
needed_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'needed_audio.txt')
needed = [l.strip() for l in open(needed_file, encoding='utf-8') if l.strip()]

# 真实音效库：按文件名匹配
prov = {}
for d in src_dirs:
    for f in glob.glob(os.path.join(d, '**', '*'), recursive=True):
        if os.path.isfile(f) and os.path.splitext(f)[1].lower() in ('.ogg', '.mp3', '.wav'):
            prov.setdefault(os.path.splitext(os.path.basename(f))[0].lower(), f)

sil_ogg = '/tmp/silence.ogg'
sil_mp3 = '/tmp/silence.mp3'
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=stereo',
                '-t', '0.5', '-c:a', 'libvorbis', '-q:a', '4', sil_ogg], check=True)
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=stereo',
                '-t', '0.5', '-c:a', 'libmp3lame', '-q:a', '4', sil_mp3], check=True)

real_b = real_s = sil = 0
for p in needed:
    out = os.path.join(root, 'audio', p)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    ext = os.path.splitext(p)[1].lower()
    base = os.path.splitext(os.path.basename(p))[0].lower()
    if os.path.exists(out) and os.path.getsize(out) > 1000:
        # 已提取到的 BGM mp3 等
        if p.startswith('BGM/'): real_b += 1
        else: real_s += 1
        continue
    src = None
    if p.startswith('BGM/'):
        cand = os.path.join(root, 'audio', os.path.basename(p))
        if os.path.exists(cand): src = cand
    if src is None:
        src = prov.get(base)
    ok = False
    if src:
        sext = os.path.splitext(src)[1].lower()
        if sext == ext:
            shutil.copyfile(src, out); ok = True
        else:
            codec = ['-c:a', 'libmp3lame', '-q:a', '4'] if ext == '.mp3' else ['-c:a', 'libvorbis', '-q:a', '4']
            r = subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', src] + codec + [out], capture_output=True)
            ok = r.returncode == 0
    if not ok:
        shutil.copyfile(sil_mp3 if ext == '.mp3' else sil_ogg, out)
        sil += 1
    else:
        if p.startswith('BGM/'): real_b += 1
        else: real_s += 1
print('audio: bgm_real', real_b, 'sfx_real', real_s, 'silence', sil)
