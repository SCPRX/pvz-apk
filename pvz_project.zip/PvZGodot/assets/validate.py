#!/usr/bin/env python3
"""Validate PvZGodot assets/art PNGs and report audio files.
Usage: python3 validate.py
Checks each PNG: decodes, RGBA with real alpha channel, non-empty content,
alpha coverage sane, bbox sane (not clipped by canvas edge).
"""
import os, sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ART = os.path.join(HERE, "art")
AUD = os.path.join(HERE, "audio")

# expected deliverables (hard requirement list from task-1 + Lead's frame sequence request)
REQUIRED = [
    "sunflower.png","peashooter.png","repeater.png","snowpea.png","wallnut.png",
    "wallnut_crack1.png","wallnut_crack2.png","cherrybomb.png",
    "zombie_basic.png","zombie_eat.png","zombie_cone.png","zombie_bucket.png","zombie_flag.png",
    "pea.png","snowpea_shot.png","sun.png","lawn_mower.png","shovel.png","card_frame.png",
]
FRAMES = [f"zombie_{t}_{i}.png" for t in ("basic","cone","bucket","flag") for i in range(4)]
EAT = [f"zombie_basic_eat_{i}.png" for i in range(2)] + [f"zombie_cone_eat_{i}.png" for i in range(2)]
AUDIO = ["sun_collect.ogg","plant.ogg","shovel.ogg","pea_shoot.ogg","pea_hit.ogg",
         "zombie_groan.ogg","zombie_bite.ogg","explosion.ogg","wave_horn.ogg",
         "win.ogg","lose.ogg","bgm_day.ogg"]

# UI card background is intentionally a full opaque rectangle, no transparent margin required
FULL_FRAME = {"card_frame.png"}

def check_png(name):
    path = os.path.join(ART, name)
    errs = []
    if not os.path.exists(path):
        return ["MISSING"]
    try:
        im = Image.open(path); im.load()
    except Exception as e:
        return [f"decode error: {e}"]
    if im.mode != "RGBA":
        errs.append(f"mode={im.mode} (want RGBA)")
    a = im.getchannel("A") if "A" in im.getbands() else None
    if a is None:
        errs.append("no alpha channel")
    else:
        hist = a.histogram()
        opaque = sum(hist[250:])
        transp = hist[0]
        total = im.width * im.height
        if opaque < total * 0.01:
            errs.append("content nearly fully transparent")
        if name not in FULL_FRAME and transp < total * 0.02:
            errs.append("canvas has almost no transparent margin")
        bbox = a.getbbox()
        if not bbox:
            errs.append("empty bbox")
        else:
            l, t, r, b = bbox
            if name not in FULL_FRAME and (l <= 0 or t <= 0 or r >= im.width or b >= im.height):
                errs.append(f"content touches canvas edge bbox={bbox} size={im.size}")
            if (r - l) < 8 or (b - t) < 8:
                errs.append(f"content too small bbox={bbox}")
    return errs

def main():
    ok = True
    names = REQUIRED + FRAMES + EAT
    print(f"== PNG validation ({len(names)} files) ==")
    for n in names:
        errs = check_png(n)
        if errs:
            ok = False
            print(f"FAIL {n}: {'; '.join(errs)}")
        else:
            im = Image.open(os.path.join(ART, n))
            print(f"ok   {n:26s} {im.width}x{im.height} bbox={im.getchannel('A').getbbox()}")
    print("\n== Audio ==")
    for n in AUDIO:
        p = os.path.join(AUD, n)
        if not os.path.exists(p):
            ok = False; print(f"FAIL {n}: missing"); continue
        sz = os.path.getsize(p)
        if sz < 1000: ok = False; print(f"FAIL {n}: {sz}B too small")
        elif sz > 300 * 1024 and n != "bgm_day.ogg": ok = False; print(f"FAIL {n}: {sz}B >300KB")
        else: print(f"ok   {n:20s} {sz/1024:.1f}KB")
    print("\nRESULT:", "ALL OK" if ok else "FAILURES PRESENT")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
