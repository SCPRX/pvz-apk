# CREDITS — PvZGodot 素材来源与许可

> ⚠️ **权利状态：不明 / 版权归 EA（PopCap）所有。**
> 本目录中的植物、僵尸、子弹、阳光、割草机、铲子、卡框及全部音效，均为**原版《植物大战僵尸》游戏资源**，
> 经 GitHub 上的开源复刻/二次开发仓库间接取得（这些仓库本身**未声明开源许可证**，仅作学习/复刻用途公开）。
> 本项目仅作**个人学习 / 本地非商业用途**（personal & educational use, rights unknown）。
> **不得商用、不得公开再分发、不得上传到应用商店或资源站。** 如需公开项目，请替换为 CC0/CC-BY 素材（见文末建议）。

## 来源仓库

| # | 仓库 | 用途 | 许可声明 |
|---|---|---|---|
| A | [limuy2022/PlantsVsZombies](https://github.com/limuy2022/PlantsVsZombies)（Godot 版 PvZ 复刻） | 绝大多数植物/僵尸/子弹/阳光图 + 全部音效 | 仓库未声明 license，内部为原版拆包资源 → 权利不明 |
| B | [marblexu/PythonPlantsVsZombies](https://github.com/marblexu/PythonPlantsVsZombies)（pygame 版，3.7k★） | `pea.png` 弹体单图 | 同上，权利不明 |
| C | [jiangnangame/New-Plants-vs-Zombies-JavaScript](https://github.com/jiangnangame/New-Plants-vs-Zombies-JavaScript) | `lawn_mower.png`（LawnCleaner1.png） | 同上，权利不明 |
| D | [tbl00c/PlantsVsZombies](https://github.com/tbl00c/PlantsVsZombies) | `shovel.png`（原版 Menu.atlas/Shovel.png） | 同上，权利不明 |
| E | 本地自制（PIL 绘制，配色取样自 A 仓库 `card_peashooter.png`） | `card_frame.png` 空卡框 | 自制，随项目 |

## 美术逐文件来源（`assets/art/`）

| 文件 | 来源 URL | 作者/出处 | 许可 | 改动 |
|---|---|---|---|---|
| `cherrybomb.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/CherryBomb/CherryBomb_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `lawn_mower.png` | https://github.com/jiangnangame/New-Plants-vs-Zombies-JavaScript/blob/master/images/interface/LawnCleaner1.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `pea.png` | https://github.com/marblexu/PythonPlantsVsZombies/blob/master/resources/graphics/Bullets/PeaNormal/PeaNormal_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `peashooter.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/PeaShooter/PeaShooter_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `repeater.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/RepeaterPea/RepeaterPea_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `shovel.png` | https://github.com/tbl00c/PlantsVsZombies/blob/master/PlantsVsZombies/Resource/Images/Items/Menu.atlas/Shovel.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `snowpea.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/SnowPea/SnowPea_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `snowpea_shot.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Bullets/PeaIce/PeaIce_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `sun.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/Sun/Sun_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `sunflower.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/SunFlower/SunFlower_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `wallnut.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/WallNut/WallNut/WallNut_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `wallnut_crack1.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `wallnut_crack2.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_basic.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/Zombie/Zombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_basic_0.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/Zombie/Zombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_basic_1.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/Zombie/Zombie_1.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_basic_2.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/Zombie/Zombie_2.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_basic_3.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/Zombie/Zombie_3.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_basic_eat_0.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/ZombieAttack/ZombieAttack_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_basic_eat_1.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/ZombieAttack/ZombieAttack_1.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_bucket.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/BucketheadZombie/BucketheadZombie/BucketheadZombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_bucket_0.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/BucketheadZombie/BucketheadZombie/BucketheadZombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_bucket_1.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/BucketheadZombie/BucketheadZombie/BucketheadZombie_1.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_bucket_2.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/BucketheadZombie/BucketheadZombie/BucketheadZombie_2.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_bucket_3.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/BucketheadZombie/BucketheadZombie/BucketheadZombie_3.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_cone.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/ConeheadZombie/ConeheadZombie/ConeheadZombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_cone_0.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/ConeheadZombie/ConeheadZombie/ConeheadZombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_cone_1.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/ConeheadZombie/ConeheadZombie/ConeheadZombie_1.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_cone_2.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/ConeheadZombie/ConeheadZombie/ConeheadZombie_2.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_cone_3.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/ConeheadZombie/ConeheadZombie/ConeheadZombie_3.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_cone_eat_0.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/ConeheadZombie/ConeheadZombieAttack/ConeheadZombieAttack_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_cone_eat_1.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/ConeheadZombie/ConeheadZombieAttack/ConeheadZombieAttack_1.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_eat.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/NormalZombie/ZombieAttack/ZombieAttack_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_flag.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/FlagZombie/FlagZombie/FlagZombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_flag_0.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/FlagZombie/FlagZombie/FlagZombie_0.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_flag_1.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/FlagZombie/FlagZombie/FlagZombie_1.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_flag_2.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/FlagZombie/FlagZombie/FlagZombie_2.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `zombie_flag_3.png` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Zombies/FlagZombie/FlagZombie/FlagZombie_3.png | 原版 PvZ (PopCap/EA)，经复刻仓库 | 权利不明，仅个人学习 | 裁剪透明边界、LANCZOS 放大 1.8–3.2×、锐化 65–70%、重排到统一透明画布；未改画风/颜色 |
| `card_frame.png` | 取样自 https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/graphics/Cards/card_peashooter.png | 本地自制（配色取自原版卡片） | 自制 | 用 PIL 绘制 80×100 空卡框（棕边+绿名牌+绿色底纹+米色价格条+阳光圆点），无原图直接像素 |

## 音频逐文件来源（`assets/audio/`）

| 文件 | 原仓库文件（来源 A） | 用途 | 许可 | 改动 |
|---|---|---|---|---|
| `sun_collect.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/coin.ogg | 太阳/金币收集音 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `plant.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/plant.ogg | 种植 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `shovel.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/shovel.ogg | 铲除 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `pea_shoot.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/shoop.ogg | 豌豆发射 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `pea_hit.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/plastichit.ogg | 豌豆命中 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `zombie_groan.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/groan.ogg | 僵尸低吼 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `zombie_bite.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/chomp.ogg | 僵尸啃咬 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `explosion.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/cherrybomb.ogg | 樱桃炸弹爆炸 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `wave_horn.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/awooga.ogg | 波次号角 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `win.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/winmusic.ogg | 胜利音乐 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `lose.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/losemusic.ogg | 失败音乐 | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |
| `bgm_day.ogg` | https://github.com/limuy2022/PlantsVsZombies/blob/main/resources/Music/mainmusic.ogg | 白天关卡 BGM | 权利不明，仅个人学习 | 无（原样复制并重命名，ogg 格式未转码） |

## 素材加工说明

- 所有 PNG 统一用 Pillow 处理：裁剪透明边界 → 去除贴边的近纯白/近品红杂边（仅边界像素）→ LANCZOS 放大 → 轻锐化 → 居中到统一透明画布。
- 僵尸保留源仓库整张画布等比放大（逐帧画布注册一致），行走 4 帧可直接做循环动画；PNG 底部留 6px 透明边。
- 音效未做任何转码/响度处理，全部 ogg，可直接被 Godot 导入。

## 如需公开发布（建议替换）

- 美术：OpenGameArt / itch.io 的 CC0 PvZ-like 素材（如 `PvZ-like plant sprites`、`Zombie sprite pack`），或自行绘制/程序化生成。
- 音效：Kenney.nl CC0 音效包（Impact / UI / Digital Audio）、OpenGameArt CC0 音效。
- 替换时保持本 MANIFEST 中的文件名与规格即可无缝接入。

---

# 追加：原版场景 / 逐帧动画 / 界面原画（2026-11-14 第二轮接入）

> 同样来自 [limuy2022/PlantsVsZombies](https://github.com/limuy2022/PlantsVsZombies)（该仓库未声明 license，
> 内部为原版《植物大战僵尸》拆包资源，**权利不明**）。同样仅限**个人学习 / 本地非商业使用**，
> **不得商用、不得公开再分发**。

## 场景与界面原画

| 本地文件 | 原仓库路径 | 用途 |
|---|---|---|
| `art/bg_day.jpg` | `resources/graphics/Items/Background/Background_0.jpg` | 白天前院完整背景 1400×600（房子/草坪/栅栏/马路），9×5 草坪格与背景原生对齐 |
| `art/ui/seedbank.png` | `resources/graphics/Screen/ChooserBackground.png` | 左上原版种子银行木条（522×87，含阳光计分牌底） |
| `art/ui/mainmenu.png` | `resources/graphics/Screen/MainMenu.png` | 开始菜单背景原画 900×600 |
| `art/ui/victory.png` / `victory_panel.png` | `resources/graphics/Screen/GameVictory.png` | 胜利界面原画；`victory_panel.png` 为去白底版本 |
| `art/ui/zombies_won.jpg` | `resources/graphics/Screen/ZombiesWon.jpg` | 失败界面「僵尸无情地侵入了你的脑子」原画 |
| `art/ui/car.png` | `resources/graphics/Screen/car.png` | 割草机（小推车）原图 71×57 |
| `art/ui/boom.png` | `resources/graphics/Screen/Boom.png` | 樱桃炸弹爆炸特效原图 |
| `art/ui/start_button.png` / `adventure_0/1.png` / `seedbank_empty.png` | `resources/graphics/Screen/*` | 开始按钮 / 冒险模式按钮 / 空白种子银行 |
| `art/cards/card_*.png`（6 张） | `resources/graphics/Cards/card_*.png` | 原版种子卡（含价格数字）64×90 |
| `art/cards/card_mask.png` | `resources/graphics/card_mask.png` | 原版卡片遮罩 |

## 逐帧动画（`assets/art/plants/`、`art/zombies/`、`art/sun/`、`art/bullets/`）

| 本地目录 / 前缀 | 原仓库路径 | 帧数 |
|---|---|---|
| `plants/sunflower/sunflower_0..17` | `Plants/SunFlower/` | 18 |
| `plants/peashooter/peashooter_0..24` | `Plants/PeaShooter/` | 25 |
| `plants/repeater/repeater_0..14` | `Plants/RepeaterPea/` | 15 |
| `plants/snowpea/snowpea_0..14` | `Plants/SnowPea/` | 15 |
| `plants/wallnut/wallnut_0..15` | `Plants/WallNut/WallNut/` | 16 |
| `plants/wallnut_cracked1/wallnut_cracked1_0..10` | `Plants/WallNut/WallNut_cracked1/` | 11 |
| `plants/wallnut_cracked2/wallnut_cracked2_0..14` | `Plants/WallNut/WallNut_cracked2/` | 15 |
| `plants/cherrybomb/cherrybomb_0..6` | `Plants/CherryBomb/` | 7 |
| `sun/sun_0..21` | `Plants/Sun/` | 22 |
| `bullets/pea_start_0..2`、`pea_end_0..3`、`pea_explode.png`、`pea_ice.png` | `Bullets/PeaNormal/`、`Bullets/PeaIce/` | 3+4+1+1 |
| `zombies/basic/walk_*`、`attack_*`、`losthead_*`、`lostheadattack_*` | `Zombies/NormalZombie/` | 22+21+18+11 |
| `zombies/cone/walk_*`、`attack_*` | `Zombies/ConeheadZombie/` | 21+11 |
| `zombies/bucket/walk_*`、`attack_*` | `Zombies/BucketheadZombie/` | 15+11 |
| `zombies/flag/walk_*`、`attack_*`、`losthead_*`、`lostheadattack_*` | `Zombies/FlagZombie/` | 12+11+12+11 |
| `zombies/common/die_*`、`boomdie_*` | `Zombies/NormalZombie/ZombieDie/`、`BoomDie/` | 10+20 |

## 追加音效（第二轮）

| 本地文件 | 原仓库文件 | 用途 |
|---|---|---|
| `audio/mower.ogg` | `Music/lawnmower.ogg` | 割草机启动 |
| `audio/ui_pause.ogg` | `Music/pause.ogg` | 暂停 |
| `audio/ui_click.ogg` | `Music/buttonclick.ogg` | 按钮点击 |
| `audio/seedlift.ogg` | `Music/seedlift.ogg` | 选卡 |
| `audio/prohibit.ogg` | `Music/prohibit.ogg` | 阳光不足/冷却中提示 |
| `audio/finalwave.ogg` | `Music/finalwave.ogg` | 最后一波号角 |
| `audio/readysetplant.ogg` | `Music/readysetplant.ogg` | 开局提示 |
| `audio/zombie_die.ogg` | `Music/zombie_falling_1.ogg` | 僵尸倒地 |
| `audio/bleep.ogg` | `Music/bleep.ogg` | 备用提示音 |

## 加工说明（第二轮）

- 像素原图按原版比例直接使用（植物 1.4×、僵尸 1.2×、豌豆 2.8×、小推车 1.0×、阳光 1.0×）。
- 仅 `victory_panel.png` 做过去白底（白色 → 透明）处理，其余文件原样复制。
- 原版布局参数（供核对）：草坪 9 列 × 5 行，格子 80×100，首列中心 (300, 120)，种子银行 522×87，僵尸出生 x≈1230。

---

# 追加：原版界面 UI 原件（2026-11-15 第三轮接入，参考 B 站「完美复刻」项目的 UI 资源构成）

> 来源：[jiangnangame/New-Plants-vs-Zombies-JavaScript](https://github.com/jiangnangame/New-Plants-vs-Zombies-JavaScript)
> （完整网页版 PvZ 复刻，内含原版 PvZ 界面资源；同样未声明 license，权利归 EA/PopCap，仅个人学习使用）。
> 参考项目：[hsk-dream/PVZ-Godot_dream](https://github.com/hsk-dream/PVZ-Godot_dream)（B 站展示视频 BV1FKNJzUEpp；
> 其资源文件因版权已删除，本项目的「原版流程 / UI 构成」按该项目的原版还原思路学习实现）。

| 本地文件（`assets/art/ui2/`） | 原文件 | 用途 |
|---|---|---|
| `fm_flagmeterempty.png` / `fm_flagmeterfull.png` | `interface/FlagMeterEmpty.png` / `FlagMeterFull.png` | 原版波次进度条（空/满） |
| `fm_flagmeterparts1.png` / `fm_flagmeterparts2.png` | `interface/FlagMeterParts1.png` / `FlagMeterParts2.png` | 进度条僵尸头标记 / 大波红旗 |
| `fm_flagmeterlevelprogress.png` | `interface/FlagMeterLevelProgress.png` | 进度条文字牌（备用） |
| `seedchooser.png` | `interface/SeedChooser_Background.png` | 选卡界面「请选择你的植物」原版面板 |
| `pausemenu.png` | `interface/OptionsMenuback32.png` | 原版墓碑「菜单」暂停界面 |
| `pausebtn_a.png` / `pausebtn_b.png` | `interface/OptionsBackButton32.png` | 原版墓碑石按钮（拆成两块） |
| `largewave.png` / `finalwave.png` | `interface/LargeWave.gif` / `FinalWave.gif` | 原版「一大波僵尸即将来袭！」「最后一波攻势」横幅（取首帧转 PNG） |
| `ready_0.png` / `ready_1.png` / `ready_2.png` | `interface/PrepareGrowPlants.png` | 原版「准备… / 好… / 开始！」三连字图（按横排拆成三张） |
| `sunback.png` | `interface/SunBack.png` | 原版阳光计数牌 |
| `shovelback.png` | `interface/ShovelBack.png` | 原版铲子槽底板 |
| `lawncleaner.png` | `interface/LawnCleaner1.png` | 原版小推车 |
| `zombies_won.png` | `interface/ZombiesWon.png`（该文件在源仓库为透明/空白，实际游戏沿用 `ui/zombies_won.jpg`） | 原版失败画参考 |
| `icon_challenge.png` / `icon_almanac.png` | `interface/Challenge.png` / `SelectorScreen_Almanac_32.png` | 菜单底部功能图标（备用） |

加工说明：仅 `LargeWave/FinalWave.gif` 取首帧转 PNG、`PrepareGrowPlants.png` 等分三行拆图、`OptionsBackButton32.png` 上下拆两块；
其余原样复制，未改色/未缩放。

## 参考项目（仅学习实现思路，未复制其代码/资源）

- [hsk-dream/PVZ-Godot_dream](https://github.com/hsk-dream/PVZ-Godot_dream)：B 站「开源！使用Godot实现对原版PVZ的完美复刻」（BV1FKNJzUEpp）。
  本项目参照它的**原版流程与 UI 构成**补全了：主菜单 → 选卡 → 准备/好/开始 → 战斗、原版进度条、原版横幅、
  原版墓碑暂停菜单；其代码采用骨骼动画（Reanim→AnimationPlayer），与原版逐帧 PNG 方案不同。

---

# 追加：大嘴花 / 土豆雷素材，以及「实机取景」参考（2026-11-15 第四轮）

| 本地文件 | 来源 |
|---|---|
| `art/plants/chomper/*`（13 帧待机 + 9 帧咬 + 6 帧咀嚼） | [limuy2022/PlantsVsZombies](https://github.com/limuy2022/PlantsVsZombies) `Plants/Chomper/` |
| `art/plants/potatomine/*`（8 帧待机 + 埋地/爆炸帧） | 同上 `Plants/PotatoMine/` |
| `art/cards/card_chomper.png`、`card_potatomine.png` | 同上 `Cards/` |

## 关于「实机取景」的参考方式

- 参考项目：[hsk-dream/PVZ-Godot_dream](https://github.com/hsk-dream/PVZ-Godot_dream)
  （B 站视频 [BV1FKNJzUEpp](https://www.bilibili.com/video/BV1FKNJzUEpp/)）。
- 为了对齐画面构图，本工程**下载并逐帧查看了该视频的实机画面**（仅作参考分析，未打包进交付物），
  据此确定：设计分辨率 1066×600、背景 1400×600 以 x≈-95 偏移裁切、9×5 格子 80×100、
  种子银行 x=150、8 张卡槽 + 右侧铲子、右下原版 FlagMeter 进度条等布局参数。
- 参考项目使用的是 **Reanim → Godot AnimationPlayer 骨骼动画**（其资源文件已因版权删除）；
  本工程改用公开复刻仓库中的**逐帧 PNG 动画**还原同样的动作，未复制参考项目代码。
