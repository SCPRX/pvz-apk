> ℹ️ 说明：本表记录**第一轮**下载/加工的素材清单。第二轮已把植物/僵尸/阳光/子弹/场景/界面
> 全部替换为**原版逐帧素材**，见 `CREDITS.md` 末尾「追加：原版场景 / 逐帧动画 / 界面原画」一节。
> 第一轮的部分单帧文件（如根目录的 plant/zombie 单图）已在整理时移除，游戏使用新素材。

# MANIFEST — PvZGodot 素材规格表

生成方式：`python3 assets/validate.py` 校验，本表由 assets 内脚本按实际文件生成。

## 美术 `assets/art/`（全部 PNG，透明底 RGBA）

| 文件 | 像素尺寸 | 可见主体高 | 朝向 | 说明 |
|---|---|---|---|---|
| `sunflower.png` | 250x250 | 230px | n/a (植物面向右) |  |
| `peashooter.png` | 250x250 | 230px | n/a (植物面向右) |  |
| `repeater.png` | 250x250 | 230px | n/a (植物面向右) |  |
| `snowpea.png` | 250x250 | 230px | n/a (植物面向右) |  |
| `wallnut.png` | 250x250 | 230px | n/a (植物面向右) |  |
| `wallnut_crack1.png` | 250x250 | 230px | n/a (植物面向右) |  |
| `wallnut_crack2.png` | 250x250 | 230px | n/a (植物面向右) |  |
| `cherrybomb.png` | 321x250 | 230px | n/a (植物面向右) |  |
| `zombie_basic.png` | 305x265 | 217px | left |  |
| `zombie_eat.png` | 305x265 | 214px | left |  |
| `zombie_cone.png` | 305x265 | 252px | left |  |
| `zombie_bucket.png` | 305x265 | 251px | left |  |
| `zombie_flag.png` | 305x265 | 249px | left |  |
| `zombie_basic_0.png` | 305x265 | 217px | left | 4 帧循环，画布注册一致 |
| `zombie_basic_1.png` | 305x265 | 214px | left | 4 帧循环，画布注册一致 |
| `zombie_basic_2.png` | 305x265 | 212px | left | 4 帧循环，画布注册一致 |
| `zombie_basic_3.png` | 305x265 | 210px | left | 4 帧循环，画布注册一致 |
| `zombie_cone_0.png` | 305x265 | 252px | left | 4 帧循环，画布注册一致 |
| `zombie_cone_1.png` | 305x265 | 252px | left | 4 帧循环，画布注册一致 |
| `zombie_cone_2.png` | 305x265 | 253px | left | 4 帧循环，画布注册一致 |
| `zombie_cone_3.png` | 305x265 | 253px | left | 4 帧循环，画布注册一致 |
| `zombie_bucket_0.png` | 305x265 | 251px | left | 4 帧循环，画布注册一致 |
| `zombie_bucket_1.png` | 305x265 | 249px | left | 4 帧循环，画布注册一致 |
| `zombie_bucket_2.png` | 305x265 | 242px | left | 4 帧循环，画布注册一致 |
| `zombie_bucket_3.png` | 305x265 | 242px | left | 4 帧循环，画布注册一致 |
| `zombie_flag_0.png` | 305x265 | 249px | left | 4 帧循环，画布注册一致 |
| `zombie_flag_1.png` | 305x265 | 251px | left | 4 帧循环，画布注册一致 |
| `zombie_flag_2.png` | 305x265 | 253px | left | 4 帧循环，画布注册一致 |
| `zombie_flag_3.png` | 305x265 | 255px | left | 4 帧循环，画布注册一致 |
| `zombie_basic_eat_0.png` | 305x265 | 214px | left |  |
| `zombie_basic_eat_1.png` | 305x265 | 212px | left |  |
| `zombie_cone_eat_0.png` | 305x265 | 253px | left |  |
| `zombie_cone_eat_1.png` | 305x265 | 254px | left |  |
| `pea.png` | 40x40 | 34px | n/a |  |
| `snowpea_shot.png` | 40x40 | 34px | n/a |  |
| `sun.png` | 110x110 | 96px | n/a |  |
| `lawn_mower.png` | 160x140 | 126px | right | 镜像后朝左 |
| `shovel.png` | 72x72 | 29px | n/a |  |
| `card_frame.png` | 80x100 | 100px | n/a | 不透明满幅，用于卡片底 |

- 画布统一：植物 250×250（cherrybomb 因源图宽 321×250）；僵尸帧序列统一 305×265，逐帧画布注册一致可直接循环不抖；杂项见上表。
- 植物/僵尸可见主体高度均在 200–240px（规格 180–260px 内）；僵尸 PNG 含 6px 透明底边，避免脚部贴边。
- 僵尸全部**朝左**（facing=left，直接可用，无需镜像）。
- 植物朝向：面向右（原版素材方向）；如需向左由引擎 flip_h。
- lawn_mower：原版推车朝右，MANIFEST 标注 facing=right，如游戏里需要朝左请 flip_h。
- card_frame.png：80×100 满幅不透明 UI 卡底框（非透明底，属 UI 资源）。

## 音频 `assets/audio/`（ogg，全部可被 Godot 直接导入）

| 文件 | 时长 | 大小 | 原仓库文件 | 处理 |
|---|---|---|---|---|
| `sun_collect.ogg` | 0.91s | 27.0 KB | coin.ogg | 映射 |
| `plant.ogg` | 0.75s | 12.4 KB | plant.ogg | 原样 |
| `shovel.ogg` | 0.23s | 6.9 KB | shovel.ogg | 原样 |
| `pea_shoot.ogg` | 0.65s | 11.7 KB | shoop.ogg | 映射 |
| `pea_hit.ogg` | 0.18s | 25.2 KB | plastichit.ogg | 原样 |
| `zombie_groan.ogg` | 1.18s | 15.7 KB | groan.ogg | 原样 |
| `zombie_bite.ogg` | 0.99s | 79.4 KB | chomp.ogg | 原样 |
| `explosion.ogg` | 2.81s | 53.8 KB | cherrybomb.ogg | 原样 |
| `wave_horn.ogg` | 4.15s | 65.6 KB | awooga.ogg | 原样 |
| `win.ogg` | 4.42s | 67.8 KB | winmusic.ogg | 原样 |
| `lose.ogg` | 6.48s | 63.7 KB | losemusic.ogg | 原样 |
| `bgm_day.ogg` | ? | 1154.9 KB | mainmusic.ogg | 原样 |

- 所有音效 < 300KB，bgm_day.ogg ≈1.15MB（<2.5MB 限制）。
- Godot 导入建议：音效 Loop=Off，bgm_day Loop=Forward。

## 文件总数

- art: 39 个 PNG；audio: 12 个 ogg。
