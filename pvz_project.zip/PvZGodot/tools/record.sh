#!/usr/bin/env bash
# 录像：Godot --write-movie 逐帧渲染 → ffmpeg 转 H.264 MP4（1066x600，30fps）。
#
# 用法:
#   ./tools/record.sh [秒数=10] [传给游戏的用户参数...]
# 例:
#   PREFIX=preview_probe bash tools/record.sh 10
#   PREFIX=preview bash tools/record.sh 12 --state=play --auto --speed=2
#   GAME_ARGS="--state=play --auto" PREFIX=battle bash tools/record.sh 15
#
# 默认游戏参数（Lead 定案）: --state=play --auto --speed=2 --ff=40 --seed=7 --mute
#   --ff=40 先确定性快进到中期，再以 2x 实时录 15s（视频仍是 30fps 正常播放）。
# 环境变量: GODOT RES(默认 1066x600) FPS(30) PREFIX(输出名) MP4_OUT(完整输出路径)
#           GAME_ARGS(空格分隔的游戏用户参数，可用 GAME_ARGS=" " 清空) KEEP_AVI(1=保留原始 avi)
#           MAKE_GIF(默认 1，额外生成 <prefix>.gif 预览) GIF_OUT(自定义 gif 路径)
#           TIMEOUT(秒，默认 时长+180)
# 退出码: 0 = MP4 存在且 ffprobe 时长达标；1 = 失败（会打印日志尾部）。
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT="${GODOT:-/root/workspace/.tools/godot441/Godot_v4.4.1-stable_linux.arm64}"
RES="${RES:-1066x600}"
FPS="${FPS:-30}"
PREFIX="${PREFIX:-preview}"
DURATION="${1:-10}"
[ $# -gt 0 ] && shift
EXTRA_ARGS=("$@")
GAME_ARGS="${GAME_ARGS---state=play --auto --speed=2 --ff=40 --seed=7 --mute}"
FPS="${FPS:-30}"
FRAMES=$((DURATION * FPS))
TIMEOUT="${TIMEOUT:-$((DURATION + 180))}"

OUT_MP4="${MP4_OUT:-$ROOT/qa/${PREFIX}.mp4}"
OUT_MP4="$(realpath -m "$OUT_MP4")"
MOVIE_DIR="$ROOT/qa/movie"
mkdir -p "$MOVIE_DIR" "$(dirname "$OUT_MP4")"
AVI="$MOVIE_DIR/${PREFIX}.avi"
LOG="$MOVIE_DIR/${PREFIX}.log"

export LIBGL_ALWAYS_SOFTWARE=1 GODOT_SILENCE_ROOT_WARNING=1
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/xdg}"
mkdir -p "$XDG_RUNTIME_DIR"

read -ra GAME_ARR <<<"$GAME_ARGS"
USER_ARGS=("${GAME_ARR[@]}" "${EXTRA_ARGS[@]}")

echo "[record] ${DURATION}s @ ${FPS}fps (${FRAMES} 帧) -> $OUT_MP4"
echo "[record] 游戏参数: ${USER_ARGS[*]:-（无）}"
rm -f "$AVI" "$OUT_MP4" "$MOVIE_DIR/${PREFIX}_frame.png" "$MOVIE_DIR/${PREFIX}_frame_*.png" "$LOG"

t0=$(date +%s)
timeout "$TIMEOUT" xvfb-run -a -s "-screen 0 ${RES}x24" "$GODOT" \
	--path "$ROOT" --rendering-driver opengl3 --audio-driver Dummy \
	--resolution "$RES" --write-movie "$AVI" --fixed-fps "$FPS" \
	--quit-after "$FRAMES" -- "${USER_ARGS[@]}" >"$LOG" 2>&1
RC=$?
t1=$(date +%s)
echo "[record] godot exit=$RC elapsed=$((t1 - t0))s log=$LOG"

if grep -Eq 'SCRIPT ERROR|Parse Error|ERROR:' "$LOG" 2>/dev/null; then
	echo "[record] WARN 日志里有引擎/脚本错误："
	grep -E 'SCRIPT ERROR|Parse Error|ERROR:' "$LOG" | head -10 | sed 's/^/     /'
fi
if [ ! -s "$AVI" ]; then
	echo "[record] FAIL: 没有生成 AVI（rc=$RC）"
	echo "--- 日志尾部($LOG)"
	tail -15 "$LOG" 2>/dev/null | sed 's/^/     /'
	exit 1
fi

AVI_SECONDS="$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$AVI" 2>/dev/null || echo 0)"
echo "[record] AVI $(du -h "$AVI" | awk '{print $1}') duration=${AVI_SECONDS}s"

ffmpeg -y -loglevel error -i "$AVI" -c:v libx264 -preset veryfast -crf 21 \
	-pix_fmt yuv420p -movflags +faststart "$OUT_MP4" || {
	echo "[record] FAIL: ffmpeg 转码失败"
	exit 1
}
if [ ! -s "$OUT_MP4" ]; then
	echo "[record] FAIL: 没有生成 MP4"
	exit 1
fi

DURATION_OUT="$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$OUT_MP4")"
SIZE_OUT="$(stat -c %s "$OUT_MP4")"
STREAM_INFO="$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height,avg_frame_rate,codec_name -of default=nw=1 "$OUT_MP4" | tr '\n' ' ')"
echo "[record] MP4 ${SIZE_OUT} bytes duration=${DURATION_OUT}s $STREAM_INFO"

# 时长自检：至少达到请求时长的 90%，且大于 8 秒（QA 要求）；不足则失败
MIN_OK="$(awk -v d="$DURATION_OUT" -v req="$DURATION" 'BEGIN { print (d >= req * 0.9) ? 1 : 0 }')"
if [ "$MIN_OK" != "1" ]; then
	echo "[record] FAIL: MP4 时长 ${DURATION_OUT}s < 请求 ${DURATION}s 的 90%"
	exit 1
fi
if awk -v d="$DURATION_OUT" 'BEGIN { exit (d > 8.0) ? 0 : 1 }'; then
	: # >8s, QA 要求达标
else
	echo "[record] WARN: 时长 ${DURATION_OUT}s <= 8s（正式预览需要 10-15s）"
fi

# 抽一帧供人工/read_image 审查
FRAME_T="$(awk -v d="$DURATION_OUT" 'BEGIN { printf "%.2f", (d > 5.0) ? 5.0 : d / 2 }')"
FRAME_PNG="$MOVIE_DIR/${PREFIX}_frame_${FRAME_T}.png"
if ffmpeg -y -loglevel error -ss "$FRAME_T" -i "$OUT_MP4" -frames:v 1 "$FRAME_PNG" 2>/dev/null; then
	echo "[record] 抽帧: $FRAME_PNG"
	if ! python3 "$ROOT/tools/png_stats.py" "$FRAME_PNG" --expect "$RES"; then
		echo "[record] WARN: 抽帧内容自检未通过（可能黑屏/白屏）"
	fi
fi

# 生成 GIF（用户预览用；12fps / 800px 宽，体积可控）
if [ "${MAKE_GIF:-1}" = "1" ]; then
	GIF_OUT="${GIF_OUT:-${OUT_MP4%.mp4}.gif}"
	rm -f "$GIF_OUT"
	if ffmpeg -y -loglevel error -i "$OUT_MP4" \
		-vf "fps=12,scale=800:-1:flags=lanczos,split[a][b];[a]palettegen[p];[b][p]paletteuse" \
		-loop 0 "$GIF_OUT" && [ -s "$GIF_OUT" ]; then
		echo "[record] GIF $(stat -c %s "$GIF_OUT") bytes -> $GIF_OUT"
	else
		echo "[record] WARN: GIF 生成失败（不影响 MP4）"
	fi
fi

if [ "${KEEP_AVI:-0}" = "1" ]; then
	echo "[record] 保留原始 AVI（KEEP_AVI=1）: $AVI"
else
	rm -f "$AVI"
fi
echo "[record] OK -> $OUT_MP4"
