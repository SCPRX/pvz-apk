#!/usr/bin/env python3
"""PNG 内容自检（依赖 Pillow）：尺寸 / 全黑 / 全白 / 纯色 / 文件过小。

用法:
    python3 png_stats.py <shot.png> [--expect 1066x600] [--min-bytes 8000]

退出码: 0 = 通过；1 = 失败（缺文件 / 尺寸不对 / 黑屏 / 白屏 / 纯色 / 文件过小）。
输出以 STATS / CHECK 开头的行，方便被脚本 grep 与写进 QA 报告。
"""
import argparse
import os
import sys

try:
    from PIL import Image, ImageStat
except ImportError:  # pragma: no cover
    print("CHECK fail: Pillow 未安装，无法自检")
    sys.exit(1)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("png")
    ap.add_argument("--expect", default="1066x600", help="期望分辨率 WxH；传 none 跳过")
    ap.add_argument("--min-bytes", type=int, default=8000)
    args = ap.parse_args()

    path = args.png
    if not os.path.isfile(path):
        print(f"CHECK fail: 文件不存在 {path}")
        return 1

    size_bytes = os.path.getsize(path)
    try:
        im = Image.open(path)
        im.load()
    except Exception as exc:  # noqa: BLE001
        print(f"CHECK fail: 无法解码 PNG: {exc}")
        return 1

    w, h = im.size
    rgb = im.convert("RGB")
    stat = ImageStat.Stat(rgb)
    mean = tuple(round(v, 1) for v in stat.mean)
    std = tuple(round(v, 1) for v in stat.stddev)

    # 8x 降采样统计非黑/非白占比与颜色数（比整图逐像素快得多）
    small = rgb.resize((max(1, w // 8), max(1, h // 8)))
    raw = small.tobytes()
    n = len(raw) // 3
    nonblack = 0
    nonwhite = 0
    colors = set()
    for i in range(0, len(raw), 3):
        r, g, b = raw[i], raw[i + 1], raw[i + 2]
        s = r + g + b
        if s > 24:
            nonblack += 1
        if s < 741:
            nonwhite += 1
        colors.add((r, g, b))
    nonblack /= n
    nonwhite /= n
    colors = len(colors)
    gray_mean = sum(mean) / 3.0
    max_std = max(std)

    print(
        f"STATS path={path} size={w}x{h} bytes={size_bytes} "
        f"mean={mean} stddev={std} nonblack={nonblack:.1%} "
        f"nonwhite={nonwhite:.1%} colors={colors}"
    )

    fails = []
    warns = []
    if args.expect and args.expect.lower() != "none":
        ew, eh = args.expect.lower().split("x")
        if (w, h) != (int(ew), int(eh)):
            fails.append(f"分辨率 {w}x{h} != 期望 {args.expect}")
    if size_bytes < args.min_bytes:
        fails.append(f"文件过小 {size_bytes}B < {args.min_bytes}B（可能没渲染出内容）")
    if gray_mean < 6 and max_std < 4:
        fails.append("疑似全黑（均值和方差都接近 0）")
    if gray_mean > 249 and max_std < 4:
        fails.append("疑似全白（均值和方差都接近 255）")
    if colors <= 4 and max_std < 3:
        fails.append(f"疑似纯色画面（采样颜色数={colors}）")
    if nonblack < 0.005:
        fails.append(f"非黑像素仅 {nonblack:.2%}，画面几乎全黑")
    if nonwhite < 0.005:
        fails.append(f"非白像素仅 {nonwhite:.2%}，画面几乎全白")
    if colors < 16:
        warns.append(f"采样颜色数偏少（{colors}），画面可能过于单调")

    for msg in fails:
        print(f"CHECK fail: {msg}")
    for msg in warns:
        print(f"CHECK warn: {msg}")
    if fails:
        return 1
    print("CHECK ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())
