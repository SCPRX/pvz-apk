#!/usr/bin/env bash
# 真实渲染截图：Xvfb + 软件 OpenGL（llvmpipe）渲染 1066x600 并存 PNG。
#
# 用法:
#   ./tools/screenshot.sh <输出路径.png> [帧号] [传给游戏的用户参数...]
# 例:
#   bash tools/screenshot.sh qa/shots/menu.png 45 --state=menu
#   FRAME=600 bash tools/screenshot.sh qa/shots/play.png 60 --state=play --ff=30
#
# 环境变量: GODOT(引擎路径) RES(默认 1066x600) SHOT_FRAME(默认帧号=30；menu 可 30~45) TIMEOUT(秒, 默认 120)
# 退出码: 0 = PNG 存在且通过非黑屏/尺寸自检；1 = 失败（日志尾部会打印）。
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT="${GODOT:-/root/workspace/.tools/godot441/Godot_v4.4.1-stable_linux.arm64}"
RES="${RES:-1066x600}"
FRAME="${SHOT_FRAME:-30}"
TIMEOUT="${TIMEOUT:-120}"

OUT="${1:-$ROOT/qa/shot.png}"
mkdir -p "$(dirname "$OUT")"
OUT="$(realpath -m "$OUT")"
[ $# -gt 0 ] && shift
if [ "${1:-}" = "" ] || [[ "${1:-}" =~ ^-- ]]; then
	: # 没给帧号，用默认
else
	FRAME="$1"
	shift
fi
EXTRA_ARGS=("$@")
LOG="$(dirname "$OUT")/shot_$(basename "$OUT" .png).log"

export LIBGL_ALWAYS_SOFTWARE=1 GODOT_SILENCE_ROOT_WARNING=1
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/xdg}"
mkdir -p "$XDG_RUNTIME_DIR"

echo "[shot] out=$OUT frame=$FRAME res=$RES extra=${EXTRA_ARGS[*]:-}"
rm -f "$OUT" "$LOG"
t0=$(date +%s)
timeout "$TIMEOUT" xvfb-run -a -s "-screen 0 ${RES}x24" "$GODOT" \
	--path "$ROOT" --rendering-driver opengl3 --audio-driver Dummy \
	--resolution "$RES" --fixed-fps 30 \
	-- --shot="$OUT" --shot-frame="$FRAME" "${EXTRA_ARGS[@]}" >"$LOG" 2>&1
RC=$?
t1=$(date +%s)
echo "[shot] godot exit=$RC elapsed=$((t1 - t0))s log=$LOG"

# 引擎/脚本报错单独摘出来（不因此一定判失败，但必须让 QA 看见）
if grep -Eq 'SCRIPT ERROR|Parse Error|ERROR:' "$LOG" 2>/dev/null; then
	echo "[shot] WARN 日志里有引擎/脚本错误："
	grep -E 'SCRIPT ERROR|Parse Error|ERROR:' "$LOG" | head -10 | sed 's/^/     /'
fi

if [ ! -f "$OUT" ]; then
	echo "[shot] FAIL: 没有生成 PNG（rc=$RC）"
	echo "--- 日志尾部($LOG)"
	tail -15 "$LOG" 2>/dev/null | sed 's/^/     /'
	exit 1
fi
if ! grep -q '\[capture\] saved' "$LOG" 2>/dev/null; then
	echo "[shot] FAIL: PNG 存在但日志里没有 '[capture] saved'（截图可能不完整）"
	tail -15 "$LOG" 2>/dev/null | sed 's/^/     /'
	exit 1
fi

echo "[shot] 校验 PNG 内容..."
if ! python3 "$ROOT/tools/png_stats.py" "$OUT" --expect "$RES"; then
	echo "[shot] FAIL: PNG 内容自检未通过"
	tail -15 "$LOG" 2>/dev/null | sed 's/^/     /'
	exit 1
fi
echo "[shot] OK $(stat -c %s "$OUT") bytes -> $OUT"
