class_name ArtPlants
extends RefCounted
## 程序化植物美术（不依赖贴图，纯矢量绘制；贴图素材到达后可无缝替换）
## 原点 = 格子中心；植物约占 x:-60..60, y:-75..48

static func _shadow(ci: CanvasItem) -> void:
	ci.draw_colored_polygon(ArtUI.ellipse_points(Vector2(0, 42), 34, 9, 20), Color(0, 0, 0, 0.18))


static func draw(ci: CanvasItem, kind: String, t: float, hp_ratio: float = 1.0,
		flash: float = 0.0, fuse: float = 0.0) -> void:
	match kind:
		"sunflower":
			_sunflower(ci, t, flash)
		"peashooter":
			_shooter(ci, t, flash, Color(0.40, 0.72, 0.26), Color(0.46, 0.78, 0.30), 1)
		"repeater":
			_shooter(ci, t, flash, Color(0.36, 0.68, 0.24), Color(0.43, 0.75, 0.28), 2)
		"snowpea":
			_shooter(ci, t, flash, Color(0.35, 0.66, 0.78), Color(0.52, 0.80, 0.90), 1, true)
		"wallnut":
			_wallnut(ci, t, hp_ratio, flash)
		"cherrybomb":
			_cherry(ci, t, fuse, flash)
		_:
			ci.draw_circle(Vector2.ZERO, 24, Color.MAGENTA)


## ---------- 向日葵 ----------
static func _sunflower(ci: CanvasItem, t: float, flash: float) -> void:
	_shadow(ci)
	ci.draw_line(Vector2(0, 44), Vector2(0, 2), Color(0.27, 0.51, 0.15), 10.0, true)
	ci.draw_line(Vector2(0, 44), Vector2(0, 2), Color(0.20, 0.40, 0.11), 4.0, true)
	ArtUI.leaf(ci, Vector2(0, 36), -2.75, 22.0, Color(0.34, 0.61, 0.19))
	ArtUI.leaf(ci, Vector2(0, 36), -0.4, 22.0, Color(0.34, 0.61, 0.19))
	ArtUI.leaf(ci, Vector2(0, 30), -2.2, 15.0, Color(0.29, 0.55, 0.16))
	var sway := sin(t * 1.7) * 0.085
	ci.draw_set_transform(Vector2(0, 0), sway, Vector2.ONE)
	var hc := Vector2(0, -20)
	# 花瓣
	for k in 12:
		var a := TAU * float(k) / 12.0 + sin(t * 1.1) * 0.02
		var pc := hc + Vector2(cos(a), sin(a)) * 33.0
		var col := Color(1.0, 0.85, 0.21) if k % 2 == 0 else Color(1.0, 0.75, 0.11)
		ArtUI.ellipse(ci, pc, 17.5, 9.0, col.darkened(0.18), 20, a)
		ArtUI.ellipse(ci, pc, 16.0, 7.6, col, 20, a)
	# 花盘
	ci.draw_circle(hc, 25.0, Color(0.30, 0.17, 0.05))
	ci.draw_circle(hc, 22.5, Color(0.52, 0.31, 0.11))
	ci.draw_circle(hc + Vector2(0, 2), 18.0, Color(0.58, 0.36, 0.14))
	# 瓜子纹理
	for k in 12:
		var a := TAU * float(k) / 12.0 + 0.26
		ci.draw_circle(hc + Vector2(cos(a), sin(a)) * 13.0, 2.2, Color(0.40, 0.23, 0.07, 0.9))
	# 表情
	for ex in [-8.5, 8.5]:
		ci.draw_circle(hc + Vector2(ex, -3.0), 7.0, Color(0.23, 0.12, 0.04))
		ci.draw_circle(hc + Vector2(ex, -3.0), 6.0, Color(1.0, 0.99, 0.92))
		ci.draw_circle(hc + Vector2(ex + 0.8, -3.4), 3.2, Color(0.07, 0.05, 0.03))
		ci.draw_circle(hc + Vector2(ex - 0.8, -5.0), 1.2, Color(1, 1, 1, 0.95))
	ci.draw_arc(hc + Vector2(0, 6.0), 7.0, 0.35, PI - 0.35, 12, Color(0.22, 0.11, 0.04), 2.6, true)
	ci.draw_circle(hc + Vector2(-15, 6), 3.4, Color(1.0, 0.55, 0.45, 0.35))
	ci.draw_circle(hc + Vector2(15, 6), 3.4, Color(1.0, 0.55, 0.45, 0.35))
	if flash > 0.0:
		ci.draw_circle(hc, 30.0, Color(1.0, 1.0, 0.6, 0.35 * flash))
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


## ---------- 射手（豌豆/双发/寒冰） ----------
static func _shooter(ci: CanvasItem, t: float, flash: float, col: Color, col_light: Color,
		barrels: int, icy: bool = false) -> void:
	_shadow(ci)
	ci.draw_line(Vector2(0, 46), Vector2(0, 4), Color(0.27, 0.51, 0.15), 10.0, true)
	ci.draw_line(Vector2(0, 46), Vector2(0, 4), Color(0.20, 0.40, 0.11), 4.0, true)
	ArtUI.leaf(ci, Vector2(0, 38), -2.8, 21.0, Color(0.34, 0.61, 0.19))
	ArtUI.leaf(ci, Vector2(0, 38), -0.35, 21.0, Color(0.34, 0.61, 0.19))
	var breathe := sin(t * 2.1) * 0.022
	var hc := Vector2(0, -22)
	ci.draw_set_transform(hc, breathe, Vector2.ONE)
	# 头部
	ArtUI.ellipse(ci, Vector2(0, 0), 34.0, 31.0, col.darkened(0.42))
	ArtUI.ellipse(ci, Vector2(0, 0), 31.0, 28.0, col)
	ArtUI.ellipse(ci, Vector2(-2, 8), 26.0, 15.0, col_light, 24, 0.0)
	# 炮口（1 或 2 个）
	var snout_ys := [-30.0] if barrels == 1 else [-33.0, -13.0]
	for sy in snout_ys:
		var sn := Vector2(28, sy)
		ArtUI.ellipse(ci, sn, 19.0, 15.5, col.darkened(0.42), 24)
		ArtUI.ellipse(ci, sn, 16.0, 12.5, col_light, 24)
		ci.draw_circle(sn + Vector2(13, 0), 10.0, col.darkened(0.62))
		ci.draw_circle(sn + Vector2(13, 0), 7.2, Color(0.06, 0.14, 0.04))
		if icy:
			ci.draw_arc(sn + Vector2(13, 0), 10.0, -2.2, 0.6, 10, Color(0.85, 0.97, 1.0, 0.85), 2.5, true)
	# 眼睛
	ci.draw_circle(Vector2(1, -14), 11.0, col.darkened(0.42))
	ci.draw_circle(Vector2(1, -14), 9.2, Color(1.0, 0.99, 0.93))
	ci.draw_circle(Vector2(3.5, -14), 4.6, Color(0.06, 0.08, 0.05))
	ci.draw_circle(Vector2(1.6, -16.5), 1.7, Color(1, 1, 1, 0.9))
	# 眉毛
	ci.draw_line(Vector2(-10, -24), Vector2(11, -21), Color(0.20, 0.37, 0.10), 4.0, true)
	if icy:
		# 冰霜纹
		for k in 4:
			var a := TAU * float(k) / 4.0 + 0.4
			ci.draw_line(Vector2(0, 8) + Vector2(cos(a), sin(a)) * 6.0, Vector2(0, 8) + Vector2(cos(a), sin(a)) * 13.0,
				Color(0.92, 0.99, 1.0, 0.75), 1.8, true)
	if flash > 0.0:
		for sy in snout_ys:
			ci.draw_circle(Vector2(46, sy), 13.0, Color(0.85, 1.0, 0.6, 0.75 * flash))
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


## ---------- 坚果墙 ----------
static func _wallnut(ci: CanvasItem, t: float, hp_ratio: float, flash: float) -> void:
	_shadow(ci)
	var wob := 1.0 + sin(t * 1.3) * 0.008
	var hc := Vector2(0, 2)
	ci.draw_set_transform(hc, 0.0, Vector2(wob, 1.0 / wob))
	ArtUI.ellipse(ci, Vector2(0, 0), 39.0, 45.0, Color(0.30, 0.17, 0.06), 30)
	ArtUI.ellipse(ci, Vector2(0, -1), 36.0, 42.0, Color(0.74, 0.50, 0.25), 30)
	ArtUI.ellipse(ci, Vector2(-8, -10), 22.0, 26.0, Color(0.82, 0.60, 0.34, 0.55), 24)
	ArtUI.ellipse(ci, Vector2(0, 10), 30.0, 20.0, Color(0.62, 0.39, 0.18, 0.35), 24)
	# 眼睛
	var eye_y := -8.0
	for ex in [-13.0, 13.0]:
		ci.draw_circle(Vector2(ex, eye_y), 8.5, Color(0.28, 0.15, 0.05))
		ci.draw_circle(Vector2(ex, eye_y), 7.2, Color(1.0, 0.99, 0.92))
		ci.draw_circle(Vector2(ex - 0.5, eye_y + 0.5), 3.4, Color(0.07, 0.05, 0.03))
		ci.draw_circle(Vector2(ex - 1.8, eye_y - 1.6), 1.2, Color(1, 1, 1, 0.9))
	# 嘴巴（血量越低越慌张）
	if hp_ratio > 0.66:
		ci.draw_arc(Vector2(0, 8), 8.0, 0.4, PI - 0.4, 12, Color(0.26, 0.14, 0.05), 2.8, true)
	elif hp_ratio > 0.33:
		ci.draw_arc(Vector2(0, 12), 7.0, PI + 0.4, TAU - 0.4, 12, Color(0.26, 0.14, 0.05), 2.8, true)
	else:
		ArtUI.ellipse(ci, Vector2(0, 14), 6.0, 4.5, Color(0.28, 0.15, 0.05))
	# 裂纹
	if hp_ratio < 0.66:
		ci.draw_polyline(PackedVector2Array([Vector2(-26, -28), Vector2(-16, -14), Vector2(-22, 2)]),
			Color(0.30, 0.16, 0.05), 2.6, true)
		ci.draw_polyline(PackedVector2Array([Vector2(20, -26), Vector2(12, -12), Vector2(20, -2)]),
			Color(0.30, 0.16, 0.05), 2.2, true)
	if hp_ratio < 0.33:
		ci.draw_polyline(PackedVector2Array([Vector2(24, 16), Vector2(12, 24), Vector2(6, 38)]),
			Color(0.30, 0.16, 0.05), 2.6, true)
		ci.draw_polyline(PackedVector2Array([Vector2(-24, 18), Vector2(-14, 28), Vector2(-18, 38)]),
			Color(0.30, 0.16, 0.05), 2.2, true)
	if flash > 0.0:
		ArtUI.ellipse(ci, Vector2(0, -1), 36.0, 42.0, Color(1, 1, 1, 0.28 * flash), 24)
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


## ---------- 樱桃炸弹 ----------
static func _cherry(ci: CanvasItem, t: float, fuse: float, flash: float) -> void:
	_shadow(ci)
	var pulse := 1.0 + sin(t * 13.0) * 0.05 * (1.0 - fuse)
	ci.draw_set_transform(Vector2(0, 4), 0.0, Vector2(pulse, pulse))
	# 茎与叶
	ci.draw_line(Vector2(-11, -14), Vector2(1, -40), Color(0.29, 0.53, 0.16), 5.0, true)
	ci.draw_line(Vector2(12, -12), Vector2(1, -40), Color(0.29, 0.53, 0.16), 5.0, true)
	ArtUI.leaf(ci, Vector2(1, -40), -1.9, 15.0, Color(0.36, 0.63, 0.20))
	ArtUI.leaf(ci, Vector2(1, -40), -1.1, 12.0, Color(0.31, 0.57, 0.17))
	# 樱桃
	for c in [Vector2(-14, 6), Vector2(14, 2)]:
		var r := 27.0
		ci.draw_circle(c, r, Color(0.45, 0.06, 0.06))
		ci.draw_circle(c, r - 2.5, Color(0.86, 0.18, 0.14))
		ci.draw_circle(c, r - 3.0, Color(0.80, 0.14, 0.11))
		ci.draw_circle(c + Vector2(-7, -8), 8.0, Color(1.0, 0.45, 0.38, 0.55))
	# 生气的脸
	for c in [Vector2(-14, 6), Vector2(14, 2)]:
		ci.draw_circle(c + Vector2(-5, -3), 5.0, Color(1, 1, 1))
		ci.draw_circle(c + Vector2(5, -3), 5.0, Color(1, 1, 1))
		ci.draw_circle(c + Vector2(-4, -2), 2.6, Color(0.08, 0.04, 0.02))
		ci.draw_circle(c + Vector2(6, -2), 2.6, Color(0.08, 0.04, 0.02))
		ci.draw_line(c + Vector2(-10, -11), c + Vector2(-1, -8), Color(0.30, 0.04, 0.02), 2.5, true)
		ci.draw_line(c + Vector2(10, -11), c + Vector2(1, -8), Color(0.30, 0.04, 0.02), 2.5, true)
		ci.draw_arc(c + Vector2(0, 9), 5.5, PI + 0.2, TAU - 0.2, 10, Color(0.30, 0.04, 0.02), 2.5, true)
	# 引线火花
	if fuse > 0.0 and fuse < 0.98:
		var spark := Vector2(1, -44) + Vector2(sin(t * 21.0) * 3.0, -6.0)
		ci.draw_circle(spark, 5.0, Color(1.0, 0.85, 0.25, 0.9))
		ci.draw_circle(spark, 2.5, Color(1, 1, 0.9))
	# 即将爆炸的红色闪光
	if fuse < 0.35:
		var a := (0.35 - fuse) / 0.35
		ci.draw_circle(Vector2(0, 0), 60.0 * (0.7 + a * 0.5), Color(1.0, 0.25, 0.1, 0.22 * a))
	if flash > 0.0:
		ci.draw_circle(Vector2(0, 0), 55.0, Color(1, 1, 1, 0.3 * flash))
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
