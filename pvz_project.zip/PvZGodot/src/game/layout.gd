class_name Layout
extends RefCounted
## 全局布局 —— 按 B 站参考实机（Godot 完全复刻项目）的取景还原：
## 设计分辨率 1066x600；背景原图 1400x600 以 x=-95 偏移裁切显示，草坪更占满屏幕。
## 草坪 9 列 x 5 行，格子 80x100；第 0 列中心（屏幕）=205，第 0 行中心 y=120。

const W := 1066.0
const H := 600.0

## 背景贴图偏移（原版背景 1400x600 裁切显示）
const BG_POS := Vector2(-95.0, 0.0)
const BG_SIZE := Vector2(1400.0, 600.0)

## 草坪（格子边界）
const COLS := 9
const ROWS := 5
const CELL_W := 80.0
const CELL_H := 96.0
const LAWN_LEFT := 165.0
const LAWN_TOP := 90.0
const LAWN_RIGHT := 885.0
const LAWN_BOTTOM := 570.0

## 原版种子银行（ChooserBackground.png 522x87）位置
const BANK_POS := Vector2(150.0, 0.0)
const BANK_W := 522.0
const BANK_H := 87.0
const CARD_SLOT_X0 := 228.0
const CARD_SLOT_DX := 54.0
const CARD_W := 51.2
const CARD_H := 72.0
const CARD_Y := 7.5
const SUN_NUM_CENTER := Vector2(184.0, 74.0)
const SHOVEL_RECT := Rect2(680.0, 6.0, 76.0, 78.0)

## 右上角控制按钮
const PAUSE_RECT := Rect2(960.0, 10.0, 42.0, 42.0)
const SOUND_RECT := Rect2(1008.0, 10.0, 42.0, 42.0)

## 右下波次进度条（原版 FlagMeter 158x24 * 1.35）
const FM_RECT := Rect2(800.0, 564.0, 213.0, 32.0)
const FM_SCALE := 1.35
const WAVE_LABEL_RIGHT := 1046.0
const WAVE_LABEL_Y := 548.0

## 割草机 / 僵尸出生点 / 家门
const MOWER_X := 141.0
const SPAWN_X := 1135.0
const HOUSE_EDGE := 125.0


static func card_rect(i: int) -> Rect2:
	var x := CARD_SLOT_X0 + float(i) * CARD_SLOT_DX + (CARD_SLOT_DX - CARD_W) * 0.5
	return Rect2(x, CARD_Y, CARD_W, CARD_H)


static func cell_center(row: int, col: int) -> Vector2:
	return Vector2(205.0 + float(col) * CELL_W, 138.0 + float(row) * CELL_H)


static func row_center(row: int) -> float:
	return 138.0 + float(row) * CELL_H


static func col_center(col: int) -> float:
	return 205.0 + float(col) * CELL_W


## 屏幕坐标 -> 格子坐标；不在草坪上时返回 (-1, -1)
static func cell_at(pos: Vector2) -> Vector2i:
	if pos.x < LAWN_LEFT or pos.y < LAWN_TOP or pos.x >= LAWN_RIGHT or pos.y >= LAWN_BOTTOM:
		return Vector2i(-1, -1)
	var col := int((pos.x - LAWN_LEFT) / CELL_W)
	var row := int((pos.y - LAWN_TOP) / CELL_H)
	if col < 0 or col >= COLS or row < 0 or row >= ROWS:
		return Vector2i(-1, -1)
	return Vector2i(col, row)
