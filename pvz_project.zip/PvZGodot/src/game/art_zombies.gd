class_name ArtZombies
extends RefCounted
## 程序化僵尸美术（原点 = 脚底中心，身体向上画到约 y=-170）
## 贴图素材到达后可整体替换；没有素材时这就是最终美术。

const SKIN := Color(0.62, 0.68, 0.52)
const SKIN_DARK := Color(0.40, 0.45, 0.31)
const SUIT := Color(0.35, 0.29, 0.42)
const SUIT_LIGHT := Color(0.45, 0.38, 0.53)
const PANTS := Color(0.26, 0.23, 0.33)
const SHIRT := Color(0.72, 0.70, 0.60)
const HAIR := Color(0.20, 0.16, 0.12)


static func draw(ci: CanvasItem, ztype: String, t: float, eating: bool, ph: float,
		slow: bool, death: float, flash: float = 0.0) -> void:
	var swing := sin(ph)
	var step := sin(ph) * 8.0
	var bob := absf(sin(ph)) * 2.2
	var breathe := sin(t * 2.3) * 1.2
	var lean := 6.0 if eating else 0.0
	# 阴影（倒地时消失）
	if death <= 0.01:
		ci.draw_colored_polygon(ArtUI.ellipse_points(Vector2(0, 2), 42, 10, 20), Color(0, 0, 0, 0.20))
	# 后腿
	_leg(ci, Vector2(-5, -44), Vector2(-5 - step, -3), PANTS.darkened(0.25), Color(0.12, 0.10, 0.08))
	# 后臂
	_arm(ci, Vector2(-12, -86), Vector2(-30, -72 + swing * 4.0), Vector2(-46, -60 + swing * 5.0), SUIT.darkened(0.3), SKIN_DARK)
	# 身体（破西装）
	_torso(ci, lean, bob)
	# 前腿
	_leg(ci, Vector2(6, -44), Vector2(6 + step, -3), PANTS, Color(0.14, 0.11, 0.09))
	# 前臂（伸向左边）
	_arm(ci, Vector2(-8, -84), Vector2(-28, -70 - swing * 3.0 + lean), Vector2(-46, -58 - swing * 4.0 + lean), SUIT_LIGHT, SKIN)
	# 头
	_head(ci, t, eating, ph, lean, bob)
	# 帽子 / 旗帜
	match ztype:
		"cone":
			_cone(ci, lean, bob)
		"bucket":
			_bucket(ci, lean, bob)
		"flag":
			_flag(ci, t, swing)
	# 受击闪白
	if flash > 0.0:
		ci.draw_colored_polygon(ArtUI.ellipse_points(Vector2(-2, -78), 40, 76, 24),
			Color(1, 1, 1, 0.22 * flash))
	# 减速冰霜
	if slow:
		for k in 3:
			var p := Vector2(-26 + k * 22, -20 - k * 10)
			ci.draw_line(p + Vector2(-5, 0), p + Vector2(5, 0), Color(0.75, 0.92, 1.0, 0.55), 2.0, true)
			ci.draw_line(p + Vector2(0, -5), p + Vector2(0, 5), Color(0.75, 0.92, 1.0, 0.55), 2.0, true)


static func _leg(ci: CanvasItem, hip: Vector2, foot: Vector2, col: Color, shoe: Color) -> void:
	var knee := (hip + foot) * 0.5 + Vector2(-2, 2)
	ci.draw_line(hip, knee, col, 13.0, true)
	ci.draw_line(knee, foot, col, 11.0, true)
	ArtUI.ellipse(ci, foot + Vector2(-4, 1), 13.0, 6.5, shoe, 14)


static func _arm(ci: CanvasItem, shoulder: Vector2, elbow: Vector2, hand: Vector2, sleeve: Color, skin: Color) -> void:
	ci.draw_line(shoulder, elbow, sleeve, 11.0, true)
	ci.draw_line(elbow, hand, sleeve, 9.5, true)
	ci.draw_line(elbow + (hand - elbow) * 0.5, hand, skin, 8.0, true)
	ci.draw_circle(hand, 7.0, skin)
	ci.draw_circle(hand + Vector2(-2, -2), 3.0, skin.lightened(0.2))


static func _torso(ci: CanvasItem, lean: float, bob: float) -> void:
	var top := Vector2(-18, -94 + bob)
	var pts := PackedVector2Array([
		top,
		Vector2(18, -94 + bob),
		Vector2(23, -70 + bob),
		Vector2(19, -58 + bob),
		Vector2(23, -46 + bob),
		Vector2(10, -50 + bob),
		Vector2(4, -42 + bob),
		Vector2(-6, -49 + bob),
		Vector2(-16, -44 + bob),
		Vector2(-15, -58 + bob),
		Vector2(-22, -66 + bob),
		Vector2(-26, -80 + bob),
	])
	for i in pts.size():
		pts[i] += Vector2(-lean * 0.35, 0)
	ci.draw_colored_polygon(pts, SUIT)
	# 衬衫
	ci.draw_colored_polygon(PackedVector2Array([
		Vector2(-8, -93 + bob), Vector2(8, -93 + bob), Vector2(10, -66 + bob), Vector2(-6, -66 + bob),
	]), SHIRT)
	# 领带
	ci.draw_colored_polygon(PackedVector2Array([
		Vector2(-1, -92 + bob), Vector2(4, -92 + bob), Vector2(3, -72 + bob), Vector2(-1, -68 + bob),
	]), Color(0.62, 0.12, 0.10))
	# 撕裂口
	ci.draw_colored_polygon(PackedVector2Array([
		Vector2(10, -72 + bob), Vector2(20, -68 + bob), Vector2(14, -58 + bob), Vector2(8, -62 + bob),
	]), SUIT.darkened(0.35))
	ci.draw_line(Vector2(-16, -60 + bob), Vector2(-8, -52 + bob), SUIT.darkened(0.3), 2.0, true)
	# 污渍
	ci.draw_circle(Vector2(-10, -66 + bob), 5.0, SUIT.darkened(0.22))
	ci.draw_circle(Vector2(12, -78 + bob), 3.5, SUIT.darkened(0.22))


static func _head(ci: CanvasItem, t: float, eating: bool, ph: float, lean: float, bob: float) -> void:
	var hc := Vector2(-3 - lean * 0.6, -118 + bob + (2.0 if eating else 0.0))
	# 脖子
	ci.draw_line(Vector2(-2, -100 + bob), hc + Vector2(0, 18), SKIN_DARK, 12.0, true)
	# 耳朵
	ci.draw_circle(hc + Vector2(22, -2), 6.5, SKIN_DARK)
	ci.draw_circle(hc + Vector2(22, -2), 4.0, SKIN)
	# 头
	ci.draw_circle(hc, 26.0, SKIN_DARK)
	ci.draw_circle(hc, 24.5, SKIN)
	# 烂掉的脸颊（右侧缺一块）
	ci.draw_colored_polygon(ArtUI.ellipse_points(hc + Vector2(14, 9), 11, 8, 14), Color(0.34, 0.28, 0.24))
	# 头发（后脑勺一撮）
	ci.draw_colored_polygon(PackedVector2Array([
		hc + Vector2(4, -24), hc + Vector2(22, -16), hc + Vector2(25, 2),
		hc + Vector2(16, -2), hc + Vector2(12, -12),
	]), HAIR)
	ci.draw_line(hc + Vector2(10, -22), hc + Vector2(4, -30), HAIR, 3.0, true)
	ci.draw_line(hc + Vector2(16, -20), hc + Vector2(14, -29), HAIR, 3.0, true)
	# 眼窝
	for ex in [-11.0, 8.0]:
		ArtUI.ellipse(ci, hc + Vector2(ex, -3), 8.5, 9.5, Color(0.26, 0.29, 0.20), 16)
		ArtUI.ellipse(ci, hc + Vector2(ex, -2), 6.5, 7.0, Color(0.94, 0.94, 0.84), 16)
		ci.draw_circle(hc + Vector2(ex - 2.0, -1.0), 3.0, Color(0.10, 0.08, 0.05))
		ci.draw_circle(hc + Vector2(ex - 3.2, -3.0), 1.1, Color(1, 1, 1, 0.9))
	# 眉毛（凶）
	ci.draw_line(hc + Vector2(-19, -14), hc + Vector2(-4, -11), HAIR, 3.0, true)
	ci.draw_line(hc + Vector2(2, -11), hc + Vector2(16, -15), HAIR, 3.0, true)
	# 鼻子
	ci.draw_colored_polygon(PackedVector2Array([
		hc + Vector2(-24, -1), hc + Vector2(-16, 2), hc + Vector2(-22, 6),
	]), SKIN_DARK)
	# 嘴（吃东西时一张一合）
	var jaw := 0.0
	if eating:
		jaw = (sin(ph * 2.6) * 0.5 + 0.5) * 7.0
	ArtUI.ellipse(ci, hc + Vector2(0, 13 + jaw * 0.3), 10.0, 4.5 + jaw * 0.5, Color(0.24, 0.12, 0.10), 16)
	for k in 4:
		ci.draw_rect(Rect2(hc + Vector2(-8.0 + float(k) * 4.6, 9.0 + jaw * 0.2), Vector2(3.0, 4.0)), Color(0.92, 0.90, 0.78))
	# 下巴
	ci.draw_line(hc + Vector2(-10, 18 + jaw * 0.5), hc + Vector2(8, 18 + jaw * 0.5), SKIN_DARK, 2.0, true)
	# 伤痕
	ci.draw_line(hc + Vector2(-18, -18), hc + Vector2(-10, -8), Color(0.45, 0.25, 0.22), 2.0, true)


static func _cone(ci: CanvasItem, lean: float, bob: float) -> void:
	var tilt := sin(bob * 0.5) * 0.05
	ci.draw_set_transform(Vector2(-5, -140 + bob), -0.12 + tilt, Vector2.ONE)
	# 锥体
	ci.draw_colored_polygon(PackedVector2Array([
		Vector2(-20, 0), Vector2(20, 0), Vector2(2, -34),
	]), Color(0.78, 0.42, 0.12))
	ci.draw_colored_polygon(PackedVector2Array([
		Vector2(-13, -6), Vector2(13, -6), Vector2(4, -33),
	]), Color(0.88, 0.53, 0.18))
	# 反光条
	ci.draw_colored_polygon(PackedVector2Array([
		Vector2(-11, -9), Vector2(11, -9), Vector2(9, -15), Vector2(-9, -15),
	]), Color(0.95, 0.94, 0.86))
	# 底座
	ArtUI.ellipse(ci, Vector2(0, 1), 23, 6, Color(0.55, 0.30, 0.08), 16)
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


static func _bucket(ci: CanvasItem, lean: float, bob: float) -> void:
	ci.draw_set_transform(Vector2(-4, -136 + bob), 0.1, Vector2.ONE)
	var r := Rect2(Vector2(-22, -30), Vector2(44, 32))
	ArtUI.rrect(ci, r.grow(1.5), 5.0, Color(0.42, 0.45, 0.48))
	ArtUI.rrect(ci, r, 4.0, Color(0.64, 0.67, 0.70))
	# 桶顶
	ArtUI.ellipse(ci, Vector2(0, -29), 22, 6, Color(0.50, 0.53, 0.56), 16)
	ArtUI.ellipse(ci, Vector2(0, -30), 18, 4.5, Color(0.72, 0.75, 0.78), 16)
	# 凹痕与反光
	ci.draw_line(Vector2(-12, -22), Vector2(-16, -2), Color(0.44, 0.47, 0.50), 2.0, true)
	ci.draw_line(Vector2(10, -24), Vector2(13, -4), Color(0.44, 0.47, 0.50), 2.0, true)
	ci.draw_line(Vector2(-15, -18), Vector2(-8, -18), Color(0.82, 0.85, 0.88, 0.7), 2.5, true)
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


static func _flag(ci: CanvasItem, t: float, swing: float) -> void:
	var hand := Vector2(-46, -58 - swing * 4.0)
	ci.draw_line(hand, hand + Vector2(4, -108), Color(0.42, 0.30, 0.18), 3.5, true)
	var top := hand + Vector2(4, -108)
	var pts := PackedVector2Array()
	for i in 8:
		var k := float(i) / 7.0
		pts.append(top + Vector2(2.0 + sin(t * 5.0 + k * 3.2) * 4.0 + k * 46.0, 2.0 + k * 6.0 - sin(k * PI) * 12.0))
	for i in range(7, -1, -1):
		var k := float(i) / 7.0
		pts.append(top + Vector2(2.0 + sin(t * 5.0 + k * 3.2) * 3.0, 34.0 + k * 7.0))
	ci.draw_colored_polygon(pts, Color(0.72, 0.13, 0.11))
	ci.draw_line(top + Vector2(2, 2), top + Vector2(46, 26), Color(0.55, 0.08, 0.06), 2.0, true)


## 菜单 / 胜利界面用的大头像（独立于身体）
static func head_portrait(ci: CanvasItem, center: Vector2, scale: float, t: float) -> void:
	ci.draw_set_transform(center, 0.0, Vector2(scale, scale))
	_head(ci, t, false, 0.0, 0.0, 0.0)
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
