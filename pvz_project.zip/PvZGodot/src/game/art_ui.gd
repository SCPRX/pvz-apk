class_name ArtUI
extends RefCounted
## 通用矢量绘制工具：椭圆/圆角矩形/文字/面板/按钮/阳光/割草机/铲子/小图标
## 所有函数都在「当前 canvas 局部坐标」里画，坐标原点由调用方决定。

## ---------- 基础几何 ----------
static func ellipse_points(center: Vector2, rx: float, ry: float, n: int = 28, rot: float = 0.0) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var cr := cos(rot)
	var sr := sin(rot)
	for i in n:
		var a := TAU * float(i) / float(n)
		var x := cos(a) * rx
		var y := sin(a) * ry
		pts.append(center + Vector2(x * cr - y * sr, x * sr + y * cr))
	return pts


static func ellipse(ci: CanvasItem, center: Vector2, rx: float, ry: float, color: Color, n: int = 28, rot: float = 0.0) -> void:
	if rx < 0.5 or ry < 0.5:
		return
	ci.draw_colored_polygon(ellipse_points(center, rx, ry, n, rot), color)


static func ellipse_outline(ci: CanvasItem, center: Vector2, rx: float, ry: float, color: Color, width: float = 3.0, n: int = 28, rot: float = 0.0) -> void:
	if rx < 0.5 or ry < 0.5:
		return
	var pts := ellipse_points(center, rx, ry, n, rot)
	pts.append(pts[0])
	ci.draw_polyline(pts, color, width, true)


static func round_rect_points(r: Rect2, radius: float, n: int = 6) -> PackedVector2Array:
	var rad := maxf(0.5, minf(radius, minf(r.size.x, r.size.y) * 0.5))
	var pts := PackedVector2Array()
	var corners := [
		[Vector2(r.position.x + rad, r.position.y + rad), PI, PI * 1.5],
		[Vector2(r.position.x + r.size.x - rad, r.position.y + rad), -PI * 0.5, 0.0],
		[Vector2(r.position.x + r.size.x - rad, r.position.y + r.size.y - rad), 0.0, PI * 0.5],
		[Vector2(r.position.x + rad, r.position.y + r.size.y - rad), PI * 0.5, PI],
	]
	for c in corners:
		var cc: Vector2 = c[0]
		var a0: float = c[1]
		var a1: float = c[2]
		for i in n + 1:
			var a := lerpf(a0, a1, float(i) / float(n))
			var p := cc + Vector2(cos(a), sin(a)) * rad
			if pts.is_empty() or pts[pts.size() - 1].distance_to(p) > 0.25:
				pts.append(p)
	return pts


static func rrect(ci: CanvasItem, r: Rect2, radius: float, color: Color) -> void:
	if r.size.x < 1.5 or r.size.y < 1.5:
		return
	ci.draw_colored_polygon(round_rect_points(r, radius), color)


static func rrect_outline(ci: CanvasItem, r: Rect2, radius: float, color: Color, width: float = 3.0) -> void:
	if r.size.x < 1.5 or r.size.y < 1.5:
		return
	var pts := round_rect_points(r, radius)
	pts.append(pts[0])
	ci.draw_polyline(pts, color, width, true)


static func leaf(ci: CanvasItem, base: Vector2, rot: float, size: float, color: Color, outline: Color = Color(0, 0, 0, 0)) -> void:
	var tip := base + Vector2(cos(rot), sin(rot)) * size
	var mid := (base + tip) * 0.5
	var side := Vector2(-sin(rot), cos(rot)) * size * 0.34
	var pts := PackedVector2Array([base, mid + side, tip, mid - side])
	if outline.a > 0.0:
		ci.draw_colored_polygon(pts, outline)
		var shrink := PackedVector2Array()
		for p in pts:
			shrink.append(mid + (p - mid) * 0.8)
		ci.draw_colored_polygon(shrink, color)
	else:
		ci.draw_colored_polygon(pts, color)
	ci.draw_line(base, tip, color.darkened(0.25), 2.0, true)


## ---------- 文字 ----------
static func text(ci: CanvasItem, pos: Vector2, s: String, size: int, color: Color,
		align: int = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	ci.draw_string(ThemeDB.fallback_font, pos, s, align, width, size, color)


static func text_outline(ci: CanvasItem, pos: Vector2, s: String, size: int, color: Color,
		outline: Color = Color(0, 0, 0, 0.65), off: float = 2.0,
		align: int = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	for i in 8:
		var a := TAU * float(i) / 8.0
		ci.draw_string(ThemeDB.fallback_font, pos + Vector2(cos(a), sin(a)) * off, s, align, width, size, outline)
	ci.draw_string(ThemeDB.fallback_font, pos, s, align, width, size, color)


static func text_right(ci: CanvasItem, right_x: float, baseline_y: float, s: String, size: int, color: Color) -> void:
	var font := ThemeDB.fallback_font
	var w := font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size).x
	ci.draw_string(font, Vector2(right_x - w, baseline_y), s, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size, color)


static func text_bold(ci: CanvasItem, pos: Vector2, s: String, size: int, color: Color,
		weight: float = 1.2, align: int = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	for dx in [-weight, 0.0, weight]:
		for dy in [-weight, 0.0, weight]:
			if dx == 0.0 and dy == 0.0:
				continue
			ci.draw_string(ThemeDB.fallback_font, pos + Vector2(dx, dy), s, align, width, size, color)
	ci.draw_string(ThemeDB.fallback_font, pos, s, align, width, size, color)


## ---------- 面板 / 按钮 ----------
static func panel(ci: CanvasItem, r: Rect2, bg: Color = Config.C_WOOD,
		border: Color = Config.C_WOOD_DARK, radius: float = 14.0) -> void:
	rrect(ci, r.grow(4.0), radius + 4.0, Color(0, 0, 0, 0.38))
	rrect(ci, r.grow(2.0), radius + 2.0, border)
	rrect(ci, r, radius, bg)
	rrect(ci, Rect2(r.position + Vector2(6.0, 4.0), Vector2(r.size.x - 12.0, 3.0)), 2.0, Color(1, 1, 1, 0.10))


static func button(ci: CanvasItem, r: Rect2, label: String, primary: bool = true,
		hovered: bool = false, size: int = 26) -> void:
	var base := Color(0.30, 0.56, 0.17) if primary else Color(0.38, 0.28, 0.16)
	if not primary:
		base = Color(0.36, 0.27, 0.16)
	if hovered:
		base = base.lightened(0.14)
	rrect(ci, Rect2(r.position + Vector2(0.0, 5.0), r.size), 14.0, Color(0, 0, 0, 0.40))
	rrect(ci, r, 14.0, base.darkened(0.35))
	rrect(ci, Rect2(r.position + Vector2(2.0, 2.0), r.size - Vector2(4.0, 4.0)), 12.0, base)
	rrect(ci, Rect2(r.position + Vector2(8.0, 4.0), Vector2(r.size.x - 16.0, 5.0)), 3.0, Color(1, 1, 1, 0.16))
	text_outline(ci, r.position + Vector2(0.0, r.size.y * 0.5 + float(size) * 0.36), label,
		size, Config.C_TEXT, Color(0, 0, 0, 0.7), 2.0, HORIZONTAL_ALIGNMENT_CENTER, r.size.x)


## ---------- 阳光 ----------
static func sun(ci: CanvasItem, center: Vector2, t: float, radius: float = 22.0, alpha: float = 1.0) -> void:
	for i in range(3, 0, -1):
		ci.draw_circle(center, radius * (1.0 + float(i) * 0.30), Color(1.0, 0.85, 0.20, 0.09 * alpha))
	for k in 12:
		var a := TAU * float(k) / 12.0 + t * 0.6
		var dir := Vector2(cos(a), sin(a))
		var ln := radius * (0.42 + 0.16 * sin(t * 3.0 + float(k) * 1.3))
		ci.draw_line(center + dir * radius * 0.98, center + dir * (radius + ln), Color(1.0, 0.92, 0.38, 0.55 * alpha), 4.0, true)
	ci.draw_circle(center, radius, Color(1.0, 0.79, 0.13, alpha))
	ci.draw_circle(center, radius * 0.84, Color(1.0, 0.90, 0.36, alpha))
	ci.draw_circle(center + Vector2(-radius * 0.26, -radius * 0.30), radius * 0.26, Color(1.0, 1.0, 0.75, 0.75 * alpha))


static func sun_icon(ci: CanvasItem, center: Vector2, radius: float) -> void:
	ci.draw_circle(center, radius * 1.25, Color(1.0, 0.85, 0.20, 0.18))
	ci.draw_circle(center, radius, Color(1.0, 0.80, 0.14))
	ci.draw_circle(center, radius * 0.82, Color(1.0, 0.90, 0.38))
	ci.draw_circle(center + Vector2(-radius * 0.22, -radius * 0.26), radius * 0.24, Color(1, 1, 0.78, 0.8))


## ---------- 割草机 ----------
static func mower(ci: CanvasItem, center: Vector2, t: float, running: bool = false) -> void:
	var shake := Vector2.ZERO
	if running:
		shake = Vector2(sin(t * 55.0) * 1.6, cos(t * 47.0) * 1.2)
	var b := center + shake
	# 刀片
	ci.draw_line(b + Vector2(-34.0, 8.0), b + Vector2(40.0, 8.0), Color(0.72, 0.75, 0.78), 4.0, true)
	for k in 5:
		ci.draw_circle(b + Vector2(-30.0 + float(k) * 17.0, 8.0), 4.0, Color(0.82, 0.85, 0.88))
	# 车身
	var body := Rect2(b + Vector2(-42.0, -28.0), Vector2(78.0, 32.0))
	rrect(ci, body, 8.0, Color(0.42, 0.10, 0.08))
	rrect(ci, Rect2(body.position + Vector2(2.0, 2.0), body.size - Vector2(4.0, 4.0)), 7.0, Color(0.76, 0.18, 0.14))
	rrect(ci, Rect2(body.position + Vector2(7.0, 4.0), Vector2(50.0, 5.0)), 3.0, Color(1.0, 0.55, 0.45, 0.45))
	# 前挡板
	ci.draw_colored_polygon(PackedVector2Array([
		b + Vector2(32.0, -20.0), b + Vector2(48.0, -4.0), b + Vector2(34.0, 8.0),
	]), Color(0.62, 0.64, 0.68))
	# 把手
	ci.draw_line(b + Vector2(-34.0, -26.0), b + Vector2(-44.0, -48.0), Color(0.38, 0.38, 0.42), 4.0, true)
	# 轮子
	for wx in [-26.0, 26.0]:
		ci.draw_circle(b + Vector2(wx, 14.0), 12.0, Color(0.11, 0.11, 0.12))
		ci.draw_circle(b + Vector2(wx, 14.0), 5.5, Color(0.56, 0.56, 0.62))
		ci.draw_circle(b + Vector2(wx, 14.0), 2.0, Color(0.85, 0.85, 0.9))


## ---------- 铲子 ----------
static func shovel_icon(ci: CanvasItem, center: Vector2, scale: float, active: bool = false) -> void:
	var c := center
	# 木柄
	ci.draw_line(c + Vector2(0.0, -26.0) * scale, c + Vector2(0.0, 8.0) * scale, Config.C_WOOD_LIGHT, 7.0 * scale, true)
	ci.draw_line(c + Vector2(0.0, -26.0) * scale, c + Vector2(0.0, 8.0) * scale, Config.C_WOOD_DARK, 3.0 * scale, true)
	# 横把手
	ci.draw_line(c + Vector2(-14.0, -27.0) * scale, c + Vector2(14.0, -27.0) * scale, Config.C_WOOD_LIGHT, 7.0 * scale, true)
	# 铲头
	var head := c + Vector2(0.0, 22.0) * scale
	ci.draw_colored_polygon(ellipse_points(head, 15.0 * scale, 19.0 * scale, 20), Color(0.55, 0.56, 0.60))
	ci.draw_colored_polygon(ellipse_points(head + Vector2(0.0, -2.0) * scale, 12.5 * scale, 15.0 * scale, 20), Color(0.74, 0.76, 0.80))
	ci.draw_line(c + Vector2(0.0, 9.0) * scale, c + Vector2(0.0, 22.0) * scale, Color(0.40, 0.41, 0.45), 3.0 * scale)
	if active:
		ci.draw_circle(head, 24.0 * scale, Color(1.0, 0.9, 0.4, 0.18))


## ---------- 顶栏小图标 ----------
static func pause_icon(ci: CanvasItem, center: Vector2, size: float, color: Color) -> void:
	ci.draw_rect(Rect2(center + Vector2(-size * 0.55, -size * 0.62), Vector2(size * 0.38, size * 1.24)), color)
	ci.draw_rect(Rect2(center + Vector2(size * 0.17, -size * 0.62), Vector2(size * 0.38, size * 1.24)), color)


static func sound_icon(ci: CanvasItem, center: Vector2, size: float, color: Color, muted: bool = false) -> void:
	var pts := PackedVector2Array([
		center + Vector2(-size * 0.7, -size * 0.26),
		center + Vector2(-size * 0.32, -size * 0.26),
		center + Vector2(size * 0.1, -size * 0.66),
		center + Vector2(size * 0.1, size * 0.66),
		center + Vector2(-size * 0.32, size * 0.26),
		center + Vector2(-size * 0.7, size * 0.26),
	])
	ci.draw_colored_polygon(pts, color)
	if muted:
		ci.draw_line(center + Vector2(size * 0.2, -size * 0.5), center + Vector2(size * 0.75, size * 0.5), Color(1.0, 0.35, 0.3), 4.0, true)
	else:
		ci.draw_arc(center + Vector2(size * 0.1, 0.0), size * 0.42, -0.9, 0.9, 12, color, 3.5, true)
		ci.draw_arc(center + Vector2(size * 0.1, 0.0), size * 0.68, -0.9, 0.9, 12, color, 3.5, true)


static func flag_icon(ci: CanvasItem, base: Vector2, h: float, color: Color, t: float = 0.0) -> void:
	ci.draw_line(base, base + Vector2(0.0, -h), Color(0.42, 0.30, 0.18), 3.0, true)
	# 三角旗（外沿随 t 轻微飘动）
	var top := base + Vector2(2.0, -h + 3.0)
	var mid := base + Vector2(2.0 + h * 0.34 + sin(t * 4.0) * 2.0, -h * 0.70)
	var bot := base + Vector2(2.0, -h * 0.48)
	ci.draw_colored_polygon(PackedVector2Array([top, mid, bot]), color)


## ---------- 种子卡小图标（程序化、不依赖贴图） ----------
static func plant_icon(ci: CanvasItem, kind: String, c: Vector2, s: float) -> void:
	match kind:
		"sunflower":
			ci.draw_line(c + Vector2(0.0, 26.0) * s, c + Vector2(0.0, 6.0) * s, Color(0.30, 0.55, 0.18), 5.0 * s, true)
			leaf(ci, c + Vector2(0.0, 20.0) * s, -2.6, 12.0 * s, Color(0.36, 0.62, 0.20))
			leaf(ci, c + Vector2(0.0, 20.0) * s, -0.5, 12.0 * s, Color(0.36, 0.62, 0.20))
			for k in 10:
				var a := TAU * float(k) / 10.0
				ellipse(ci, c + Vector2(cos(a), sin(a)) * 18.0 * s, 10.0 * s, 6.5 * s,
					Color(1.0, 0.84, 0.20), 16, a)
			ci.draw_circle(c, 13.0 * s, Color(0.47, 0.28, 0.11))
			ci.draw_circle(c, 9.5 * s, Color(0.56, 0.34, 0.14))
			ci.draw_circle(c + Vector2(-4.0, -2.0) * s, 2.2 * s, Color(0.1, 0.06, 0.03))
			ci.draw_circle(c + Vector2(4.0, -2.0) * s, 2.2 * s, Color(0.1, 0.06, 0.03))
		"peashooter", "repeater", "snowpea":
			var col := Color(0.38, 0.72, 0.25)
			var col2 := Color(0.50, 0.82, 0.33)
			if kind == "snowpea":
				col = Color(0.35, 0.66, 0.78)
				col2 = Color(0.52, 0.80, 0.90)
			ci.draw_line(c + Vector2(0.0, 30.0) * s, c + Vector2(0.0, 12.0) * s, Color(0.30, 0.55, 0.18), 5.0 * s, true)
			leaf(ci, c + Vector2(0.0, 26.0) * s, -2.6, 11.0 * s, Color(0.36, 0.62, 0.20))
			leaf(ci, c + Vector2(0.0, 26.0) * s, -0.5, 11.0 * s, Color(0.36, 0.62, 0.20))
			ci.draw_circle(c + Vector2(-2.0, -4.0) * s, 20.0 * s, col.darkened(0.3))
			ci.draw_circle(c + Vector2(-2.0, -4.0) * s, 18.0 * s, col)
			ci.draw_circle(c + Vector2(-8.0, -12.0) * s, 8.0 * s, Color(0.88, 0.97, 0.80, 0.5))
			ellipse(ci, c + Vector2(16.0, -8.0) * s, 12.0 * s, 10.0 * s, col.darkened(0.25))
			ellipse(ci, c + Vector2(16.0, -8.0) * s, 9.5 * s, 8.0 * s, col2)
			ci.draw_circle(c + Vector2(24.0, -8.0) * s, 6.5 * s, Color(0.10, 0.24, 0.08))
			ci.draw_circle(c + Vector2(-8.0, -10.0) * s, 6.0 * s, Color(1, 1, 1))
			ci.draw_circle(c + Vector2(-10.0, -10.0) * s, 3.0 * s, Color(0.05, 0.08, 0.04))
			if kind == "repeater":
				ellipse(ci, c + Vector2(16.0, 8.0) * s, 11.0 * s, 8.0 * s, col.darkened(0.25))
				ci.draw_circle(c + Vector2(24.0, 8.0) * s, 6.0 * s, Color(0.10, 0.24, 0.08))
		"wallnut":
			ellipse(ci, c + Vector2(0.0, 2.0) * s, 24.0 * s, 30.0 * s, Color(0.42, 0.24, 0.10))
			ellipse(ci, c + Vector2(0.0, 0.0) * s, 22.0 * s, 28.0 * s, Color(0.72, 0.48, 0.24))
			ellipse(ci, c + Vector2(-6.0, -8.0) * s, 10.0 * s, 12.0 * s, Color(0.80, 0.58, 0.33, 0.6))
			ci.draw_circle(c + Vector2(-9.0, -4.0) * s, 5.5 * s, Color(1, 1, 1))
			ci.draw_circle(c + Vector2(9.0, -4.0) * s, 5.5 * s, Color(1, 1, 1))
			ci.draw_circle(c + Vector2(-9.0, -3.0) * s, 2.6 * s, Color(0.12, 0.07, 0.03))
			ci.draw_circle(c + Vector2(9.0, -3.0) * s, 2.6 * s, Color(0.12, 0.07, 0.03))
			ci.draw_arc(c + Vector2(0.0, 8.0) * s, 7.0 * s, 0.3, PI - 0.3, 10, Color(0.24, 0.13, 0.05), 2.5 * s, true)
		"cherrybomb":
			ci.draw_line(c + Vector2(-8.0, -10.0) * s, c + Vector2(2.0, -30.0) * s, Color(0.30, 0.55, 0.18), 4.0 * s, true)
			ci.draw_line(c + Vector2(8.0, -8.0) * s, c + Vector2(2.0, -30.0) * s, Color(0.30, 0.55, 0.18), 4.0 * s, true)
			leaf(ci, c + Vector2(2.0, -30.0) * s, -1.2, 12.0 * s, Color(0.36, 0.62, 0.20))
			ci.draw_circle(c + Vector2(-10.0, 4.0) * s, 16.0 * s, Color(0.55, 0.08, 0.08))
			ci.draw_circle(c + Vector2(-10.0, 4.0) * s, 14.0 * s, Color(0.85, 0.18, 0.14))
			ci.draw_circle(c + Vector2(11.0, 0.0) * s, 15.0 * s, Color(0.55, 0.08, 0.08))
			ci.draw_circle(c + Vector2(11.0, 0.0) * s, 13.0 * s, Color(0.90, 0.22, 0.16))
			ci.draw_circle(c + Vector2(-14.0, -2.0) * s, 4.0 * s, Color(1.0, 0.55, 0.45, 0.7))
			ci.draw_circle(c + Vector2(14.0, -4.0) * s, 3.5 * s, Color(1.0, 0.55, 0.45, 0.7))
			for p in [Vector2(-14, 6), Vector2(-6, 6), Vector2(7, 2), Vector2(15, 2)]:
				ci.draw_circle(c + p * s, 2.0 * s, Color(0.1, 0.05, 0.03))


static func zombie_head(ci: CanvasItem, center: Vector2, r: float, col: Color = Color(0.65, 0.71, 0.55)) -> void:
	ci.draw_circle(center, r, col.darkened(0.35))
	ci.draw_circle(center, r - 1.0, col)
	ci.draw_circle(center + Vector2(-r * 0.32, -r * 0.12), r * 0.26, Color(1, 1, 1))
	ci.draw_circle(center + Vector2(r * 0.30, -r * 0.12), r * 0.22, Color(1, 1, 1))
	ci.draw_circle(center + Vector2(-r * 0.38, -r * 0.10), r * 0.11, Color(0.08, 0.06, 0.03))
	ci.draw_circle(center + Vector2(r * 0.24, -r * 0.10), r * 0.10, Color(0.08, 0.06, 0.03))
	ci.draw_line(center + Vector2(-r * 0.5, r * 0.42), center + Vector2(r * 0.45, r * 0.42), Color(0.15, 0.1, 0.08), 2.0, true)
	for k in 4:
		ci.draw_line(center + Vector2(-r * 0.42 + float(k) * r * 0.28, r * 0.42),
			center + Vector2(-r * 0.42 + float(k) * r * 0.28, r * 0.20), Color(0.95, 0.93, 0.82), 2.0, true)
