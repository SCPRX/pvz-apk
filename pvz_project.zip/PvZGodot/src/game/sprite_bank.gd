class_name SpriteBank
extends RefCounted
## 素材贴图缓存 + 绘制辅助（原版 PvZ 素材，缺失时回退程序化美术）

static var _cache: Dictionary = {}


static func tex(path_or_name: String) -> Texture2D:
	if _cache.has(path_or_name):
		return _cache[path_or_name]
	var path := path_or_name
	if not path.begins_with("res://"):
		path = "res://assets/art/" + path_or_name
		if not path.ends_with(".png") and not path.ends_with(".jpg"):
			path += ".png"
	var t: Texture2D = null
	if ResourceLoader.exists(path):
		t = load(path) as Texture2D
	_cache[path_or_name] = t
	return t


static func has_tex(path_or_name: String) -> bool:
	return tex(path_or_name) != null


## 加载一帧序列：res://assets/art/<dir>/<prefix>_0.png ... 直到缺失
static func frame_seq(dir: String, prefix: String, max_count: int = 40) -> Array:
	var out: Array = []
	for i in max_count:
		var t := tex("res://assets/art/%s/%s_%d.png" % [dir, prefix, i])
		if t == null:
			break
		out.append(t)
	return out


static func frames_at(dir: String, count: int) -> Array:
	var out: Array = []
	for i in count:
		var t := tex("res://assets/art/%s/%d.png" % [dir, i])
		if t != null:
			out.append(t)
	return out


## 以中心为锚点绘制
static func draw_center(ci: CanvasItem, path_or_name: String, center: Vector2, height: float,
		tint: Color = Color.WHITE) -> bool:
	var t := tex(path_or_name)
	if t == null:
		return false
	var s := height / float(t.get_height())
	var w := float(t.get_width()) * s
	ci.draw_texture_rect(t, Rect2(center.x - w * 0.5, center.y - height * 0.5, w, height), false, tint)
	return true


## 以左上角锚点、按原始像素尺寸绘制（scale 缩放）
static func draw_native(ci: CanvasItem, path_or_name: String, pos: Vector2, scale: float = 1.0,
		tint: Color = Color.WHITE) -> bool:
	var t := tex(path_or_name)
	if t == null:
		return false
	ci.draw_texture_rect(t, Rect2(pos, Vector2(t.get_width(), t.get_height()) * scale), false, tint)
	return true
