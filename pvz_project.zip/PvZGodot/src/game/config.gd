class_name Config
extends RefCounted
## 数值配置：植物 / 僵尸 / 波次 / 阳光经济

## ---------- 阳光经济 ----------
const START_SUN := 200.0
const SUN_CAP := 9999.0
const SUN_VALUE := 25.0
const SUNFALL_MIN := 6.0
const SUNFALL_MAX := 9.0
const SUN_LIFETIME := 13.0
const SUNFLOWER_FIRST := 5.0
const SUNFLOWER_EVERY := 16.0

## ---------- 豌豆 ----------
const PEA_SPEED := 430.0
const PEA_DAMAGE := 25.0
const PEA_SLOW_TIME := 3.0
const PEA_SLOW_FACTOR := 0.5

## ---------- 植物（顺序即种子卡顺序） ----------
const PLANTS: Array = [
	{"id": "sunflower", "name": "向日葵", "cost": 50, "hp": 300.0, "cd": 6.0, "hint": "生产阳光"},
	{"id": "peashooter", "name": "豌豆射手", "cost": 100, "hp": 300.0, "cd": 5.0, "hint": "向前发射豌豆"},
	{"id": "wallnut", "name": "坚果墙", "cost": 50, "hp": 2600.0, "cd": 20.0, "hint": "高血量，阻挡僵尸"},
	{"id": "snowpea", "name": "寒冰射手", "cost": 175, "hp": 300.0, "cd": 6.0, "hint": "豌豆减速僵尸"},
	{"id": "repeater", "name": "双发射手", "cost": 200, "hp": 300.0, "cd": 6.0, "hint": "一次发射两颗"},
	{"id": "cherrybomb", "name": "樱桃炸弹", "cost": 150, "hp": 9999.0, "cd": 22.0, "hint": "炸掉 3x3 范围"},
	{"id": "potatomine", "name": "土豆雷", "cost": 25, "hp": 300.0, "cd": 20.0, "hint": "埋下 14 秒后长成，僵尸踩中爆炸"},
	{"id": "chomper", "name": "大嘴花", "cost": 150, "hp": 300.0, "cd": 25.0, "hint": "一口吞掉僵尸，随后咀嚼 14 秒"},
]

## 射击类植物的开火间隔（秒）
const FIRE_INTERVAL := {"peashooter": 1.4, "snowpea": 1.5, "repeater": 1.4}

## ---------- 僵尸 ----------
const ZOMBIES: Dictionary = {
	"basic": {"name": "普通僵尸", "hp": 150.0, "speed": 20.0, "dps": 100.0},
	"cone": {"name": "路障僵尸", "hp": 300.0, "speed": 19.0, "dps": 100.0},
	"bucket": {"name": "铁桶僵尸", "hp": 650.0, "speed": 17.0, "dps": 110.0},
	"flag": {"name": "旗帜僵尸", "hp": 200.0, "speed": 26.0, "dps": 100.0},
}

const ZOMBIE_FEET_OFFSET := 50.0   # 僵尸脚底 = 行中心 + 50（格子底边）
const ZOMBIE_EAT_DPS := 100.0

## ---------- 波次表 ----------
## at=生成时刻（秒，从开局算），spawns=[[类型, 数量], ...]，big=大波来袭横幅，final=最后一波
const WAVES: Array = [
	{"at": 10.0, "spawns": [["basic", 1]]},
	{"at": 28.0, "spawns": [["basic", 2]]},
	{"at": 46.0, "spawns": [["basic", 2], ["cone", 1]]},
	{"at": 64.0, "spawns": [["basic", 2], ["cone", 1]]},
	{"at": 82.0, "spawns": [["basic", 3], ["cone", 1]]},
	{"at": 100.0, "big": true, "spawns": [["basic", 3], ["cone", 2]]},
	{"at": 118.0, "spawns": [["basic", 3], ["cone", 2], ["bucket", 1]]},
	{"at": 136.0, "spawns": [["basic", 4], ["cone", 2], ["bucket", 1]]},
	{"at": 154.0, "big": true, "spawns": [["basic", 4], ["cone", 2], ["bucket", 2]]},
	{"at": 174.0, "big": true, "final": true,
		"spawns": [["flag", 1], ["basic", 5], ["cone", 2], ["bucket", 2]]},
]

## ---------- 配色 ----------
const C_LAWN_A := Color(0.345, 0.616, 0.184)
const C_LAWN_B := Color(0.302, 0.557, 0.157)
const C_LAWN_EDGE := Color(0.235, 0.196, 0.105)
const C_SOIL := Color(0.355, 0.255, 0.145)
const C_WOOD := Color(0.302, 0.208, 0.114)
const C_WOOD_DARK := Color(0.192, 0.129, 0.071)
const C_WOOD_LIGHT := Color(0.412, 0.290, 0.165)
const C_TEXT := Color(1.0, 0.961, 0.827)
const C_TEXT_DIM := Color(0.827, 0.769, 0.612)
const C_GOLD := Color(1.0, 0.831, 0.231)
const C_GREEN := Color(0.408, 0.733, 0.267)
const C_RED := Color(0.855, 0.243, 0.169)
const C_PANEL := Color(0.137, 0.098, 0.055)
