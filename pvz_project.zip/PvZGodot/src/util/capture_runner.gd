extends Node
## 自动化运行器（autoload: CaptureRunner）：截图 / 定时退出 / 参数分发。
##
## 用法（Godot 用户参数写在 `--` 之后）：
##   godot --path . -- --shot=/abs/out.png --shot-frame=150
##   godot --path . -- --quit-after=4.0
## 本脚本只服务测试与自动化，不参与玩法。

var shot_path := ""
var shot_frame := 150
var quit_after_seconds := 0.0

var _frames := 0
var _elapsed := 0.0
var _captured := false


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shot="):
			shot_path = arg.substr("--shot=".length()).strip_edges()
		elif arg.begins_with("--shot-frame="):
			shot_frame = maxi(1, int(arg.substr("--shot-frame=".length())))
		elif arg.begins_with("--quit-after="):
			quit_after_seconds = maxf(0.0, float(arg.substr("--quit-after=".length())))
	if shot_path != "":
		print("[capture] armed path=", shot_path, " frame=", shot_frame)
	if quit_after_seconds > 0.0:
		print("[capture] quit after %.2fs" % quit_after_seconds)


func _process(delta: float) -> void:
	_frames += 1
	_elapsed += delta
	if quit_after_seconds > 0.0 and _elapsed >= quit_after_seconds:
		print("[capture] quit at %.2fs" % _elapsed)
		get_tree().quit()
		return
	if shot_path != "" and not _captured and _frames >= shot_frame:
		_captured = true
		_shot.call_deferred()


func _shot() -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	var err := img.save_png(shot_path)
	print("[capture] saved ", shot_path, " err=", err)
	get_tree().quit()
