class_name Sfx
extends Node
## 音效管理器：从 assets/audio/ 加载 ogg/wav/mp3，缺失时静默不报错

const NAMES := [
	"sun_collect", "plant", "shovel", "pea_shoot", "pea_hit",
	"zombie_groan", "zombie_bite", "explosion", "wave_horn", "win", "lose", "mower",
	"ui_pause", "ui_click", "seedlift", "prohibit", "finalwave", "readysetplant",
	"zombie_die", "bleep",
]

var game = null
var streams: Dictionary = {}
var players: Array = []
var music_player: AudioStreamPlayer = null
var muted := false
var silent := false


func _ready() -> void:
	for n in NAMES:
		var s := _load_any("res://assets/audio/" + n)
		if s != null:
			streams[n] = s
	for i in 8:
		var p := AudioStreamPlayer.new()
		p.volume_db = 0.0
		add_child(p)
		players.append(p)
	music_player = AudioStreamPlayer.new()
	music_player.volume_db = -15.0
	add_child(music_player)
	var music := _load_any("res://assets/audio/bgm_day")
	if music != null:
		if music is AudioStreamOggVorbis:
			music.loop = true
		elif music is AudioStreamMP3:
			music.loop = true
		elif music is AudioStreamWAV:
			music.loop_mode = AudioStreamWAV.LOOP_FORWARD
		music_player.stream = music
	print("[sfx] loaded ", streams.size(), " sounds, music=", music != null)


func _load_any(base: String) -> AudioStream:
	for ext in [".ogg", ".wav", ".mp3"]:
		var path: String = base + ext
		if ResourceLoader.exists(path):
			var r := load(path)
			if r is AudioStream:
				return r
	return null


func play(sname: String, vol_db: float = 0.0) -> void:
	if silent or muted:
		return
	var st = streams.get(sname)
	if st == null:
		return
	for p in players:
		var pl: AudioStreamPlayer = p
		if not pl.playing:
			pl.stream = st
			pl.volume_db = vol_db
			pl.play()
			return
	var first: AudioStreamPlayer = players[0]
	first.stream = st
	first.volume_db = vol_db
	first.play()


func play_music() -> void:
	if music_player == null or music_player.stream == null:
		return
	if not music_player.playing:
		music_player.play()


func set_muted(m: bool) -> void:
	muted = m
	if music_player != null:
		music_player.volume_db = -80.0 if m else -15.0
