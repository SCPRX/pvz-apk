class_name Zombie
extends Node2D
## 僵尸实体：使用原版逐帧动画（walk / attack / die / boomdie），画布 166x144、缩放 1.2

const Z_DEF := {
	"basic": {"dir": "zombies/basic", "walk": "walk", "attack": "attack", "bx": 105.5, "by": 142.0},
	"cone": {"dir": "zombies/cone", "walk": "walk", "attack": "attack", "bx": 118.5, "by": 143.0},
	"bucket": {"dir": "zombies/bucket", "walk": "walk", "attack": "attack", "bx": 98.5, "by": 144.0},
	"flag": {"dir": "zombies/flag", "walk": "walk", "attack": "attack", "bx": 111.5, "by": 141.0},
}
const Z_CANVAS := Vector2(166.0, 144.0)
const Z_SCALE := 1.2

var ztype := "basic"
var data: Dictionary = {}
var row := 0
var x := 0.0
var hp := 100.0
var max_hp := 100.0
var speed := 20.0
var dps := 100.0
var dying := false
var death_t := 0.0
var boom_die := false
var anim_t := 0.0
var walk_phase := 0.0
var attack_phase := 0.0
var eating := false
var slow_timer := 0.0
var bite_timer := 0.0
var hit_flash := 0.0
var groaned := false
var target: Plant = null

var walk_frames: Array = []
var attack_frames: Array = []
var die_frames: Array = []
var boom_frames: Array = []
var losthead_frames: Array = []
var losthead_attack_frames: Array = []
var lost_head := false
var bx := 105.5
var by := 142.0


func setup(t: String, r: int) -> void:
	ztype = t
	row = r
	data = Config.ZOMBIES[t]
	hp = float(data["hp"])
	max_hp = hp
	speed = float(data["speed"])
	dps = float(data["dps"])
	z_index = r * 10 + 2
	x = Layout.SPAWN_X
	var def: Dictionary = Z_DEF.get(ztype, Z_DEF["basic"])
	walk_frames = SpriteBank.frame_seq(str(def["dir"]), str(def["walk"]))
	attack_frames = SpriteBank.frame_seq(str(def["dir"]), str(def["attack"]))
	bx = float(def["bx"])
	by = float(def["by"])
	die_frames = SpriteBank.frame_seq("zombies/common", "die")
	boom_frames = SpriteBank.frame_seq("zombies/common", "boomdie")
	if ztype == "basic" or ztype == "flag":
		losthead_frames = SpriteBank.frame_seq(str(def["dir"]), "losthead")
		losthead_attack_frames = SpriteBank.frame_seq(str(def["dir"]), "lostheadattack")
	walk_phase = randf() * float(maxi(walk_frames.size(), 1))
	attack_phase = 0.0
	bite_timer = 0.4
	modulate = Color.WHITE
	apply_pos()


func kill(by_boom: bool = false) -> void:
	if dying:
		return
	dying = true
	death_t = 0.0
	boom_die = by_boom
	z_index = row * 10 + 3


func take_damage(dmg: float) -> void:
	if dying:
		return
	hp -= dmg
	hit_flash = 1.0
	if not lost_head and hp <= max_hp * 0.5 and not losthead_frames.is_empty():
		lost_head = true


func apply_pos() -> void:
	position = Vector2(x, Layout.row_center(row) + Config.ZOMBIE_FEET_OFFSET)


func sim_step(dt: float, g) -> void:
	anim_t += dt
	hit_flash = maxf(0.0, hit_flash - dt * 6.0)
	if dying:
		death_t += dt
		modulate = Color(1, 1, 1, clampf(2.4 - death_t * 1.6, 0.0, 1.0))
		queue_redraw()
		return
	if slow_timer > 0.0:
		slow_timer -= dt
	if target != null and (target.dead or not is_instance_valid(target)):
		target = null
	if target == null:
		target = g.find_eat_target(self)
	eating = target != null
	if eating:
		target.take_damage(dps * dt)
		attack_phase += dt
		bite_timer -= dt
		if bite_timer <= 0.0:
			bite_timer = 0.62
			g.sfx.play("zombie_bite", -8.0)
	else:
		var spd := speed
		if slow_timer > 0.0:
			spd *= Config.PEA_SLOW_FACTOR
		x -= spd * dt
		# 行走帧 5fps @ 20px/s（原版节奏）
		walk_phase += dt * 5.0 * spd / 20.0
		if not groaned and x < 1150.0:
			groaned = true
			g.sfx.play("zombie_groan", -10.0)
	apply_pos()
	queue_redraw()


func _draw() -> void:
	if dying:
		var dfr: Array = boom_frames if boom_die else die_frames
		if dfr.is_empty():
			return
		var fps_d := 10.0 if boom_die else 6.0
		var idx_d := mini(int(death_t * fps_d), dfr.size() - 1)
		_draw_frame(dfr[idx_d], Color.WHITE)
		return
	var fr: Array = attack_frames if eating else walk_frames
	if lost_head:
		if eating and not losthead_attack_frames.is_empty():
			fr = losthead_attack_frames
		elif not eating and not losthead_frames.is_empty():
			fr = losthead_frames
	if fr.is_empty():
		ArtZombies.draw(self, ztype, anim_t, eating, walk_phase, slow_timer > 0.0, 0.0, hit_flash)
		return
	var idx := 0
	if eating:
		idx = int(attack_phase * 5.0) % fr.size()
	else:
		idx = int(walk_phase) % fr.size()
	# 接地阴影
	draw_colored_polygon(ArtUI.ellipse_points(Vector2(0, 0), 42, 9, 18), Color(0, 0, 0, 0.20))
	var tint := Color.WHITE
	if slow_timer > 0.0:
		tint = Color(0.72, 0.86, 1.05)
	if hit_flash > 0.0:
		tint = tint.lerp(Color(2.0, 2.0, 2.0), hit_flash * 0.45)
	_draw_frame(fr[idx], tint)


func _draw_frame(tex: Texture2D, tint: Color) -> void:
	if tex == null:
		return
	draw_texture_rect(tex, Rect2(-bx * Z_SCALE, -by * Z_SCALE, Z_CANVAS.x * Z_SCALE, Z_CANVAS.y * Z_SCALE), false, tint)
