class_name Mower
extends Node2D
## 割草机：原版小推车贴图，僵尸越线时从草坪左侧冲出横扫整行

var row := 0
var used := false
var anim_t := 0.0
var tex: Texture2D = null


func setup(r: int) -> void:
	row = r
	position = Vector2(Layout.MOWER_X, Layout.row_center(r))
	z_index = r * 10 - 2
	anim_t = 0.0
	tex = SpriteBank.tex("ui/car.png")


func trigger() -> void:
	if used:
		return
	used = true
	z_index = row * 10 + 6


func sim_step(dt: float, g) -> void:
	anim_t += dt
	if used:
		position.x += 350.0 * dt
		if position.x > Layout.W - 40.0:
			g.remove_mower(self)
	queue_redraw()


func _draw() -> void:
	if tex != null:
		var w := float(tex.get_width())
		var h := float(tex.get_height())
		var bump := Vector2.ZERO
		if used:
			bump = Vector2(0.0, sin(anim_t * 40.0) * 1.2)
		draw_texture_rect(tex, Rect2(-w * 0.5 + bump.x, -h * 0.5 + bump.y, w, h), false)
		return
	ArtUI.mower(self, Vector2.ZERO, anim_t, used)
