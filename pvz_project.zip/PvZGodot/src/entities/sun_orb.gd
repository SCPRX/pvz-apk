class_name SunOrb
extends Node2D
## 阳光：原版太阳逐帧动画，点击后飞向种子银行左侧的阳光计数牌

const ST_FALL := 0
const ST_SIT := 1
const ST_FLY := 2
const ST_DONE := 3

var state := ST_FALL
var value := Config.SUN_VALUE
var anim_t := 0.0
var life := Config.SUN_LIFETIME
var target_y := 300.0
var vy := 0.0
var gravity := 0.0
var fly_from := Vector2.ZERO
var fly_t := 0.0
var frames: Array = []


func setup_fall(pos: Vector2, ty: float) -> void:
	position = pos
	target_y = ty
	vy = 110.0
	gravity = 40.0
	life = Config.SUN_LIFETIME
	state = ST_FALL
	z_index = 300
	anim_t = randf() * 2.0
	_load_frames()


func setup_plant(pos: Vector2) -> void:
	position = pos + Vector2(0.0, -18.0)
	target_y = pos.y + 10.0
	vy = -95.0
	gravity = 420.0
	life = 11.0
	state = ST_FALL
	z_index = 300
	anim_t = randf() * 2.0
	_load_frames()


func _load_frames() -> void:
	frames = SpriteBank.frame_seq("sun", "sun")
	if frames.is_empty():
		frames = []


func collectable() -> bool:
	return state == ST_FALL or state == ST_SIT


func collect() -> bool:
	if not collectable():
		return false
	state = ST_FLY
	fly_t = 0.0
	fly_from = position
	z_index = 400
	return true


func sim_step(dt: float, g) -> void:
	anim_t += dt
	match state:
		ST_FALL:
			position.y += vy * dt
			vy += gravity * dt
			if vy > 0.0 and position.y >= target_y:
				position.y = target_y
				state = ST_SIT
		ST_SIT:
			life -= dt
			if life <= 0.0:
				state = ST_DONE
				g.remove_sun(self, false)
		ST_FLY:
			fly_t += dt
			var k := minf(1.0, fly_t / 0.42)
			position = fly_from.lerp(g.sun_target_pos(), k * k)
			if k >= 1.0:
				state = ST_DONE
				g.finish_sun(self)
	queue_redraw()


func _draw() -> void:
	var alpha := 1.0
	if state == ST_SIT:
		alpha = clampf(life / 2.0, 0.30, 1.0)
	var size := 78.0
	if state == ST_FLY:
		size = lerpf(78.0, 46.0, minf(1.0, fly_t / 0.42))
	if frames.is_empty():
		ArtUI.sun(self, Vector2.ZERO, anim_t, size * 0.28, alpha)
		return
	var tex: Texture2D = frames[int(anim_t * 10.0) % frames.size()]
	var s := size / float(tex.get_width())
	var w := float(tex.get_width()) * s
	var h := float(tex.get_height()) * s
	draw_texture_rect(tex, Rect2(-w * 0.5, -h * 0.5, w, h), false, Color(1, 1, 1, alpha))
