class_name Plant
extends Node2D
## 植物实体：原版 PvZ 逐帧动画（向日葵摇摆 / 射手待机 / 坚果三段裂纹 / 樱桃引线）
## 素材缺失时回退到程序化美术。

const DEF := {
	"sunflower": {"dir": "plants/sunflower", "prefix": "sunflower", "fps": 8.0, "s": 1.4, "oy": 0.0},
	"peashooter": {"dir": "plants/peashooter", "prefix": "peashooter", "fps": 10.0, "s": 1.4, "oy": -12.0},
	"repeater": {"dir": "plants/repeater", "prefix": "repeater", "fps": 8.0, "s": 1.4, "oy": 0.0},
	"snowpea": {"dir": "plants/snowpea", "prefix": "snowpea", "fps": 8.0, "s": 1.4, "oy": 0.0},
	"wallnut": {"dir": "plants/wallnut", "prefix": "wallnut", "fps": 8.0, "s": 1.4, "oy": 0.0},
	"cherrybomb": {"dir": "plants/cherrybomb", "prefix": "cherrybomb", "fps": 8.0, "s": 1.4, "oy": 0.0},
	"potatomine": {"dir": "plants/potatomine", "prefix": "potatomine", "fps": 8.0, "s": 1.3, "oy": 14.0},
	"chomper": {"dir": "plants/chomper", "prefix": "chomper", "fps": 8.0, "s": 1.0, "oy": -5.0},
}

var kind := "sunflower"
var data: Dictionary = {}
var row := 0
var col := 0
var hp := 100.0
var max_hp := 100.0
var dead := false
var anim_t := 0.0
var shoot_flash := 0.0
var hit_flash := 0.0
var fire_timer := 0.0
var produce_timer := 0.0
var explode_timer := -1.0
var pop_t := 0.0

var frames: Array = []
var crack1: Array = []
var crack2: Array = []
var chomper_attack: Array = []
var chomper_digest: Array = []
var potato_init: Array = []
var armed := false
var arm_t := 14.0
var chew_t := 0.0
var digest_t := 0.0
var chomp_target: Zombie = null
var ts := 1.4
var oy := 0.0
var fps := 8.0


func setup(d: Dictionary, r: int, c: int) -> void:
	kind = str(d["id"])
	data = d
	row = r
	col = c
	hp = float(d["hp"])
	max_hp = hp
	position = Layout.cell_center(r, c)
	z_index = r * 10
	pop_t = 0.0
	scale = Vector2(0.35, 0.35)
	var def: Dictionary = DEF.get(kind, DEF["sunflower"])
	frames = SpriteBank.frame_seq(str(def["dir"]), str(def["prefix"]))
	ts = float(def["s"])
	oy = float(def["oy"])
	fps = float(def["fps"])
	if kind == "wallnut":
		crack1 = SpriteBank.frame_seq("plants/wallnut_cracked1", "wallnut_cracked1")
		crack2 = SpriteBank.frame_seq("plants/wallnut_cracked2", "wallnut_cracked2")
	elif kind == "chomper":
		chomper_attack = SpriteBank.frame_seq("plants/chomper", "chomper_attack")
		chomper_digest = SpriteBank.frame_seq("plants/chomper", "chomper_digest")
	elif kind == "potatomine":
		var ti := SpriteBank.tex("res://assets/art/plants/potatomine/potatomine_init_0.png")
		if ti != null:
			potato_init = [ti]
		armed = false
		arm_t = 14.0
	if kind == "sunflower":
		produce_timer = Config.SUNFLOWER_FIRST
	elif kind == "cherrybomb":
		explode_timer = 1.05
	elif Config.FIRE_INTERVAL.has(kind):
		fire_timer = 0.55


func sim_step(dt: float, g) -> void:
	anim_t += dt
	hit_flash = maxf(0.0, hit_flash - dt * 5.0)
	if dead:
		return
	pop_t = minf(1.0, pop_t + dt / 0.32)
	var s := _pop_scale(pop_t)
	scale = Vector2(s, s)
	shoot_flash = maxf(0.0, shoot_flash - dt * 7.0)
	if kind == "chomper":
		if digest_t > 0.0:
			digest_t = maxf(0.0, digest_t - dt)
		elif chew_t > 0.0:
			chew_t = maxf(0.0, chew_t - dt)
			if chew_t <= 0.0:
				if chomp_target != null and is_instance_valid(chomp_target) and not chomp_target.dying:
					g.chomp_kill(self, chomp_target)
				chomp_target = null
				digest_t = 14.0
		else:
			var tgt: Zombie = g.find_chomper_target(self)
			if tgt != null:
				chomp_target = tgt
				chew_t = 0.6
		queue_redraw()
		return
	if kind == "potatomine":
		if not armed:
			arm_t -= dt
			if arm_t <= 0.0:
				armed = true
		else:
			if g.find_potato_target(self) != null:
				g.potato_explode(self)
				return
		queue_redraw()
		return
	if kind == "sunflower":
		produce_timer -= dt
		if produce_timer <= 0.0:
			produce_timer = Config.SUNFLOWER_EVERY
			shoot_flash = 0.7
			g.spawn_plant_sun(self)
	elif kind == "cherrybomb":
		explode_timer -= dt
		if explode_timer <= 0.0:
			g.cherry_explode(self)
			return
	elif Config.FIRE_INTERVAL.has(kind):
		fire_timer -= dt
		if fire_timer <= 0.0:
			if g.plants_should_fire(self):
				fire_timer = float(Config.FIRE_INTERVAL[kind])
				shoot_flash = 1.0
				g.plant_shoot(self)
			else:
				fire_timer = 0.25
	queue_redraw()


func take_damage(dmg: float) -> void:
	if dead:
		return
	hp -= dmg
	hit_flash = 1.0
	if hp <= 0.0:
		dead = true
	queue_redraw()


func fuse_ratio() -> float:
	if kind != "cherrybomb":
		return 0.0
	return clampf(explode_timer / 1.05, 0.0, 1.0)


func hp_ratio() -> float:
	return clampf(hp / maxf(max_hp, 0.001), 0.0, 1.0)


func _pop_scale(p: float) -> float:
	if p >= 1.0:
		return 1.0
	var a := 1.0 - p
	return 0.35 + 0.65 * (1.0 - a * a * a)


func current_frames() -> Array:
	if kind == "wallnut":
		var hr := hp_ratio()
		if hr < 0.34 and not crack2.is_empty():
			return crack2
		if hr < 0.67 and not crack1.is_empty():
			return crack1
	return frames


func _draw() -> void:
	if dead:
		return
	if kind == "chomper":
		_draw_chomper()
		return
	if kind == "potatomine":
		_draw_potato()
		return
	var fr := current_frames()
	if fr.is_empty():
		ArtPlants.draw(self, kind, anim_t, hp_ratio(), hit_flash, fuse_ratio())
		return
	# 轻微接地阴影
	draw_colored_polygon(ArtUI.ellipse_points(Vector2(0, 50), 28, 6, 16), Color(0, 0, 0, 0.13))
	var idx := 0
	if kind == "cherrybomb":
		idx = mini(int(anim_t * fps), fr.size() - 1)
	else:
		idx = int(anim_t * fps) % fr.size()
	var tex: Texture2D = fr[idx]
	var w := float(tex.get_width()) * ts
	var h := float(tex.get_height()) * ts
	var rect := Rect2(-w * 0.5, oy - h * 0.5, w, h)
	var tint := Color.WHITE
	if hit_flash > 0.0:
		tint = tint.lerp(Color(1.9, 1.6, 1.6), hit_flash * 0.55)
	elif kind == "sunflower" and shoot_flash > 0.0:
		tint = Color(1.15, 1.1, 0.85)
	elif kind == "cherrybomb" and fuse_ratio() < 0.5:
		var k := 1.0 - fuse_ratio() / 0.5
		tint = Color(1.0 + 0.3 * k, 1.0 - 0.15 * k, 1.0 - 0.2 * k)
	draw_texture_rect(tex, rect, false, tint)


func _draw_chomper() -> void:
	draw_colored_polygon(ArtUI.ellipse_points(Vector2(0, 50), 34, 7, 16), Color(0, 0, 0, 0.16))
	var fr: Array = frames
	var idx := int(anim_t * fps) % maxi(frames.size(), 1)
	if chew_t > 0.0 and not chomper_attack.is_empty():
		var k := clampf((0.6 - chew_t) / 0.6, 0.0, 1.0)
		fr = chomper_attack
		idx = mini(int(k * float(fr.size())), fr.size() - 1)
	elif digest_t > 0.0 and not chomper_digest.is_empty():
		fr = chomper_digest
		idx = int(anim_t * fps) % fr.size()
	if fr.is_empty():
		return
	var tex: Texture2D = fr[idx]
	var w := float(tex.get_width()) * ts
	var h := float(tex.get_height()) * ts
	var tint := Color.WHITE
	if hit_flash > 0.0:
		tint = tint.lerp(Color(1.9, 1.6, 1.6), hit_flash * 0.55)
	draw_texture_rect(tex, Rect2(-w * 0.5, oy - h * 0.5, w, h), false, tint)


func _draw_potato() -> void:
	draw_colored_polygon(ArtUI.ellipse_points(Vector2(0, 50), 26, 6, 16), Color(0, 0, 0, 0.16))
	var fr: Array = frames
	var idx := int(anim_t * fps) % maxi(frames.size(), 1)
	if not armed and not potato_init.is_empty():
		fr = potato_init
		idx = 0
	if fr.is_empty():
		return
	var tex: Texture2D = fr[idx]
	var w := float(tex.get_width()) * ts
	var h := float(tex.get_height()) * ts
	var tint := Color.WHITE
	if hit_flash > 0.0:
		tint = tint.lerp(Color(1.9, 1.6, 1.6), hit_flash * 0.55)
	draw_texture_rect(tex, Rect2(-w * 0.5, oy - h * 0.5, w, h), false, tint)
