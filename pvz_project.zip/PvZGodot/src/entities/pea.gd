class_name Pea
extends Node2D
## 豌豆子弹（原版弹体帧动画）

var dmg := Config.PEA_DAMAGE
var icy := false
var row := 0
var x := 0.0
var anim_t := 0.0
var trail: Array = []
var frames: Array = []


func setup(r: int, start: Vector2, icy_shot: bool = false) -> void:
	row = r
	icy = icy_shot
	position = start
	x = start.x
	z_index = r * 10 + 4
	anim_t = 0.0
	trail.clear()
	frames = SpriteBank.frame_seq("bullets", "pea_start")
	if frames.is_empty():
		var single := SpriteBank.tex("pea")
		if single != null:
			frames = [single]


func sim_step(dt: float) -> void:
	x += Config.PEA_SPEED * dt
	position.x = x
	anim_t += dt
	trail.append(position)
	if trail.size() > 4:
		trail.pop_front()
	queue_redraw()


func _draw() -> void:
	var col := Color(0.55, 0.85, 0.35) if not icy else Color(0.68, 0.90, 1.0)
	for i in trail.size():
		var p: Vector2 = trail[i]
		var a := float(i + 1) / float(trail.size() + 1)
		draw_circle(p - position, 5.0 * a, Color(col.r, col.g, col.b, a * 0.25))
	if frames.is_empty():
		draw_circle(Vector2.ZERO, 10.0, col.darkened(0.3))
		draw_circle(Vector2.ZERO, 8.5, col)
		return
	var tex: Texture2D = frames[int(anim_t * 10.0) % frames.size()]
	var s := 2.8
	var w := float(tex.get_width()) * s
	var h := float(tex.get_height()) * s
	var tint := Color(0.72, 0.92, 1.0) if icy else Color.WHITE
	draw_texture_rect(tex, Rect2(-w * 0.5, -h * 0.5, w, h), false, tint)
