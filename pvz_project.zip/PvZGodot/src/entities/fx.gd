class_name Fx
extends Node2D
## 轻量粒子特效：豌豆溅射 / 爆炸 / 阳光收集 / 泥土 / 冰霜

var parts: Array = []
var finished := false
var anim_t := 0.0
var ring_t := 0.0
var ring_max := 0.0
var ring_col := Color(1, 0.8, 0.3, 0.6)
var ring_radius := 0.0
var gravity := 400.0
var kind := "particles"


static func splat(pos: Vector2, col: Color, n: int = 9, spd: float = 150.0) -> Fx:
	var f := Fx.new()
	f.position = pos
	f.z_index = 260
	f.gravity = 520.0
	for i in n:
		var a := randf() * TAU
		var v := Vector2(cos(a), sin(a)) * spd * randf_range(0.4, 1.1)
		f.parts.append({"p": Vector2.ZERO, "v": v, "life": 0.35, "max": 0.35,
			"size": randf_range(2.5, 5.0), "col": col})
	return f


static func boom(pos: Vector2) -> Fx:
	var f := Fx.new()
	f.kind = "boom"
	f.position = pos
	f.z_index = 270
	return f


static func explosion(pos: Vector2) -> Fx:
	var f := Fx.new()
	f.position = pos
	f.z_index = 270
	f.gravity = 240.0
	f.ring_max = 0.45
	f.ring_radius = 150.0
	f.ring_col = Color(1.0, 0.6, 0.2, 0.8)
	for i in 36:
		var a := randf() * TAU
		var v := Vector2(cos(a), sin(a)) * randf_range(120.0, 420.0)
		var cols := [Color(1.0, 0.85, 0.25), Color(1.0, 0.45, 0.12), Color(0.9, 0.2, 0.1), Color(0.3, 0.2, 0.1)]
		f.parts.append({"p": Vector2.ZERO, "v": v, "life": randf_range(0.35, 0.7),
			"max": 0.7, "size": randf_range(3.0, 9.0), "col": cols[randi() % cols.size()]})
	return f


static func sparkle(pos: Vector2) -> Fx:
	var f := Fx.new()
	f.position = pos
	f.z_index = 280
	f.gravity = -140.0
	for i in 9:
		var a := randf() * TAU
		f.parts.append({"p": Vector2.ZERO, "v": Vector2(cos(a), sin(a)) * randf_range(40.0, 130.0),
			"life": 0.5, "max": 0.5, "size": randf_range(2.5, 5.0),
			"col": Color(1.0, 0.9, 0.4) if i % 2 == 0 else Color(1.0, 0.75, 0.15)})
	return f


static func dirt(pos: Vector2) -> Fx:
	var f := Fx.new()
	f.position = pos
	f.z_index = 240
	f.gravity = 700.0
	for i in 8:
		f.parts.append({"p": Vector2(0.0, 30.0), "v": Vector2(randf_range(-90.0, 90.0), randf_range(-180.0, -60.0)),
			"life": 0.5, "max": 0.5, "size": randf_range(3.0, 6.0), "col": Color(0.36, 0.26, 0.15)})
	return f


static func frost(pos: Vector2) -> Fx:
	var f := Fx.new()
	f.position = pos
	f.z_index = 265
	f.gravity = 120.0
	for i in 7:
		f.parts.append({"p": Vector2.ZERO, "v": Vector2(randf_range(-120.0, 40.0), randf_range(-120.0, 20.0)),
			"life": 0.4, "max": 0.4, "size": randf_range(2.0, 4.0), "col": Color(0.75, 0.92, 1.0)})
	return f


func sim_step(dt: float) -> void:
	anim_t += dt
	if kind == "boom":
		finished = anim_t > 0.5
		queue_redraw()
		return
	var alive: Array = []
	for p in parts:
		p["life"] -= dt
		if p["life"] <= 0.0:
			continue
		p["p"] += p["v"] * dt
		p["v"].y += gravity * dt
		alive.append(p)
	parts = alive
	if ring_max > 0.0:
		ring_t += dt
	finished = parts.is_empty() and ring_t >= ring_max
	queue_redraw()


func _draw() -> void:
	if kind == "boom":
		var t := SpriteBank.tex("res://assets/art/ui/boom.png")
		if t != null:
			var k := clampf(anim_t / 0.5, 0.0, 1.0)
			var w := 213.0 * (0.75 + 0.85 * k)
			var h := 160.0 * (0.75 + 0.85 * k)
			draw_texture_rect(t, Rect2(-w * 0.5, -h * 0.5, w, h), false, Color(1, 1, 1, 1.0 - k * 0.8))
			return
		finished = true
		return
	if ring_max > 0.0 and ring_t < ring_max:
		var k := ring_t / ring_max
		var rr: float = ring_radius * (0.25 + k * 0.95)
		var col := ring_col
		col.a *= (1.0 - k)
		draw_arc(Vector2.ZERO, rr, 0.0, TAU, 40, col, 10.0 * (1.0 - k) + 2.0, true)
	for p in parts:
		var life: float = p["life"]
		var mx: float = p["max"]
		var a := clampf(life / mx, 0.0, 1.0)
		var c: Color = p["col"]
		draw_circle(p["p"], float(p["size"]) * (0.5 + 0.5 * a), Color(c.r, c.g, c.b, a))
