class_name Hud
extends Node2D
## 原版风格 HUD：左上种子银行 + 原版种子卡 + 铲子槽 / 右下原版 FlagMeter 波次条
## 额外：准备-好-开始（原版字图）、原版「一大波僵尸」「最后一波」横幅

var game = null
var mouse_pos := Vector2.ZERO
var hover_cell := Vector2i(-1, -1)
var deny_i := -1
var deny_t := 0.0
var _t := 0.0

const CARD_TEX := {
	"sunflower": "res://assets/art/cards/card_sunflower.png",
	"peashooter": "res://assets/art/cards/card_peashooter.png",
	"wallnut": "res://assets/art/cards/card_wallnut.png",
	"snowpea": "res://assets/art/cards/card_snowpea.png",
	"repeater": "res://assets/art/cards/card_repeaterpea.png",
	"cherrybomb": "res://assets/art/cards/card_cherrybomb.png",
	"potatomine": "res://assets/art/cards/card_potatomine.png",
	"chomper": "res://assets/art/cards/card_chomper.png",
}


func flash_deny(i: int) -> void:
	deny_i = i
	deny_t = 0.5


## 返回被点中的植物全局索引（按当前卡槽映射），没有则 -1
func card_at(pos: Vector2) -> int:
	if game == null:
		return -1
	var cards: Array = game.active_cards
	for slot in cards.size():
		if Layout.card_rect(slot).grow(4.0).has_point(pos):
			return int(cards[slot])
	return -1


func _draw() -> void:
	if game == null:
		return
	_t += 0.016
	deny_t = maxf(0.0, deny_t - 0.016)
	_draw_bank()
	_draw_cards()
	_draw_shovel()
	_draw_buttons()
	_draw_wave_bar()
	_draw_hover_cell()
	_draw_tooltip()
	_draw_hints()
	_draw_intro()
	_draw_banner()


## ---------------- 种子银行 ----------------
func _draw_bank() -> void:
	if not SpriteBank.draw_native(self, "res://assets/art/ui/seedbank.png", Layout.BANK_POS, 1.0):
		ArtUI.rrect(self, Rect2(Layout.BANK_POS, Vector2(Layout.BANK_W, Layout.BANK_H)), 10.0, Config.C_WOOD)
	# 阳光数（原版计分牌位置）
	var txt := str(int(game.sun))
	var flash := clampf(game.sun_flash, 0.0, 1.0)
	var col := Color(0.16, 0.10, 0.03)
	if flash > 0.0:
		col = col.lerp(Color(0.55, 0.30, 0.02), flash * 0.6)
	# 原版白色阳光计数小牌
	var pr := Rect2(Layout.SUN_NUM_CENTER.x - 33.0, Layout.SUN_NUM_CENTER.y - 17.0, 66.0, 23.0)
	ArtUI.rrect(self, pr, 4.0, Color(0.99, 0.96, 0.86))
	ArtUI.rrect_outline(self, pr, 4.0, Color(0.55, 0.42, 0.22), 2.0)
	ArtUI.text_bold(self, Vector2(pr.position.x, pr.position.y + 18.0),
		txt, 20, col, 0.9, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x)


func _draw_cards() -> void:
	var cards: Array = game.active_cards
	for slot in cards.size():
		var idx: int = int(cards[slot])
		var d: Dictionary = Config.PLANTS[idx]
		var kind := str(d["id"])
		var rect: Rect2 = Layout.card_rect(slot)
		var selected: bool = game.selected == idx
		var ready: bool = game.cooldowns[idx] <= 0.0
		var afford: bool = game.sun >= float(d["cost"])
		if selected:
			rect.position.y -= 4.0
		var tex := SpriteBank.tex(CARD_TEX.get(kind, ""))
		var tint := Color.WHITE
		if not ready or not afford:
			tint = Color(0.70, 0.70, 0.70)
		if tex != null:
			draw_texture_rect(tex, rect, false, tint)
		else:
			ArtUI.rrect(self, rect, 6.0, Color(0.85, 0.79, 0.62))
			ArtUI.plant_icon(self, kind, rect.get_center(), 0.45)
		if not ready:
			var cd: float = game.cooldowns[idx]
			var total: float = maxf(float(d["cd"]), 0.001)
			var k := clampf(cd / total, 0.0, 1.0)
			ArtUI.rrect(self, rect, 4.0, Color(0.02, 0.02, 0.04, 0.55))
			var h := rect.size.y * k
			ArtUI.rrect(self, Rect2(rect.position.x, rect.position.y + rect.size.y - h, rect.size.x, h),
				4.0, Color(0.05, 0.05, 0.08, 0.55))
			draw_rect(Rect2(rect.position.x + 2.0, rect.position.y + rect.size.y - h - 2.0,
				rect.size.x - 4.0, 2.0), Color(1.0, 0.9, 0.45, 0.9))
		if not afford and ready:
			ArtUI.rrect(self, rect, 4.0, Color(0.03, 0.03, 0.05, 0.30))
		if selected:
			ArtUI.rrect_outline(self, rect.grow(3.0), 6.0, Color(1.0, 0.88, 0.35, 0.95), 3.0)
		elif Layout.card_rect(slot).grow(4.0).has_point(mouse_pos):
			ArtUI.rrect_outline(self, Layout.card_rect(slot), 4.0, Color(1, 1, 0.85, 0.65), 2.0)
		if deny_i == idx and deny_t > 0.0:
			ArtUI.rrect(self, rect, 4.0, Color(1.0, 0.15, 0.1, deny_t * 0.55))


func _draw_shovel() -> void:
	var r: Rect2 = Layout.SHOVEL_RECT
	var hov := r.has_point(mouse_pos)
	# 铲子木底板
	ArtUI.rrect(self, Rect2(676.0, 8.0, 84.0, 74.0), 8.0, Color(0.28, 0.18, 0.09))
	ArtUI.rrect_outline(self, Rect2(676.0, 8.0, 84.0, 74.0), 8.0, Color(0.50, 0.36, 0.18), 2.0)
	# 原版铲子槽底图（原生 71x35，放在槽位下方）
	var sb := SpriteBank.tex("res://assets/art/ui2/shovelback.png")
	if sb != null:
		var sw := float(sb.get_width())
		var sh := float(sb.get_height())
		draw_texture_rect(sb, Rect2(r.get_center().x - sw * 0.5, r.position.y + r.size.y - sh - 2.0, sw, sh), false)
	if game.shovel:
		ArtUI.rrect(self, r, 8.0, Color(1.0, 0.85, 0.3, 0.20))
		ArtUI.rrect_outline(self, r, 8.0, Color(1.0, 0.90, 0.40, 0.95), 2.5)
	elif hov:
		ArtUI.rrect_outline(self, r, 8.0, Color(1, 1, 0.85, 0.5), 2.0)
	var tex := SpriteBank.tex("res://assets/art/shovel.png")
	if tex != null:
		var h := 46.0
		var sc := h / float(tex.get_height())
		var w := float(tex.get_width()) * sc
		draw_texture_rect(tex, Rect2(r.get_center().x - w * 0.5, r.position.y + 4.0, w, h),
			false, Color(1, 1, 1, 0.95))
	else:
		ArtUI.shovel_icon(self, r.get_center(), 0.9, game.shovel)


func _draw_buttons() -> void:
	var pr: Rect2 = Layout.PAUSE_RECT
	var hs := pr.has_point(mouse_pos)
	ArtUI.rrect(self, pr, 9.0, Color(0.09, 0.06, 0.03, 0.55))
	ArtUI.rrect(self, pr.grow(-2.0), 8.0, Color(0.42, 0.30, 0.16, 0.9) if not hs else Color(0.55, 0.40, 0.22, 0.95))
	ArtUI.pause_icon(self, pr.get_center(), 11.0, Config.C_TEXT)
	var sr: Rect2 = Layout.SOUND_RECT
	var hs2 := sr.has_point(mouse_pos)
	ArtUI.rrect(self, sr, 9.0, Color(0.09, 0.06, 0.03, 0.55))
	ArtUI.rrect(self, sr.grow(-2.0), 8.0, Color(0.42, 0.30, 0.16, 0.9) if not hs2 else Color(0.55, 0.40, 0.22, 0.95))
	ArtUI.sound_icon(self, sr.get_center(), 10.0, Config.C_TEXT, bool(game.muted))


## ---------------- 原版 FlagMeter 波次条 ----------------
func _draw_wave_bar() -> void:
	var total: int = Config.WAVES.size()
	var r: Rect2 = Layout.FM_RECT
	var progress := clampf(float(game.wave_idx) / float(total), 0.0, 1.0)
	var empty := SpriteBank.tex("res://assets/art/ui2/fm_flagmeterempty.png")
	var full := SpriteBank.tex("res://assets/art/ui2/fm_flagmeterfull.png")
	if empty != null:
		draw_texture_rect(empty, r, false)
	else:
		ArtUI.rrect(self, r, 8.0, Color(0.10, 0.09, 0.05, 0.9))
	if full != null and progress > 0.01:
		var src_w := 158.0 * progress
		draw_texture_rect_region(full, Rect2(r.position, Vector2(r.size.x * progress, r.size.y)),
			Rect2(0, 0, src_w, 24.0))
	# 大波红旗
	var flag := SpriteBank.tex("res://assets/art/ui2/fm_flagmeterparts2.png")
	if flag != null:
		for i in total:
			var w: Dictionary = Config.WAVES[i]
			if w.get("big", false):
				var fx := r.position.x + r.size.x * (float(i) / float(total))
				var fw := 20.0 * Layout.FM_SCALE
				var fh := 18.0 * Layout.FM_SCALE
				draw_texture_rect(flag, Rect2(fx - fw * 0.5, r.position.y - 4.0, fw, fh), false)
	# 僵尸头进度标记
	var head := SpriteBank.tex("res://assets/art/ui2/fm_flagmeterparts1.png")
	var hx := r.position.x + r.size.x * progress
	if head != null:
		var hw := 24.0 * Layout.FM_SCALE
		var hh := 24.0 * Layout.FM_SCALE
		draw_texture_rect(head, Rect2(hx - hw * 0.5, r.position.y - hh + 6.0, hw, hh), false)
	else:
		ArtUI.zombie_head(self, Vector2(hx, r.position.y - 10.0), 9.5)
	# 原版没有波次文字，保持画面干净


## ---------------- 草坪交互提示 ----------------
func _draw_hover_cell() -> void:
	if game.selected < 0 and not game.shovel:
		return
	if hover_cell.x < 0:
		return
	var r := Rect2(
		Layout.LAWN_LEFT + float(hover_cell.x) * Layout.CELL_W + 2.0,
		Layout.LAWN_TOP + float(hover_cell.y) * Layout.CELL_H + 3.0,
		Layout.CELL_W - 4.0, Layout.CELL_H - 6.0
	)
	if game.shovel:
		var has_plant: bool = game.grid[hover_cell.y][hover_cell.x] != null
		ArtUI.rrect(self, r, 8.0, Color(1.0, 0.3, 0.2, 0.18 if has_plant else 0.08))
		if has_plant:
			ArtUI.rrect_outline(self, r, 8.0, Color(1.0, 0.45, 0.3, 0.7), 2.0)
		return
	var occupied: bool = game.grid[hover_cell.y][hover_cell.x] != null
	var d: Dictionary = Config.PLANTS[game.selected]
	var afford: bool = game.sun >= float(d["cost"]) and game.cooldowns[game.selected] <= 0.0
	if occupied or not afford:
		ArtUI.rrect(self, r, 8.0, Color(1.0, 0.25, 0.2, 0.14))
		ArtUI.rrect_outline(self, r, 8.0, Color(1.0, 0.4, 0.3, 0.5), 2.0)
	else:
		ArtUI.rrect(self, r, 8.0, Color(0.55, 1.0, 0.45, 0.14))
		ArtUI.rrect_outline(self, r, 8.0, Color(0.75, 1.0, 0.6, 0.55), 2.0)
		var ghost := SpriteBank.tex("res://assets/art/plants/%s/%s_0.png" % [str(d["id"]), str(d["id"])])
		if ghost != null:
			var h := 92.0
			var sc := h / float(ghost.get_height())
			var w := float(ghost.get_width()) * sc
			var anchor := Vector2(r.get_center().x, r.position.y + r.size.y + 4.0)
			draw_texture_rect(ghost, Rect2(anchor.x - w * 0.5, anchor.y - h, w, h), false, Color(1, 1, 1, 0.5))


func _draw_tooltip() -> void:
	var idx := card_at(mouse_pos)
	if idx < 0 or game.selected == idx:
		return
	var d: Dictionary = Config.PLANTS[idx]
	var slot: int = game.active_cards.find(idx)
	if slot < 0:
		return
	var rect: Rect2 = Layout.card_rect(slot)
	var w := 250.0
	var x := clampf(rect.position.x - 20.0, 6.0, Layout.W - w - 6.0)
	var tr := Rect2(x, Layout.BANK_POS.y + Layout.BANK_H + 4.0, w, 60.0)
	ArtUI.rrect(self, tr.grow(2.0), 10.0, Color(0, 0, 0, 0.5))
	ArtUI.rrect(self, tr, 8.0, Color(0.16, 0.11, 0.06, 0.95))
	ArtUI.rrect_outline(self, tr, 8.0, Color(0.55, 0.40, 0.19), 2.0)
	ArtUI.text_bold(self, tr.position + Vector2(10, 22), str(d["name"]), 18, Config.C_TEXT, 0.8)
	ArtUI.sun_icon(self, tr.position + Vector2(w - 66.0, 16.0), 7.5)
	ArtUI.text_right(self, tr.position.x + w - 12.0, tr.position.y + 22.0, str(int(d["cost"])), 16, Config.C_GOLD)
	ArtUI.text(self, tr.position + Vector2(10, 44), str(d["hint"]), 14, Config.C_TEXT_DIM)


func _draw_hints() -> void:
	ArtUI.text(self, Vector2(8.0, Layout.H - 8.0),
		"左键收集阳光 / 选卡后点草坪种植 / 铲子移除植物 / 空格暂停", 13,
		Color(1, 1, 1, 0.42))


## ---------------- 准备-好-开始（原版字图） ----------------
func _draw_intro() -> void:
	if game.intro_t <= 0.0 or game.intro_t >= 1.95:
		return
	var stage := 0
	if game.intro_t > 0.55:
		stage = 1
	if game.intro_t > 1.05:
		stage = 2
	var tex := SpriteBank.tex("res://assets/art/ui2/ready_%d.png" % stage)
	if tex == null:
		return
	var sc := 1.5
	var w := float(tex.get_width()) * sc
	var h := float(tex.get_height()) * sc
	var a := 1.0
	if game.intro_t > 1.72:
		a = clampf((1.95 - game.intro_t) / 0.23, 0.0, 1.0)
	draw_texture_rect(tex, Rect2((Layout.W - w) * 0.5, (Layout.H - h) * 0.5 - 20.0, w, h),
		false, Color(1, 1, 1, a))


## ---------------- 横幅（原版字图优先） ----------------
func _draw_banner() -> void:
	if game.banner_t <= 0.0:
		return
	var bt: float = game.banner_t
	var k: float = bt / 2.8
	var appear: float = clampf((1.0 - k) / 0.18, 0.0, 1.0)
	var alpha: float = clampf(bt / 0.5, 0.0, 1.0) * appear
	var slide: float = (1.0 - appear) * 220.0
	var cx := Layout.W * 0.5 - slide
	var kind := str(game.banner_kind)
	if kind == "largewave":
		var te := SpriteBank.tex("res://assets/art/ui2/largewave.png")
		if te != null:
			var sc := 2.2
			var w := float(te.get_width()) * sc
			var h := float(te.get_height()) * sc
			draw_texture_rect(te, Rect2(cx - w * 0.5, 132.0, w, h), false, Color(1, 1, 1, alpha))
			return
	elif kind == "finalwave":
		var te := SpriteBank.tex("res://assets/art/ui2/finalwave.png")
		if te != null:
			var sc := 2.0
			var w := float(te.get_width()) * sc
			var h := float(te.get_height()) * sc
			draw_texture_rect(te, Rect2(cx - w * 0.5, 100.0, w, h), false, Color(1, 1, 1, alpha))
			return
	# 文字横幅兜底
	var center := Vector2(cx, 150.0)
	var rect := Rect2(center.x - 330.0, center.y - 34.0, 660.0, 68.0)
	ArtUI.rrect(self, rect.grow(4.0), 14.0, Color(0.10, 0.03, 0.02, 0.72 * alpha))
	ArtUI.rrect(self, rect, 12.0, Color(0.42, 0.08, 0.06, 0.86 * alpha))
	ArtUI.rrect_outline(self, rect, 12.0, Color(1.0, 0.72, 0.25, 0.9 * alpha), 3.0)
	ArtUI.text_outline(self, Vector2(rect.position.x, center.y + 15.0), game.banner_text, 36,
		Color(1.0, 0.93, 0.72, alpha), Color(0.15, 0.02, 0.01, alpha), 2.0,
		HORIZONTAL_ALIGNMENT_CENTER, rect.size.x)
