class_name Screens
extends Node2D
## 开始菜单 / 选卡（原版 SeedChooser 面板，8 卡）/ 暂停（原版墓碑菜单）/ 胜利 / 失败
## 设计分辨率 1066x600（对齐 B 站原版复刻实机的取景比例）

var game = null
var mouse_pos := Vector2.ZERO
var sname := ""
var buttons: Array = []
var _anim := 0.0
var _t := 0.0
var toast_text := ""
var toast_t := 0.0
var help_visible := false

## 选卡面板几何（原版 SeedChooser_Background 465x540 缩放 0.86）
const CHOOSER_PANEL := Rect2(333.0, 18.0, 400.0, 464.0)
const CHOOSER_CARD_W := 64.0
const CHOOSER_CARD_H := 90.0

const CARD_TEX := {
	"sunflower": "res://assets/art/cards/card_sunflower.png",
	"peashooter": "res://assets/art/cards/card_peashooter.png",
	"wallnut": "res://assets/art/cards/card_wallnut.png",
	"snowpea": "res://assets/art/cards/card_snowpea.png",
	"repeater": "res://assets/art/cards/card_repeaterpea.png",
	"cherrybomb": "res://assets/art/cards/card_cherrybomb.png",
	"potatomine": "res://assets/art/cards/card_potatomine.png",
	"chomper": "res://assets/art/cards/card_chomper.png",
}


func set_state(n: String) -> void:
	sname = n
	_anim = 0.0
	buttons.clear()
	match n:
		"menu":
			buttons = [
				{"rect": Rect2(640, 128, 330, 68), "action": "start", "label": "开始冒险吧", "style": "stone", "size": 27},
				{"rect": Rect2(640, 213, 330, 68), "action": "toast|玩玩小游戏：复刻版未实现该模式",
					"label": "玩玩小游戏", "style": "stone", "size": 25, "disabled": true},
				{"rect": Rect2(640, 298, 330, 68), "action": "toast|解密模式：复刻版未实现该模式",
					"label": "解密模式", "style": "stone", "size": 25, "disabled": true},
				{"rect": Rect2(640, 383, 330, 68), "action": "toast|生存模式：复刻版未实现该模式",
					"label": "生存模式", "style": "stone", "size": 25, "disabled": true},
				{"rect": Rect2(250, 540, 120, 42), "action": "auto", "label": "自动演示", "size": 16},
				{"rect": Rect2(378, 540, 120, 42), "action": "toast|图鉴：复刻版未实现", "label": "图鉴", "size": 16},
				{"rect": Rect2(506, 540, 120, 42), "action": "toast|商店：复刻版未实现", "label": "商店", "size": 16},
				{"rect": Rect2(634, 540, 120, 42), "action": "mute", "label": "选项", "size": 16},
				{"rect": Rect2(762, 540, 120, 42), "action": "help", "label": "帮助", "size": 16},
				{"rect": Rect2(890, 540, 120, 42), "action": "toast|退出：请关闭窗口或按 F11 退出全屏",
					"label": "退出", "size": 16},
			]
		"chooser":
			buttons = [
				{"rect": Rect2(393, 496, 280, 64), "action": "start_choose", "style": "texture",
					"tex": "res://assets/art/ui/start_button.png"},
				{"rect": Rect2(20, 548, 130, 40), "action": "menu", "label": "返回菜单", "size": 17},
			]
		"pause":
			buttons = [
				{"rect": Rect2(478, 250, 220, 66), "action": "resume", "label": "继续游戏", "style": "stone", "size": 24},
				{"rect": Rect2(478, 335, 220, 66), "action": "restart", "label": "重新开始", "style": "stone", "size": 24},
				{"rect": Rect2(478, 420, 220, 66), "action": "menu", "label": "返回菜单", "style": "stone", "size": 24},
				{"rect": Rect2(18, 540, 130, 42), "action": "mute", "label": "音效开关", "size": 16},
			]
		"win":
			buttons = [
				{"rect": Rect2(293, 430, 220, 52), "action": "again", "label": "再玩一次", "primary": true, "size": 21},
				{"rect": Rect2(553, 430, 220, 52), "action": "menu", "label": "返回主菜单", "primary": false, "size": 21},
			]
		"lose":
			buttons = [
				{"rect": Rect2(331, 486, 190, 50), "action": "retry", "label": "再试一次", "primary": true, "size": 20},
				{"rect": Rect2(545, 486, 190, 50), "action": "menu", "label": "返回主菜单", "primary": false, "size": 20},
			]


func hit(pos: Vector2) -> String:
	for b in buttons:
		var r: Rect2 = b["rect"]
		if r.has_point(pos):
			return str(b["action"])
	return ""


func toast(t: String) -> void:
	toast_text = t
	toast_t = 2.2


## 选卡：返回植物全局索引（按 Config 顺序），未命中 -1
func chooser_card_at(pos: Vector2) -> int:
	var rects := chooser_card_rects()
	for i in rects.size():
		if rects[i].has_point(pos):
			return i
	return -1


func chooser_card_rects() -> Array:
	var out: Array = []
	var grid := Rect2(362.0, 97.0, 342.0, 365.0)
	var cols := 4
	var rows := 2
	var gapx := (grid.size.x - float(cols) * CHOOSER_CARD_W) / float(cols + 1)
	var gapy := (grid.size.y - float(rows) * CHOOSER_CARD_H) / float(rows + 1)
	for i in cols * rows:
		var c := i % cols
		var r := i / cols
		out.append(Rect2(
			grid.position.x + gapx + float(c) * (CHOOSER_CARD_W + gapx),
			grid.position.y + gapy + float(r) * (CHOOSER_CARD_H + gapy),
			CHOOSER_CARD_W, CHOOSER_CARD_H))
	return out


func _draw() -> void:
	if game == null:
		return
	_anim += 0.016
	_t += 0.016
	toast_t = maxf(0.0, toast_t - 0.016)
	if help_visible:
		_draw_help()
		return
	match sname:
		"menu":
			_draw_menu()
		"chooser":
			_draw_chooser()
		"pause":
			_draw_pause()
		"win":
			_draw_win()
		"lose":
			_draw_lose()
	if toast_t > 0.0:
		_draw_toast()


func _fade() -> float:
	return clampf(_anim / 0.25, 0.0, 1.0)


func _draw_buttons() -> void:
	for b in buttons:
		var r: Rect2 = b["rect"]
		var style := str(b.get("style", "wood"))
		var disabled := bool(b.get("disabled", false))
		var hov := r.has_point(mouse_pos) and not disabled
		if style == "stone":
			var t := SpriteBank.tex("res://assets/art/ui2/pausebtn_a.png")
			if t != null:
				draw_texture_rect(t, r, false, Color(1, 1, 1) if not disabled else Color(0.72, 0.72, 0.78))
			else:
				ArtUI.rrect(self, r, 8.0, Color(0.44, 0.45, 0.55))
			if hov:
				ArtUI.rrect(self, r, 6.0, Color(1, 1, 1, 0.10))
			var fs := int(b.get("size", 26))
			ArtUI.text_outline(self, Vector2(r.position.x, r.position.y + r.size.y * 0.5 + float(fs) * 0.36),
				str(b["label"]), fs,
				Color(0.96, 0.97, 1.0) if not disabled else Color(0.60, 0.62, 0.70),
				Color(0.12, 0.12, 0.20), 2.0, HORIZONTAL_ALIGNMENT_CENTER, r.size.x)
		elif style == "texture":
			var t := SpriteBank.tex(str(b["tex"]))
			if t != null:
				if hov:
					ArtUI.rrect(self, r.grow(4.0), 12.0, Color(1.0, 0.9, 0.4, 0.28))
				draw_texture_rect(t, r, false, Color(1.12, 1.12, 1.05) if hov else Color.WHITE)
		else:
			ArtUI.button(self, r, str(b["label"]), bool(b.get("primary", false)), hov, int(b.get("size", 20)))


## ---------------- 开始菜单 ----------------
func _draw_menu() -> void:
	draw_rect(Rect2(0, 0, Layout.W, Layout.H), Color(0.04, 0.07, 0.03))
	var t := SpriteBank.tex("res://assets/art/ui/mainmenu.png")
	if t != null:
		# 900x600 原版主菜单图裁成 16:9 铺满 1066x600
		draw_texture_rect_region(t, Rect2(0, 0, Layout.W, Layout.H), Rect2(0, 47, 900, 507))
	for i in 8:
		draw_rect(Rect2(0, float(i) * 18.0, Layout.W, 18.0),
			Color(0.01, 0.03, 0.01, 0.14 * float(8 - i) / 8.0))
	_draw_wood_sign(Rect2(30, 96, 340, 216))
	ArtUI.text_bold(self, Vector2(48, 145), "植物大战僵尸", 30, Color(0.98, 0.86, 0.42), 1.1)
	ArtUI.text(self, Vector2(50, 170), "草坪保卫战 · Godot 复刻版", 15, Color(0.94, 0.90, 0.78))
	ArtUI.text(self, Vector2(50, 206), "存档：Player", 18, Color(0.97, 0.93, 0.80))
	ArtUI.text(self, Vector2(50, 232), "欢迎回来，我的邻居！", 15, Color(0.90, 0.86, 0.72))
	ArtUI.text(self, Vector2(50, 262), "如果这不是你的存档，点「开始冒险吧」", 12, Color(0.82, 0.78, 0.64, 0.9))
	ArtUI.text(self, Vector2(50, 282), "原版流程：选卡 → 准备-好-开始 → 守住草坪", 12, Color(0.82, 0.78, 0.64, 0.9))
	_draw_buttons()
	ArtUI.text(self, Vector2(0, 594), "Godot 4.4 复刻 · 原版场景/素材/动画/流程 · 仅供个人学习交流", 12,
		Color(0.74, 0.72, 0.60, 0.85), HORIZONTAL_ALIGNMENT_CENTER, Layout.W)


func _draw_wood_sign(r: Rect2) -> void:
	ArtUI.rrect(self, r.grow(5.0), 14.0, Color(0, 0, 0, 0.45))
	ArtUI.rrect(self, r.grow(2.0), 12.0, Color(0.24, 0.15, 0.07))
	ArtUI.rrect(self, r, 10.0, Color(0.42, 0.29, 0.15))
	for i in 6:
		draw_line(Vector2(r.position.x + 6.0, r.position.y + 14.0 + float(i) * r.size.y / 6.0),
			Vector2(r.position.x + r.size.x - 6.0, r.position.y + 10.0 + float(i) * r.size.y / 6.0),
			Color(0.30, 0.20, 0.10, 0.5), 2.0)
	ArtUI.rrect_outline(self, r, 10.0, Color(0.62, 0.46, 0.24), 3.0)
	ArtUI.rrect(self, Rect2(r.position.x + 10.0, r.position.y + 6.0, r.size.x - 20.0, 4.0),
		2.0, Color(1, 1, 1, 0.10))


## ---------------- 选卡（8 张） ----------------
func _draw_chooser() -> void:
	draw_rect(Rect2(0, 0, Layout.W, Layout.H), Color(0.02, 0.03, 0.02, 0.50))
	var panel := SpriteBank.tex("res://assets/art/ui2/seedchooser.png")
	if panel != null:
		draw_texture_rect(panel, CHOOSER_PANEL, false)
	else:
		ArtUI.panel(self, CHOOSER_PANEL, Color(0.34, 0.18, 0.08), Config.C_WOOD_DARK, 14.0)
	var chosen: Array = game.chosen
	var rects := chooser_card_rects()
	for i in rects.size():
		if i >= Config.PLANTS.size():
			break
		var d: Dictionary = Config.PLANTS[i]
		var rect: Rect2 = rects[i]
		var selected: bool = i in chosen
		var tex := SpriteBank.tex(CARD_TEX.get(str(d["id"]), ""))
		if selected:
			ArtUI.rrect(self, rect.grow(4.0), 8.0, Color(1.0, 0.85, 0.3, 0.45))
		if tex != null:
			draw_texture_rect(tex, rect, false, Color.WHITE if selected else Color(0.42, 0.42, 0.45))
		else:
			ArtUI.rrect(self, rect, 6.0, Color(0.8, 0.75, 0.6) if selected else Color(0.4, 0.38, 0.34))
			ArtUI.plant_icon(self, str(d["id"]), rect.get_center(), 0.5)
		ArtUI.text_outline(self, Vector2(rect.position.x, rect.position.y + rect.size.y + 15.0),
			str(d["name"]), 13, Config.C_TEXT, Color(0.05, 0.02, 0.0), 2.0,
			HORIZONTAL_ALIGNMENT_CENTER, rect.size.x)
		if rect.grow(4.0).has_point(mouse_pos):
			ArtUI.rrect_outline(self, rect, 7.0, Color(1, 1, 0.85, 0.8), 2.0)
	ArtUI.text(self, Vector2(0, 472), "已选择 %d / 8 张卡（点击卡片切换）" % chosen.size(), 16,
		Color(0.95, 0.88, 0.62), HORIZONTAL_ALIGNMENT_CENTER, Layout.W)
	_draw_buttons()


## ---------------- 暂停（原版墓碑菜单） ----------------
func _draw_pause() -> void:
	draw_rect(Rect2(0, 0, Layout.W, Layout.H), Color(0.02, 0.03, 0.02, 0.55 * _fade()))
	var m := SpriteBank.tex("res://assets/art/ui2/pausemenu.png")
	var p := Vector2((Layout.W - 412.0) * 0.5, (Layout.H - 483.0) * 0.5)
	if m != null:
		draw_texture_rect(m, Rect2(p, Vector2(412, 483)), false)
	else:
		ArtUI.panel(self, Rect2(p, Vector2(412, 483)), Color(0.22, 0.15, 0.08), Color(0.55, 0.40, 0.19), 18.0)
	_draw_buttons()


## ---------------- 胜利 ----------------
func _draw_win() -> void:
	draw_rect(Rect2(0, 0, Layout.W, Layout.H), Color(0.02, 0.05, 0.02, 0.62 * _fade()))
	var t := SpriteBank.tex("res://assets/art/ui/victory_panel.png")
	if t == null:
		t = SpriteBank.tex("res://assets/art/ui/victory.png")
	var sc := 0.95
	var w := 761.0 * sc
	var h := 534.0 * sc
	var pos := Vector2((Layout.W - w) * 0.5, (Layout.H - h) * 0.5 - 6.0)
	if t != null:
		draw_texture_rect(t, Rect2(pos, Vector2(w, h)), false)
	else:
		ArtUI.panel(self, Rect2(pos, Vector2(w, h)), Color(0.24, 0.16, 0.08), Color(0.60, 0.44, 0.20), 20.0)
	_draw_stats(Rect2(pos.x + 120.0 * sc, pos.y + 232.0 * sc, 500.0 * sc, 210.0 * sc))
	_draw_buttons()


## ---------------- 失败 ----------------
func _draw_lose() -> void:
	draw_rect(Rect2(0, 0, Layout.W, Layout.H), Color(0.0, 0.0, 0.0))
	var t := SpriteBank.tex("res://assets/art/ui/zombies_won.jpg")
	if t != null:
		var sc := 0.95
		var w := float(t.get_width()) * sc
		var h := float(t.get_height()) * sc
		draw_texture_rect(t, Rect2((Layout.W - w) * 0.5, 12.0, w, h), false)
	else:
		ArtUI.text_outline(self, Vector2(0, 240), "僵尸吃掉了你的脑子…", 52, Color(0.6, 0.95, 0.2),
			Color(0.02, 0.05, 0.01), 4.0, HORIZONTAL_ALIGNMENT_CENTER, Layout.W)
	_draw_buttons()
	ArtUI.text(self, Vector2(0, 578), _summary_line(), 13, Color(0.62, 0.86, 0.32, 0.85),
		HORIZONTAL_ALIGNMENT_CENTER, Layout.W)


func _summary_line() -> String:
	var secs := int(game.elapsed)
	var mm := secs / 60
	var ss := secs % 60
	return "用时 %d:%02d    ·    击杀僵尸 %d    ·    收集阳光 %d" % [mm, ss, game.zombies_killed, game.sun_collected]


func _draw_stats(area: Rect2) -> void:
	var secs := int(game.elapsed)
	var mm := secs / 60
	var ss := secs % 60
	var ml := 0
	for mo in game.mowers:
		if is_instance_valid(mo) and not mo.used:
			ml += 1
	var lines := [
		["用时", "%d:%02d" % [mm, ss]],
		["击杀僵尸", str(game.zombies_killed)],
		["剩余割草机", "%d / %d" % [ml, Layout.ROWS]],
		["收集阳光", str(game.sun_collected)],
	]
	var col_w := area.size.x * 0.5
	for i in lines.size():
		var col := i % 2
		var row := i / 2
		var x := area.position.x + 18.0 + float(col) * col_w
		var y := area.position.y + 24.0 + float(row) * 58.0
		ArtUI.text(self, Vector2(x, y), str(lines[i][0]), 15, Color(0.42, 0.30, 0.15))
		ArtUI.text_bold(self, Vector2(x, y + 26.0), str(lines[i][1]), 23, Color(0.35, 0.20, 0.06), 0.9)


func _draw_toast() -> void:
	var a := clampf(toast_t / 0.25, 0.0, 1.0)
	var r := Rect2(Layout.W * 0.5 - 260.0, 486.0, 520.0, 46.0)
	ArtUI.rrect(self, r.grow(2.0), 12.0, Color(0, 0, 0, 0.6 * a))
	ArtUI.rrect(self, r, 10.0, Color(0.16, 0.11, 0.06, 0.95 * a))
	ArtUI.rrect_outline(self, r, 10.0, Color(0.65, 0.48, 0.22, 0.9 * a), 2.0)
	ArtUI.text(self, Vector2(r.position.x, r.position.y + 30.0), toast_text, 16,
		Color(0.96, 0.92, 0.78, a), HORIZONTAL_ALIGNMENT_CENTER, r.size.x)


func _draw_help() -> void:
	draw_rect(Rect2(0, 0, Layout.W, Layout.H), Color(0.0, 0.0, 0.0, 0.74))
	var r := Rect2(Layout.W * 0.5 - 320.0, 110.0, 640.0, 380.0)
	ArtUI.panel(self, r, Color(0.20, 0.14, 0.07), Color(0.60, 0.44, 0.20), 16.0)
	ArtUI.text_outline(self, Vector2(0, 168), "操作说明", 34, Config.C_GOLD, Color(0.08, 0.05, 0.02), 3.0,
		HORIZONTAL_ALIGNMENT_CENTER, Layout.W)
	var lines := [
		"鼠标左键：收集阳光 / 选择种子卡 / 点击草坪种植",
		"1 ~ 8：快速选卡　　空格：暂停　　Esc：取消 / 暂停",
		"R：重新开始　　M：静音　　F11：全屏",
		"铲子（种子银行右侧）：点铲子后再点植物可铲除",
		"目标：收集阳光，种下植物，守住 10 波僵尸！",
	]
	for i in lines.size():
		ArtUI.text(self, Vector2(r.position.x + 50.0, 222.0 + float(i) * 42.0), str(lines[i]), 17,
			Color(0.94, 0.90, 0.78))
	ArtUI.text(self, Vector2(0, 468), "点击任意位置或按 H 关闭", 14,
		Color(0.82, 0.78, 0.64), HORIZONTAL_ALIGNMENT_CENTER, Layout.W)
