extends Node2D
## 植物大战僵尸 · 草坪保卫战 —— 主流程
##
## 用户参数（写在 -- 之后）：
##   --state=menu|play|pause|win|lose  启动状态（默认 menu）
##   --auto                             AI 自动演示（自动收阳光/种植物）
##   --ff=秒                            首帧前确定性快进 N 秒模拟
##   --speed=1.5                        游戏速度倍率
##   --seed=7                           固定随机种子
##   --mute                             静音
## 截图 / 定时退出由 CaptureRunner（autoload）处理。

enum St { MENU, CHOOSING, PLAYING, PAUSED, WIN, LOSE }

var state: int = St.MENU
var state_t := 0.0
var speed := 1.0
var muted := false

var start_state := "menu"
var auto_play := false
var ff_seconds := 0.0
var seed_arg := 0
var muted_arg := false
var shot_ui := false
var force_banner := false
var run_selftest := false
var showcase := false

var world: Node2D
var bg: LawnBackground
var hud: Hud
var screens: Screens
var sfx: Sfx
var hud_layer: CanvasLayer
var screens_layer: CanvasLayer

var grid: Array = []
var plants: Array = []
var zombies: Array = []
var peas: Array = []
var suns: Array = []
var mowers: Array = []
var fxs: Array = []

var sun := Config.START_SUN
var cooldowns: Array = []
var selected := -1
var shovel := false
var chosen: Array = []        # 选卡阶段已选植物（Config 索引）
var active_cards: Array = []  # 本局卡槽（Config 索引）
var intro_t := 0.0            # 准备-好-开始 阶段计时
var banner_kind := "text"

var wave_idx := 0
var wave_clock := 0.0
var spawn_queue: Array = []
var zombies_killed := 0
var sun_collected := 0
var elapsed := 0.0
var sun_fall_timer := 5.0
var banner_text := ""
var banner_t := 0.0

var shake_t := 0.0
var shake_amt := 0.0
var auto_timer := 0.0
var sun_flash := 0.0
var fx_enabled := true
var dbg_shots := 0
var dbg_hits := 0
var dbg_earned := 0
var dbg_sun_spawn := 0

var debug_log := false
var first_banner_done := false
var _dbg_next := 0.0

var rng := RandomNumberGenerator.new()
var rng_fx := RandomNumberGenerator.new()


func _ready() -> void:
	rng.randomize()
	rng_fx.randomize()
	_parse_args()
	_build_nodes()
	muted = muted_arg
	sfx.set_muted(muted)
	if start_state == "menu":
		_set_state(St.MENU)
	elif start_state == "chooser" or start_state == "choose":
		_open_chooser()
	else:
		_new_game(auto_play)
		if ff_seconds > 0.0:
			_fast_forward(ff_seconds)
		match start_state:
			"pause":
				_set_state(St.PAUSED)
			"win":
				_force_end(true)
			"lose":
				_force_end(false)
	if shot_ui:
		selected = 1
		hud.mouse_pos = Layout.card_rect(1).get_center()
		hud.hover_cell = Vector2i(3, 2)
	if force_banner:
		_show_banner("", "largewave")
	if showcase:
		_build_showcase()
	if run_selftest:
		_self_test()
	print("[PvZ] ready state=", start_state, " auto=", auto_play, " ff=", ff_seconds, " seed=", seed_arg)


func _parse_args() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--state="):
			start_state = arg.substr(8).strip_edges()
		elif arg.begins_with("--ff="):
			ff_seconds = maxf(0.0, float(arg.substr(5)))
		elif arg == "--auto":
			auto_play = true
		elif arg.begins_with("--speed="):
			speed = clampf(float(arg.substr(8)), 0.2, 6.0)
		elif arg.begins_with("--seed="):
			seed_arg = int(arg.substr(7))
		elif arg == "--mute":
			muted_arg = true
		elif arg == "--debug-log":
			debug_log = true
		elif arg == "--show-ui":
			shot_ui = true
		elif arg == "--banner":
			force_banner = true
		elif arg == "--selftest":
			run_selftest = true
		elif arg == "--showcase":
			showcase = true
	if ff_seconds > 0.0 and start_state == "menu":
		start_state = "play"
	if seed_arg != 0:
		rng.seed = seed_arg


func _build_nodes() -> void:
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	bg = LawnBackground.new()
	bg.name = "Background"
	world.add_child(bg)

	hud_layer = CanvasLayer.new()
	hud_layer.layer = 10
	add_child(hud_layer)
	hud = Hud.new()
	hud.game = self
	hud_layer.add_child(hud)

	screens_layer = CanvasLayer.new()
	screens_layer.layer = 20
	add_child(screens_layer)
	screens = Screens.new()
	screens.game = self
	screens_layer.add_child(screens)

	sfx = Sfx.new()
	sfx.game = self
	add_child(sfx)


## ---------------- 状态 ----------------
func _set_state(s: int) -> void:
	state = s
	state_t = 0.0
	match s:
		St.MENU:
			world.visible = false
			hud.visible = false
			screens.set_state("menu")
		St.CHOOSING:
			world.visible = true
			hud.visible = false
			screens.set_state("chooser")
		St.PLAYING:
			world.visible = true
			hud.visible = true
			screens.set_state("")
		St.PAUSED:
			hud.visible = true
			screens.set_state("pause")
		St.WIN:
			hud.visible = false
			screens.set_state("win")
		St.LOSE:
			hud.visible = false
			screens.set_state("lose")


func _to_menu() -> void:
	_clear_world()
	screens.help_visible = false
	screens.toast_t = 0.0
	sfx.play_music()
	_set_state(St.MENU)


func _build_showcase() -> void:
	intro_t = 2.0
	sun = 999.0
	var spots := [
		[0, 0, "sunflower"], [0, 1, "sunflower"], [1, 0, "sunflower"], [1, 1, "snowpea"],
		[2, 0, "sunflower"], [2, 1, "snowpea"], [3, 0, "sunflower"], [3, 1, "snowpea"],
		[4, 0, "sunflower"], [4, 1, "snowpea"],
		[1, 2, "peashooter"], [1, 3, "repeater"], [2, 2, "peashooter"], [2, 3, "repeater"],
		[3, 2, "peashooter"], [3, 3, "repeater"], [4, 2, "peashooter"], [4, 3, "wallnut"],
		[2, 4, "wallnut"], [3, 4, "cherrybomb"], [0, 4, "chomper"], [1, 4, "chomper"],
		[2, 5, "potatomine"], [3, 5, "potatomine"],
	]
	for s in spots:
		var idx := _plant_index_by_id(str(s[2]))
		if idx < 0:
			continue
		var cell := Vector2i(int(s[1]), int(s[0]))
		if grid[cell.y][cell.x] != null:
			continue
		var d: Dictionary = Config.PLANTS[idx]
		var p := Plant.new()
		p.setup(d, cell.y, cell.x)
		world.add_child(p)
		plants.append(p)
		grid[cell.y][cell.x] = p
		p.pop_t = 1.0
		p.scale = Vector2.ONE
		if str(s[2]) == "cherrybomb":
			p.explode_timer = 999.0
	# 摆几只僵尸
	var ztypes := ["basic", "cone", "bucket", "basic", "flag", "cone"]
	for i in ztypes.size():
		var z := Zombie.new()
		z.setup(ztypes[i], i % 5)
		z.x = 980.0 + float(i) * 26.0
		z.apply_pos()
		world.add_child(z)
		zombies.append(z)
	sfx.play_music()


func _plant_index_by_id(pid: String) -> int:
	for i in Config.PLANTS.size():
		if str(Config.PLANTS[i]["id"]) == pid:
			return i
	return -1


func _open_chooser() -> void:
	_clear_world()
	active_cards.clear()
	intro_t = 0.0
	_set_state(St.CHOOSING)


func _new_game(auto_mode: bool) -> void:
	auto_play = auto_mode
	_clear_world()
	grid = []
	for r in Layout.ROWS:
		var row_arr: Array = []
		for c in Layout.COLS:
			row_arr.append(null)
		grid.append(row_arr)
	sun = Config.START_SUN
	if chosen.is_empty():
		for i in Config.PLANTS.size():
			chosen.append(i)
	active_cards = chosen.duplicate()
	cooldowns = []
	for i in Config.PLANTS.size():
		cooldowns.append(0.0)
	selected = -1
	shovel = false
	wave_idx = 0
	wave_clock = 0.0
	spawn_queue.clear()
	zombies_killed = 0
	sun_collected = 0
	elapsed = 0.0
	sun_fall_timer = 6.0
	banner_text = ""
	banner_t = 0.0
	shake_t = 0.0
	auto_timer = 1.0
	sun_flash = 0.0
	fx_enabled = true
	sfx.silent = false
	first_banner_done = false
	intro_t = 0.0
	banner_kind = "text"
	if seed_arg == 0:
		rng.randomize()
	world.position = Vector2.ZERO
	for r in Layout.ROWS:
		var m := Mower.new()
		m.setup(r)
		world.add_child(m)
		mowers.append(m)
	_set_state(St.PLAYING)
	sfx.play_music()
	sfx.play("readysetplant", -8.0)


func _clear_world() -> void:
	for n in world.get_children():
		if n == bg:
			continue
		n.queue_free()
	plants.clear()
	zombies.clear()
	peas.clear()
	suns.clear()
	mowers.clear()
	fxs.clear()
	grid.clear()


func _fast_forward(seconds: float) -> void:
	sfx.silent = true
	fx_enabled = false
	var step := 1.0 / 60.0
	var t := 0.0
	var guard := 0
	while t < seconds and state == St.PLAYING:
		_simulate(step)
		t += step
		guard += 1
		if guard > 200000:
			break
	sfx.silent = false
	fx_enabled = true
	print("[PvZ] fast-forward done: sim=%.1fs wave_idx=%d zombies=%d state=%d" % [t, wave_idx, zombies.size(), state])


func _force_end(win: bool) -> void:
	selected = -1
	shovel = false
	sfx.silent = false
	var mleft := 0
	for m in mowers:
		if is_instance_valid(m) and not m.used:
			mleft += 1
	print("[PvZ] END win=%s t=%.1f wave_done=%d kills=%d sun=%d mowers_left=%d sunflowers=%d cherries_seen=%d" %
		[str(win), elapsed, wave_idx, zombies_killed, int(sun), mleft, _count_kind("sunflower"), _count_kind("cherrybomb")])
	print("[PvZ] plants: peashooter=%d snowpea=%d repeater=%d wallnut=%d" %
		[_count_kind("peashooter"), _count_kind("snowpea"), _count_kind("repeater"), _count_kind("wallnut")])
	for r in 5:
		var shooters := _row_shooter_count(r)
		var nuts := _row_kind_count(r, "wallnut")
		print("[PvZ] row%d shooters=%d wallnut=%d minzx=%.0f" % [r, shooters, nuts, _row_min_zombie_x(r)])
	_set_state(St.WIN if win else St.LOSE)
	sfx.play("win" if win else "lose", -3.0)


## ---------------- 主循环 ----------------
func _process(delta: float) -> void:
	if state == St.PLAYING:
		_simulate(delta * speed)
	_update_visual(delta)
	hud.queue_redraw()
	screens.queue_redraw()


func _self_test() -> void:
	print("[TEST] --- input chaining test ---")
	# 选卡
	_click(Layout.card_rect(0).get_center())
	print("[TEST] select card0 -> selected=", selected, " expect 0: ", "PASS" if selected == 0 else "FAIL")
	# 种植到 (row2, col0)
	var cell := Vector2i(0, 2)
	var sun_before := sun
	_click(Layout.cell_center(cell.y, cell.x))
	print("[TEST] plant -> occupied=", grid[2][0] != null, " sun ", int(sun_before), "->", int(sun),
		" planted=", _count_kind("sunflower"), " PASS=", grid[2][0] != null)
	# 铲子移除
	_click(Layout.SHOVEL_RECT.get_center())
	print("[TEST] shovel mode=", shovel)
	_click(Layout.cell_center(cell.y, cell.x))
	print("[TEST] dig -> empty=", grid[2][0] == null, " PASS=", grid[2][0] == null)
	# 阳光点击
	var orb := SunOrb.new()
	orb.setup_fall(Vector2(500, 300), 300)
	world.add_child(orb)
	suns.append(orb)
	var s0 := sun
	_click(Vector2(500, 300))
	var flying := orb.state == SunOrb.ST_FLY
	var ft := 0.0
	while ft < 1.0 and orb.state != SunOrb.ST_DONE:
		orb.sim_step(1.0 / 60.0, self)
		ft += 1.0 / 60.0
	print("[TEST] sun click -> flying=", flying, " final_sun=", int(sun), " gained=", int(sun - s0),
		" PASS=", flying and int(sun - s0) == 25)
	# 暂停/继续
	_set_state(St.PAUSED)
	_do_screen_action("resume")
	print("[TEST] pause/resume -> state=", state, " PASS=", state == St.PLAYING)
	# 樱桃炸弹 + 爆炸死亡帧
	intro_t = 2.0
	sun = 500.0
	cooldowns[5] = 0.0
	var zt := Zombie.new()
	zt.setup("basic", 2)
	zt.x = 570.0
	zt.apply_pos()
	world.add_child(zt)
	zombies.append(zt)
	var cell_cherry := Vector2i(4, 2)
	_place_plant(cell_cherry, 5)
	for i in 80:
		_simulate(1.0 / 60.0)
	print("[TEST] cherry -> exploded=", grid[2][4] == null, " zombie_dying=", zt.dying,
		" boom_die=", zt.boom_die, " PASS=", zt.dying and zt.boom_die)
	# 土豆雷
	sun = 500.0
	cooldowns[6] = 0.0
	var pt_cell := Vector2i(8, 3)
	_place_plant(pt_cell, 6)
	var p_pot: Plant = grid[3][8]
	if p_pot != null:
		p_pot.arm_t = 0.1
	var zpt := Zombie.new()
	zpt.setup("basic", 3)
	zpt.x = 980.0
	zpt.apply_pos()
	world.add_child(zpt)
	zombies.append(zpt)
	for i in 360:
		_simulate(1.0 / 60.0)
	print("[TEST] potatomine -> plant_gone=", grid[3][8] == null, " zombie_dying=", zpt.dying,
		" PASS=", zpt.dying)
	# 大嘴花
	sun = 500.0
	cooldowns[7] = 0.0
	var ch_cell := Vector2i(4, 0)
	_place_plant(ch_cell, 7)
	var zch := Zombie.new()
	zch.setup("basic", 0)
	zch.x = 570.0
	zch.apply_pos()
	world.add_child(zch)
	zombies.append(zch)
	for i in 150:
		_simulate(1.0 / 60.0)
	print("[TEST] chomper -> zombie_dying=", zch.dying, " PASS=", zch.dying)
	print("[TEST] --- done ---")


func _update_visual(delta: float) -> void:
	if shot_ui:
		selected = 1
		shovel = false
		sun = 500.0
		for i in cooldowns.size():
			cooldowns[i] = 0.0
		hud.hover_cell = Vector2i(7, 3)
		hud.mouse_pos = Layout.card_rect(2).get_center()
	if not shot_ui:
		var m := get_viewport().get_mouse_position()
		hud.mouse_pos = m
		screens.mouse_pos = m
		if state == St.PLAYING:
			hud.hover_cell = Layout.cell_at(m)
		else:
			hud.hover_cell = Vector2i(-1, -1)
	sun_flash = maxf(0.0, sun_flash - delta * 1.6)
	if shake_t > 0.0:
		shake_t = maxf(0.0, shake_t - delta)
		var k := shake_t / 0.35
		world.position = Vector2(rng_fx.randf_range(-1.0, 1.0), rng_fx.randf_range(-1.0, 1.0)) * shake_amt * k
	else:
		world.position = Vector2.ZERO


func _simulate(dt: float) -> void:
	if dt <= 0.0 or state != St.PLAYING:
		return
	# 准备 - 好 - 开始：开场冻结约 1.9 秒
	if intro_t < 1.9:
		intro_t += dt
		return
	elapsed += dt
	for i in cooldowns.size():
		cooldowns[i] = maxf(0.0, cooldowns[i] - dt)
	banner_t = maxf(0.0, banner_t - dt)
	_update_waves(dt)
	for p in plants.duplicate():
		if is_instance_valid(p) and not p.dead:
			p.sim_step(dt, self)
	for z in zombies.duplicate():
		if is_instance_valid(z):
			z.sim_step(dt, self)
	_update_peas(dt)
	for s in suns.duplicate():
		if is_instance_valid(s):
			s.sim_step(dt, self)
	for m in mowers.duplicate():
		if is_instance_valid(m):
			m.sim_step(dt, self)
	for f in fxs.duplicate():
		if is_instance_valid(f):
			f.sim_step(dt)
			if f.finished:
				_remove_fx(f)
	_update_sun_fall(dt)
	_update_mowers_hit()
	_cleanup()
	if auto_play:
		_auto_think(dt)
	_check_end()
	if debug_log and elapsed >= _dbg_next:
		_dbg_next = elapsed + 10.0
		print("[DBG] t=%.0f sun=%d flowers=%d shooters=%d nuts=%d zomb=%d killed=%d wave=%d mowers=%d shots=%d hits=%d earned=%d suns=%d" %
			[elapsed, int(sun), _count_kind("sunflower"),
			_count_kind("peashooter") + _count_kind("snowpea") + _count_kind("repeater"),
			_count_kind("wallnut"), zombies.size(), zombies_killed, wave_idx, mowers.size(),
			dbg_shots, dbg_hits, dbg_earned, dbg_sun_spawn])


## ---------------- 波次 ----------------
func _update_waves(dt: float) -> void:
	wave_clock += dt
	while wave_idx < Config.WAVES.size() and wave_clock >= float(Config.WAVES[wave_idx]["at"]):
		_start_wave(wave_idx)
		wave_idx += 1
	for item in spawn_queue.duplicate():
		item["t"] = float(item["t"]) - dt
		if float(item["t"]) <= 0.0:
			spawn_queue.erase(item)
			_spawn_zombie(str(item["type"]), int(item["lane"]))


func _start_wave(idx: int) -> void:
	var w: Dictionary = Config.WAVES[idx]
	if w.get("final", false):
		_show_banner("", "finalwave")
		sfx.play("finalwave", -6.0)
	elif w.get("big", false):
		_show_banner("", "largewave")
		sfx.play("wave_horn", -8.0)
	var list: Array = []
	for pair in w["spawns"]:
		for i in int(pair[1]):
			list.append(str(pair[0]))
	var delay := 0.0
	for t in list:
		spawn_queue.append({"t": delay, "type": t, "lane": _pick_lane()})
		delay += rng.randf_range(0.35, 0.95)


func _pick_lane() -> int:
	var counts := [0, 0, 0, 0, 0]
	for z in zombies:
		if is_instance_valid(z) and not z.dying:
			counts[z.row] += 1
	var min_c := 999
	for c in counts:
		min_c = mini(min_c, int(c))
	var best: Array = []
	for r in 5:
		if int(counts[r]) == min_c:
			best.append(r)
	if rng.randf() < 0.75:
		return int(best[rng.randi_range(0, best.size() - 1)])
	return rng.randi_range(0, 4)


func _spawn_zombie(t: String, lane: int) -> void:
	var z := Zombie.new()
	z.setup(t, lane)
	z.x = Layout.SPAWN_X + rng.randf_range(0.0, 40.0)
	z.apply_pos()
	world.add_child(z)
	zombies.append(z)


func _show_banner(text: String, kind: String = "text") -> void:
	banner_text = text
	banner_kind = kind
	banner_t = 2.8


## ---------------- 阳光 ----------------
func sun_target_pos() -> Vector2:
	return Layout.SUN_NUM_CENTER


func _update_sun_fall(dt: float) -> void:
	sun_fall_timer -= dt
	if sun_fall_timer <= 0.0:
		sun_fall_timer = rng.randf_range(Config.SUNFALL_MIN, Config.SUNFALL_MAX)
		var x := rng.randf_range(Layout.LAWN_LEFT + 40.0, Layout.LAWN_RIGHT - 40.0)
		var ty := rng.randf_range(Layout.LAWN_TOP + 30.0, Layout.LAWN_BOTTOM - 50.0)
		var orb := SunOrb.new()
		orb.setup_fall(Vector2(x, -40.0), ty)
		world.add_child(orb)
		suns.append(orb)
		dbg_sun_spawn += 1


func spawn_plant_sun(p: Plant) -> void:
	var orb := SunOrb.new()
	orb.setup_plant(p.position)
	dbg_sun_spawn += 1
	world.add_child(orb)
	suns.append(orb)


func finish_sun(orb: SunOrb) -> void:
	sun = minf(Config.SUN_CAP, sun + orb.value)
	sun_collected += int(orb.value)
	dbg_earned += int(orb.value)
	sun_flash = 1.0
	_spawn_fx(Fx.sparkle(sun_target_pos()))
	remove_sun(orb, true)


func remove_sun(orb: SunOrb, _collected: bool) -> void:
	if orb in suns:
		suns.erase(orb)
	if is_instance_valid(orb):
		orb.queue_free()


## ---------------- 植物 ----------------
func _try_plant(cell: Vector2i, idx: int) -> bool:
	if cell.x < 0 or cell.y < 0:
		return false
	if grid[cell.y][cell.x] != null:
		return false
	var d: Dictionary = Config.PLANTS[idx]
	if sun < float(d["cost"]) or cooldowns[idx] > 0.0:
		return false
	_place_plant(cell, idx)
	return true


func _place_plant(cell: Vector2i, idx: int) -> void:
	var d: Dictionary = Config.PLANTS[idx]
	var p := Plant.new()
	p.setup(d, cell.y, cell.x)
	world.add_child(p)
	plants.append(p)
	grid[cell.y][cell.x] = p
	sun -= float(d["cost"])
	cooldowns[idx] = float(d["cd"])
	selected = -1
	shovel = false
	sfx.play("plant", -5.0)
	_spawn_fx(Fx.dirt(p.position))


func _select_card(i: int) -> void:
	if i < 0 or i >= Config.PLANTS.size():
		return
	if selected == i:
		selected = -1
		return
	if cooldowns[i] > 0.0 or sun < float(Config.PLANTS[i]["cost"]):
		hud.flash_deny(i)
		sfx.play("prohibit", -8.0)
		selected = -1
		return
	shovel = false
	selected = i
	sfx.play("seedlift", -6.0)


func _dig(cell: Vector2i) -> void:
	var p = grid[cell.y][cell.x]
	if p == null:
		return
	grid[cell.y][cell.x] = null
	plants.erase(p)
	_spawn_fx(Fx.dirt(p.position))
	p.queue_free()
	sfx.play("shovel", -6.0)


func plants_should_fire(p: Plant) -> bool:
	for z in zombies:
		if not is_instance_valid(z) or z.dying or z.row != p.row:
			continue
		if z.x > p.position.x - 30.0:
			return true
	return false


func plant_shoot(p: Plant) -> void:
	if not is_instance_valid(p) or p.dead:
		return
	var base := p.position + Vector2(34.0, -20.0)
	if p.kind == "repeater":
		_spawn_pea(p.row, base)
		_spawn_pea(p.row, base + Vector2(26.0, 0.0))
	else:
		_spawn_pea(p.row, base, p.kind == "snowpea")
	sfx.play("pea_shoot", -15.0)


func _spawn_pea(row: int, pos: Vector2, icy: bool = false) -> void:
	dbg_shots += 1
	var p := Pea.new()
	p.setup(row, pos, icy)
	world.add_child(p)
	peas.append(p)


func _remove_pea(p: Pea) -> void:
	if p in peas:
		peas.erase(p)
	if is_instance_valid(p):
		p.queue_free()


func cherry_explode(p: Plant) -> void:
	if p.dead:
		return
	p.dead = true
	var center := p.position
	for z in zombies.duplicate():
		if not is_instance_valid(z) or z.dying:
			continue
		if absf(z.position.y - center.y) <= Layout.CELL_H * 1.6 \
				and absf(z.x - center.x) <= Layout.CELL_W * 1.6:
			_kill_zombie(z, true)
	_spawn_fx(Fx.boom(center))
	_spawn_fx(Fx.explosion(center))
	sfx.play("explosion", -2.0)
	add_shake(9.0)


## ---------------- 僵尸 / 豌豆 ----------------
func find_eat_target(z: Zombie) -> Plant:
	var best: Plant = null
	var best_x := -100000.0
	for p in plants:
		if not is_instance_valid(p) or p.dead or p.row != z.row:
			continue
		if p.position.x <= z.x + 8.0 and p.position.x > best_x:
			best_x = p.position.x
			best = p
	if best == null:
		return null
	if z.x - 30.0 <= best.position.x + 36.0:
		return best
	return null


func _update_peas(dt: float) -> void:
	for pea in peas.duplicate():
		if not is_instance_valid(pea):
			continue
		pea.sim_step(dt)
		if pea.x > Layout.W + 60.0:
			_remove_pea(pea)
			continue
		var hit: Zombie = null
		for z in zombies:
			if not is_instance_valid(z) or z.dying or z.row != pea.row:
				continue
			if pea.x >= z.x - 30.0 and pea.x <= z.x + 36.0:
				hit = z
				break
		if hit != null:
			hit.take_damage(pea.dmg)
			dbg_hits += 1
			if pea.icy:
				hit.slow_timer = Config.PEA_SLOW_TIME
			var col := Color(0.55, 0.85, 0.35) if not pea.icy else Color(0.72, 0.92, 1.0)
			_spawn_fx(Fx.splat(pea.position, col, 8, 130.0))
			if pea.icy:
				_spawn_fx(Fx.frost(pea.position))
			sfx.play("pea_hit", -10.0)
			_remove_pea(pea)
			if hit.hp <= 0.0 and not hit.dying:
				_kill_zombie(hit)


## 大嘴花：找同一行正前方约 1 格内的僵尸
func find_chomper_target(p: Plant) -> Zombie:
	var best: Zombie = null
	for z in zombies:
		if not is_instance_valid(z) or z.dying or z.row != p.row:
			continue
		if z.x > p.position.x - 14.0 and z.x < p.position.x + 72.0:
			if best == null or z.x < best.x:
				best = z
	return best


func chomp_kill(p: Plant, z: Zombie) -> void:
	if not is_instance_valid(z) or z.dying:
		return
	z.take_damage(99999.0)
	_kill_zombie(z)
	sfx.play("zombie_bite", -4.0)
	_spawn_fx(Fx.splat(z.position + Vector2(0, -60), Color(0.5, 0.55, 0.42), 8, 110.0))


## 土豆雷：僵尸踩到同一格范围
func find_potato_target(p: Plant) -> Zombie:
	for z in zombies:
		if not is_instance_valid(z) or z.dying or z.row != p.row:
			continue
		if absf(z.x - p.position.x) < 70.0:
			return z
	return null


func potato_explode(p: Plant) -> void:
	if p.dead:
		return
	p.dead = true
	var center := p.position
	for z in zombies.duplicate():
		if not is_instance_valid(z) or z.dying or z.row != p.row:
			continue
		if absf(z.x - center.x) < 80.0:
			_kill_zombie(z)
	_spawn_fx(Fx.boom(center))
	_spawn_fx(Fx.explosion(center))
	sfx.play("explosion", -4.0)
	add_shake(5.0)


func _kill_zombie(z: Zombie, by_boom: bool = false) -> void:
	if not is_instance_valid(z) or z.dying:
		return
	z.kill(by_boom)
	zombies_killed += 1
	if not by_boom:
		_spawn_fx(Fx.splat(z.position + Vector2(0, -70), Color(0.5, 0.55, 0.42), 6, 90.0))
		sfx.play("zombie_die", -10.0)


## ---------------- 割草机 ----------------
func _mower_for_row(row: int) -> Mower:
	for m in mowers:
		if is_instance_valid(m) and m.row == row and not m.used:
			return m
	return null


func _update_mowers_hit() -> void:
	for m in mowers:
		if not is_instance_valid(m) or not m.used:
			continue
		for z in zombies:
			if not is_instance_valid(z) or z.dying or z.row != m.row:
				continue
			if z.x < m.position.x + 80.0 and z.x > m.position.x - 120.0:
				_kill_zombie(z)


func remove_mower(m: Mower) -> void:
	if m in mowers:
		mowers.erase(m)
	if is_instance_valid(m):
		m.queue_free()


## ---------------- 清理 / 结束 ----------------
func _cleanup() -> void:
	for p in plants.duplicate():
		if not is_instance_valid(p):
			plants.erase(p)
			continue
		if p.dead:
			if grid[p.row][p.col] == p:
				grid[p.row][p.col] = null
			_spawn_fx(Fx.dirt(p.position))
			plants.erase(p)
			p.queue_free()
	for z in zombies.duplicate():
		if not is_instance_valid(z):
			zombies.erase(z)
			continue
		if z.dying:
			var limit := 2.15 if z.boom_die else 1.80
			if z.death_t > limit:
				zombies.erase(z)
				z.queue_free()
	for s in suns.duplicate():
		if not is_instance_valid(s):
			suns.erase(s)
			continue
		if s.state == SunOrb.ST_DONE:
			suns.erase(s)
			s.queue_free()


func _check_end() -> void:
	if state != St.PLAYING:
		return
	for z in zombies:
		if not is_instance_valid(z) or z.dying:
			continue
		if z.x < Layout.LAWN_LEFT - 12.0:
			var m := _mower_for_row(z.row)
			if m != null:
				m.trigger()
				sfx.play("mower", -4.0)
			elif z.x < Layout.HOUSE_EDGE - 10.0:
				_force_end(false)
				return
	if wave_idx >= Config.WAVES.size() and zombies.is_empty() and spawn_queue.is_empty():
		_force_end(true)


func add_shake(amount: float) -> void:
	shake_amt = amount
	shake_t = 0.35


func _spawn_fx(f: Fx) -> void:
	if not fx_enabled or f == null:
		return
	world.add_child(f)
	fxs.append(f)


func _remove_fx(f: Fx) -> void:
	if f in fxs:
		fxs.erase(f)
	if is_instance_valid(f):
		f.queue_free()


## ---------------- 自动演示 AI ----------------
func _auto_think(dt: float) -> void:
	auto_timer -= dt
	if auto_timer > 0.0:
		return
	auto_timer = 0.3
	for s in suns.duplicate():
		if is_instance_valid(s) and s.collectable():
			if s.collect():
				sfx.play("sun_collect", -10.0)
	_auto_plant()


func _threat_score(row: int) -> float:
	var sc := 0.0
	for z in zombies:
		if is_instance_valid(z) and not z.dying and z.row == row:
			sc += 1.0 + maxf(0.0, 1000.0 - z.x) / 400.0
		if sc <= 0.0:
			continue
	return sc


func _auto_plant() -> void:
	# 建造顺序（接近一个会玩的玩家）：3 向日葵 → 每行 1 射手 → 6 向日葵 → 每行 2 射手 → 坚果/樱桃
	var flowers := _count_kind("sunflower")
	var shooters := _count_kind("peashooter") + _count_kind("snowpea") + _count_kind("repeater")
	if flowers < 3 and cooldowns[0] <= 0.0 and sun >= 50.0:
		var cell := _find_empty(0, 1)
		if cell.x >= 0:
			_place_plant(cell, 0)
			return
	if shooters < 5 and cooldowns[1] <= 0.0 and sun >= 100.0:
		var r := _need_shooter_row()
		if r >= 0:
			var cell2 := _find_empty(2, 5, r)
			if cell2.x >= 0:
				_place_plant(cell2, 1)
				return
	if flowers < 6 and cooldowns[0] <= 0.0 and sun >= 50.0:
		var cell3 := _find_empty(0, 1)
		if cell3.x >= 0:
			_place_plant(cell3, 0)
			return
	if shooters < 10 and cooldowns[1] <= 0.0 and sun >= 100.0:
		var r2 := _need_shooter_row()
		if r2 >= 0:
			var cell4 := _find_empty(2, 5, r2)
			if cell4.x >= 0:
				_place_plant(cell4, 1)
				return
	# 坚果挡在最危险行
	if cooldowns[2] <= 0.0 and sun >= 50.0:
		var nut_row := -1
		var nut_score := 0.0
		for r3 in 5:
			if _row_kind_count(r3, "wallnut") > 0:
				continue
			var sc := _threat_score(r3)
			if sc > nut_score:
				nut_score = sc
				nut_row = r3
		if nut_row >= 0 and _row_min_zombie_x(nut_row) < 700.0:
			var cell5 := _find_empty(6, 8, nut_row)
			if cell5.x >= 0:
				_place_plant(cell5, 2)
				return
	# 僵尸扎堆时樱桃炸弹
	if cooldowns[5] <= 0.0 and sun >= 130.0:
		var cc := _cherry_cell()
		if cc.x >= 0:
			_place_plant(cc, 5)
			return
	# 土豆雷守前排
	if cooldowns[6] <= 0.0 and sun >= 100.0:
		for r6 in 5:
			if _row_min_zombie_x(r6) < 820.0 and _row_kind_count(r6, "potatomine") == 0:
				var cell6 := _find_empty(7, 8, r6)
				if cell6.x >= 0:
					_place_plant(cell6, 6)
					return
	# 大嘴花守后排
	if cooldowns[7] <= 0.0 and sun >= 220.0:
		for r7 in 5:
			if _row_min_zombie_x(r7) < 720.0 and _row_kind_count(r7, "chomper") == 0:
				var cell7 := _find_empty(5, 6, r7)
				if cell7.x >= 0:
					_place_plant(cell7, 7)
					return
	# 钱多时升级：寒冰 + 双发
	if cooldowns[3] <= 0.0 and sun >= 260.0 and _count_kind("snowpea") < 3:
		var r4 := _need_shooter_row()
		if r4 >= 0:
			var cell6 := _find_empty(2, 5, r4)
			if cell6.x >= 0:
				_place_plant(cell6, 3)
				return
	if cooldowns[4] <= 0.0 and sun >= 340.0 and _count_kind("repeater") < 4:
		var r5 := _need_shooter_row()
		if r5 >= 0:
			var cell7 := _find_empty(2, 5, r5)
			if cell7.x >= 0:
				_place_plant(cell7, 4)
				return


func _find_empty(col_min: int, col_max: int, prefer_row: int = -1) -> Vector2i:
	var cand: Array = []
	var c_hi := mini(col_max, Layout.COLS - 1)
	for r in Layout.ROWS:
		if prefer_row >= 0 and r != prefer_row:
			continue
		for c in range(col_min, c_hi + 1):
			if grid[r][c] == null:
				cand.append(Vector2i(c, r))
	if cand.is_empty():
		return Vector2i(-1, -1)
	return cand[rng.randi_range(0, cand.size() - 1)]


func _count_kind(kind: String) -> int:
	var n := 0
	for p in plants:
		if is_instance_valid(p) and not p.dead and p.kind == kind:
			n += 1
	return n


func _row_kind_count(row: int, kind: String) -> int:
	var n := 0
	for p in plants:
		if is_instance_valid(p) and not p.dead and p.row == row and p.kind == kind:
			n += 1
	return n


func _row_shooter_count(row: int) -> int:
	var n := 0
	for p in plants:
		if is_instance_valid(p) and not p.dead and p.row == row:
			if p.kind == "peashooter" or p.kind == "snowpea" or p.kind == "repeater":
				n += 1
	return n


func _need_shooter_row() -> int:
	var best := -1
	var best_n := 99
	for r in 5:
		var n := _row_shooter_count(r)
		if n < 2 and n < best_n:
			best_n = n
			best = r
	if best >= 0 and _find_empty(2, 5, best).x < 0:
		return -1
	return best


func _row_min_zombie_x(row: int) -> float:
	var mx := 9999.0
	for z in zombies:
		if is_instance_valid(z) and not z.dying and z.row == row:
			mx = minf(mx, z.x)
	return mx


func _cherry_cell() -> Vector2i:
	var total := 0
	var sum_row := 0.0
	var sum_x := 0.0
	for z in zombies:
		if not is_instance_valid(z) or z.dying:
			continue
		if z.x < 1000.0 and z.x > 320.0:
			total += 1
			sum_row += float(z.row)
			sum_x += z.x
	if total < 3:
		return Vector2i(-1, -1)
	var nearest := 9999.0
	for z in zombies:
		if is_instance_valid(z) and not z.dying:
			nearest = minf(nearest, z.x)
	if total < 4 and nearest > 520.0:
		return Vector2i(-1, -1)
	var avg_row := int(round(sum_row / float(total)))
	var avg_x := sum_x / float(total)
	var col := clampi(int((avg_x - Layout.LAWN_LEFT) / Layout.CELL_W), 0, Layout.COLS - 1)
	if grid[avg_row][col] == null:
		return Vector2i(col, avg_row)
	var cell := _find_empty(maxi(col - 1, 0), mini(col + 1, Layout.COLS - 1), avg_row)
	return cell


## ---------------- 输入 ----------------
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_click(event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		_key(event.keycode)


func _click(pos: Vector2) -> void:
	if screens.help_visible:
		screens.help_visible = false
		return
	if state == St.CHOOSING:
		var a0 := screens.hit(pos)
		if a0 != "":
			_do_screen_action(a0)
			return
		var ci := screens.chooser_card_at(pos)
		if ci >= 0:
			if ci in chosen:
				chosen.erase(ci)
			elif chosen.size() < 6:
				chosen.append(ci)
			sfx.play("seedlift", -8.0)
		return
	match state:
		St.MENU, St.PAUSED, St.WIN, St.LOSE:
			_do_screen_action(screens.hit(pos))
			return
	if state != St.PLAYING:
		return
	if Layout.PAUSE_RECT.has_point(pos):
		sfx.play("ui_pause", -6.0)
		_set_state(St.PAUSED)
		return
	if Layout.SOUND_RECT.has_point(pos):
		_toggle_mute()
		return
	for s in suns:
		if is_instance_valid(s) and s.collectable() and pos.distance_to(s.position) <= 50.0:
			if s.collect():
				sfx.play("sun_collect", -5.0)
			return
	var ci := hud.card_at(pos)
	if ci >= 0:
		_select_card(ci)
		return
	if Layout.SHOVEL_RECT.has_point(pos):
		shovel = not shovel
		selected = -1
		sfx.play("shovel", -12.0)
		return
	var cell := Layout.cell_at(pos)
	if cell.x >= 0:
		if shovel:
			_dig(cell)
		elif selected >= 0:
			if not _try_plant(cell, selected):
				if grid[cell.y][cell.x] != null:
					hud.flash_deny(selected)
		return
	selected = -1
	shovel = false


func _do_screen_action(a: String) -> void:
	match a:
		"start":
			chosen.clear()
			_open_chooser()
		"start_choose":
			if chosen.is_empty():
				screens.toast("请先点击选择至少一种植物")
			else:
				_new_game(false)
		"auto":
			chosen.clear()
			for i in Config.PLANTS.size():
				chosen.append(i)
			_new_game(true)
		"resume":
			_set_state(St.PLAYING)
		"restart":
			_new_game(auto_play)
		"again":
			_new_game(auto_play)
		"retry":
			_new_game(auto_play)
		"menu":
			_to_menu()
		"help":
			screens.help_visible = not screens.help_visible
		"mute":
			_toggle_mute()
		_:
			if a.begins_with("toast|"):
				screens.toast(a.substr(6))


func _select_slot(slot: int) -> void:
	if state != St.PLAYING:
		return
	if slot >= 0 and slot < active_cards.size():
		_select_card(int(active_cards[slot]))


func _toggle_mute() -> void:
	muted = not muted
	sfx.set_muted(muted)


func _key(code: int) -> void:
	match code:
		KEY_ESCAPE:
			if state == St.PLAYING:
				_set_state(St.PAUSED)
			elif state == St.PAUSED:
				_set_state(St.PLAYING)
			elif state == St.WIN or state == St.LOSE or state == St.CHOOSING:
				_to_menu()
			elif screens.help_visible:
				screens.help_visible = false
		KEY_H:
			screens.help_visible = not screens.help_visible
		KEY_SPACE:
			if state == St.PLAYING:
				_set_state(St.PAUSED)
			elif state == St.PAUSED:
				_set_state(St.PLAYING)
		KEY_R:
			if state != St.MENU:
				_new_game(auto_play)
		KEY_M:
			_toggle_mute()
		KEY_F11:
			var w := get_window()
			w.mode = Window.MODE_WINDOWED if w.mode == Window.MODE_FULLSCREEN else Window.MODE_FULLSCREEN
		KEY_1:
			_select_slot(0)
		KEY_2:
			_select_slot(1)
		KEY_3:
			_select_slot(2)
		KEY_4:
			_select_slot(3)
		KEY_5:
			_select_slot(4)
		KEY_6:
			_select_slot(5)
		KEY_7:
			_select_slot(6)
		KEY_8:
			_select_slot(7)
