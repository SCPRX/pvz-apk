class_name LawnBackground
extends Node2D
## 原版白天前院背景（1400x600），素材缺失时回退程序化草坪

func _ready() -> void:
	z_index = -100
	queue_redraw()


func _draw() -> void:
	var t := SpriteBank.tex("res://assets/art/bg_day.jpg")
	if t != null:
		draw_texture_rect(t, Rect2(Layout.BG_POS, Layout.BG_SIZE), false)
		return
	# 兜底：程序化草坪
	draw_rect(Rect2(0, 0, Layout.W, Layout.H), Color(0.15, 0.24, 0.11))
	draw_rect(Rect2(Layout.LAWN_LEFT - 10, Layout.LAWN_TOP - 10,
		Layout.COLS * Layout.CELL_W + 20, Layout.ROWS * Layout.CELL_H + 20), Color(0.24, 0.35, 0.14))
	for r in Layout.ROWS:
		var col := Config.C_LAWN_A if r % 2 == 0 else Config.C_LAWN_B
		draw_rect(Rect2(Layout.LAWN_LEFT, Layout.LAWN_TOP + float(r) * Layout.CELL_H,
			float(Layout.COLS) * Layout.CELL_W, Layout.CELL_H), col)
